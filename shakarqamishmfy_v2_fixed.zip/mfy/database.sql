-- ============================================================
-- ShakarqamishMFY — Database sxemasi
-- Import: PHPMyAdmin -> c552_mahalla bazasiga
-- ============================================================
SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;

-- Settings
CREATE TABLE IF NOT EXISTS `settings` (
  `id`    SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `key`   VARCHAR(100) NOT NULL,
  `value` TEXT DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`key`,`value`) VALUES
('site_name',       'ShakarqamishMFY'),
('site_phone',      '+998 XX XXX XX XX'),
('site_phone2',     '+998 XX XXX XX XX'),
('site_email',      'info@shakarqamishmfy.uz'),
('site_address',    'Surxondaryo viloyati, Oltinsoy tumani, Shakarqamish MFY'),
('site_telegram',   'https://t.me/shakarqamishmfy'),
('site_facebook',   ''),
('site_instagram',  ''),
('site_youtube',    ''),
('site_logo',       ''),
('population',      '0'),
('households',      '0'),
('streets',         '0'),
('founded_year',    '1992'),
('maps_embed',      ''),
('meta_desc',       'Shakarqamish mahalla fuqarolar yig\'ini rasmiy sayti'),
('meta_keywords',   'shakarqamish, mahalla, oltinsoy, surxondaryo'),
('telegram_bot',    ''),
('telegram_chat',   ''),
('ticker_text',     'Mahalla portaliga xush kelibsiz! | Online murojaat xizmati ishlaydi | Yangi tadbirlar e\'loni yaqinda')
ON DUPLICATE KEY UPDATE `key`=`key`;

-- Kategoriyalar
CREATE TABLE IF NOT EXISTS `categories` (
  `id`        TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name_uz`   VARCHAR(100) NOT NULL,
  `name_cy`   VARCHAR(100) NOT NULL,
  `name_ru`   VARCHAR(100) NOT NULL,
  `slug`      VARCHAR(120) NOT NULL,
  `icon`      VARCHAR(30)  NOT NULL DEFAULT 'bi-folder',
  `color`     VARCHAR(20)  NOT NULL DEFAULT '#0A4DA6',
  `sort`      TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `categories` (`name_uz`,`name_cy`,`name_ru`,`slug`,`icon`,`color`,`sort`) VALUES
('Yangiliklar',           'Янгиликлар',           'Новости',                'yangiliklar',  'bi-newspaper',       '#0A4DA6', 1),
("E'lonlar",              'Эълонлар',             'Объявления',             'elonlar',      'bi-megaphone',       '#E8A320', 2),
('Tadbirlar',             'Тадбирлар',            'Мероприятия',            'tadbirlar',    'bi-calendar-event',  '#00B060', 3),
('Ijtimoiy yordam',       'Ижтимоий ёрдам',       'Социальная помощь',      'yordam',       'bi-heart',           '#E02020', 4),
('Qarorlar',              'Қарорлар',             'Решения',                'qarorlar',     'bi-file-text',       '#6610f2', 5),
('Yoshlar',               'Ёшлар',                'Молодёжь',               'yoshlar',      'bi-people',          '#0dcaf0', 6),
('Ayollar',               'Аёллар',               'Женщины',                'ayollar',      'bi-gender-female',   '#d63384', 7),
('Sport',                 'Спорт',                'Спорт',                  'sport',        'bi-trophy',          '#ffc107', 8)
ON DUPLICATE KEY UPDATE `name_uz`=VALUES(`name_uz`);

-- Postlar (Yangiliklar + E'lonlar)
CREATE TABLE IF NOT EXISTS `posts` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `cat_id`      TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `admin_id`    TINYINT UNSIGNED NOT NULL DEFAULT 1,
  `title_uz`    VARCHAR(300) NOT NULL,
  `title_cy`    VARCHAR(300) DEFAULT NULL,
  `title_ru`    VARCHAR(300) DEFAULT NULL,
  `slug`        VARCHAR(320) NOT NULL,
  `body_uz`     LONGTEXT NOT NULL,
  `body_cy`     LONGTEXT DEFAULT NULL,
  `body_ru`     LONGTEXT DEFAULT NULL,
  `image`       VARCHAR(500) DEFAULT NULL,
  `views`       INT UNSIGNED NOT NULL DEFAULT 0,
  `is_pinned`   TINYINT(1) NOT NULL DEFAULT 0,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `status`      ENUM('draft','published') NOT NULL DEFAULT 'published',
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_slug` (`slug`),
  KEY `idx_cat`    (`cat_id`),
  KEY `idx_status` (`status`),
  KEY `idx_pinned` (`is_pinned`),
  FULLTEXT KEY `ft_search` (`title_uz`,`body_uz`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Xodimlar
CREATE TABLE IF NOT EXISTS `staff` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fullname`      VARCHAR(150) NOT NULL,
  `position_uz`   VARCHAR(150) NOT NULL,
  `position_cy`   VARCHAR(150) DEFAULT NULL,
  `position_ru`   VARCHAR(150) DEFAULT NULL,
  `phone`         VARCHAR(20)  DEFAULT NULL,
  `email`         VARCHAR(100) DEFAULT NULL,
  `telegram`      VARCHAR(50)  DEFAULT NULL,
  `photo`         VARCHAR(500) DEFAULT NULL,
  `bio_uz`        TEXT DEFAULT NULL,
  `bio_cy`        TEXT DEFAULT NULL,
  `bio_ru`        TEXT DEFAULT NULL,
  `reception`     VARCHAR(200) DEFAULT NULL,
  `sort`          TINYINT NOT NULL DEFAULT 0,
  `is_active`     TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Murojaatlar
CREATE TABLE IF NOT EXISTS `appeals` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `ticket`       VARCHAR(20)  NOT NULL,
  `fullname`     VARCHAR(150) NOT NULL,
  `phone`        VARCHAR(20)  NOT NULL,
  `address`      VARCHAR(300) DEFAULT NULL,
  `type`         VARCHAR(50)  NOT NULL DEFAULT 'ariza',
  `subject`      VARCHAR(300) NOT NULL,
  `body`         TEXT NOT NULL,
  `priority`     ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `status`       ENUM('new','processing','resolved','rejected') NOT NULL DEFAULT 'new',
  `is_anon`      TINYINT(1) NOT NULL DEFAULT 0,
  `file`         VARCHAR(500) DEFAULT NULL,
  `ip`           VARCHAR(45)  DEFAULT NULL,
  `reply`        TEXT DEFAULT NULL,
  `replied_at`   DATETIME DEFAULT NULL,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_ticket` (`ticket`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Galereya
CREATE TABLE IF NOT EXISTS `gallery` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title_uz`   VARCHAR(200) DEFAULT NULL,
  `title_ru`   VARCHAR(200) DEFAULT NULL,
  `image`      VARCHAR(500) NOT NULL,
  `album`      VARCHAR(100) DEFAULT NULL,
  `sort`       SMALLINT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Hujjatlar
CREATE TABLE IF NOT EXISTS `documents` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title_uz`    VARCHAR(300) NOT NULL,
  `title_ru`    VARCHAR(300) DEFAULT NULL,
  `file`        VARCHAR(500) NOT NULL,
  `size`        INT UNSIGNED DEFAULT 0,
  `downloads`   INT UNSIGNED DEFAULT 0,
  `cat`         VARCHAR(100) DEFAULT NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Slayder
CREATE TABLE IF NOT EXISTS `sliders` (
  `id`        SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title_uz`  VARCHAR(200) DEFAULT NULL,
  `title_ru`  VARCHAR(200) DEFAULT NULL,
  `subtitle`  VARCHAR(300) DEFAULT NULL,
  `image`     VARCHAR(500) NOT NULL,
  `link`      VARCHAR(500) DEFAULT NULL,
  `sort`      TINYINT NOT NULL DEFAULT 0,
  `is_active` TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tadbirlar
CREATE TABLE IF NOT EXISTS `events` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title_uz`    VARCHAR(300) NOT NULL,
  `title_ru`    VARCHAR(300) DEFAULT NULL,
  `body_uz`     TEXT DEFAULT NULL,
  `body_ru`     TEXT DEFAULT NULL,
  `image`       VARCHAR(500) DEFAULT NULL,
  `location`    VARCHAR(300) DEFAULT NULL,
  `event_date`  DATETIME NOT NULL,
  `status`      ENUM('upcoming','done','cancelled') NOT NULL DEFAULT 'upcoming',
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Ovoz berish
CREATE TABLE IF NOT EXISTS `polls` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `question_uz` VARCHAR(500) NOT NULL,
  `question_ru` VARCHAR(500) DEFAULT NULL,
  `options`    JSON NOT NULL,
  `votes`      JSON DEFAULT NULL,
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  `expires_at` DATE DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `poll_votes` (
  `id`      INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `poll_id` INT UNSIGNED NOT NULL,
  `opt`     TINYINT NOT NULL,
  `ip`      VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_poll_ip` (`poll_id`,`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- FAQ
CREATE TABLE IF NOT EXISTS `faqs` (
  `id`         SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `q_uz`       VARCHAR(400) NOT NULL,
  `q_ru`       VARCHAR(400) DEFAULT NULL,
  `a_uz`       TEXT NOT NULL,
  `a_ru`       TEXT DEFAULT NULL,
  `sort`       TINYINT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Adminlar
CREATE TABLE IF NOT EXISTS `admins` (
  `id`           TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fullname`     VARCHAR(150) NOT NULL,
  `username`     VARCHAR(50)  NOT NULL,
  `email`        VARCHAR(100) NOT NULL,
  `password`     VARCHAR(255) NOT NULL,
  `role`         ENUM('superadmin','admin','moderator') NOT NULL DEFAULT 'admin',
  `is_active`    TINYINT(1) NOT NULL DEFAULT 1,
  `last_login`   DATETIME DEFAULT NULL,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Default admin: login=admin, pass=Admin@2025!
INSERT INTO `admins` (`fullname`,`username`,`email`,`password`,`role`)
SELECT 'Super Admin','admin','admin@shakarqamishmfy.uz','$2y$12$eK8V.G5UdpQF3hDW6uJsBuaGTmE4sMUcXqOQSMI2QBlX9.lv7Pxhe','superadmin'
WHERE NOT EXISTS (SELECT 1 FROM `admins` WHERE username='admin');
-- parol: Admin@2025!

-- Loglar
CREATE TABLE IF NOT EXISTS `logs` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `admin_id`   TINYINT UNSIGNED DEFAULT NULL,
  `action`     VARCHAR(100) NOT NULL,
  `ip`         VARCHAR(45) DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
