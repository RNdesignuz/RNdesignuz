<?php
require_once __DIR__ . '/config.php';

// ============================================================
// ROUTING
// ============================================================
$uri = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');

// Login sahifasi
if ($uri === '/admin/login' || $uri === '/admin/login.php') {
    handleLogin();
    exit;
}

// Logout
if ($uri === '/admin/logout' || !empty($_GET['logout'])) {
    if (!empty($_SESSION['admin_id'])) {
        ins('logs', ['admin_id' => $_SESSION['admin_id'], 'action' => 'logout', 'ip' => $_SERVER['REMOTE_ADDR'] ?? '']);
        q("UPDATE admins SET last_login=NOW() WHERE id=?", [$_SESSION['admin_id']]);
    }
    session_destroy();
    header('Location: /admin/login');
    exit;
}

requireAdmin();
$admin = row("SELECT * FROM admins WHERE id=?", [$_SESSION['admin_id']]);

$mod = $_GET['m'] ?? 'dashboard';
$act = $_GET['a'] ?? '';
$id  = (int)($_GET['id'] ?? 0);

// ============================================================
// AJAX / POST handlers
// ============================================================
if (!empty($_POST['ajax'])) {
    handleAjax($mod, $act, $id, $admin);
    exit;
}

// ============================================================
// LOGIN
// ============================================================
function handleLogin(): void {
    if (isAdmin()) { header('Location: /admin'); exit; }

    $err = '';
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        $ip   = $_SERVER['REMOTE_ADDR'] ?? '';

        // Rate limit: 5 urinish
        $lockKey = 'login_' . md5($ip);
        $attempts = (int)($_SESSION[$lockKey] ?? 0);
        $lockedUntil = (int)($_SESSION[$lockKey . '_until'] ?? 0);

        if ($lockedUntil > time()) {
            $err = ceil(($lockedUntil - time()) / 60) . " daqiqa kutib turing";
        } elseif (!$user || !$pass) {
            $err = "Login va parolni kiriting";
        } else {
            $adm = row("SELECT * FROM admins WHERE (username=? OR email=?) AND is_active=1", [$user, $user]);
            if ($adm && password_verify($pass, $adm['password'])) {
                $_SESSION[$lockKey] = 0;
                session_regenerate_id(true);
                $_SESSION['admin_id']   = $adm['id'];
                $_SESSION['admin_role'] = $adm['role'];
                ins('logs', ['admin_id' => $adm['id'], 'action' => 'login', 'ip' => $ip]);
                header('Location: /admin');
                exit;
            } else {
                $attempts++;
                $_SESSION[$lockKey] = $attempts;
                if ($attempts >= 5) {
                    $_SESSION[$lockKey . '_until'] = time() + 15 * 60;
                    $err = "Hisob 15 daqiqaga bloklandi";
                } else {
                    $err = "Login yoki parol noto'g'ri. " . (5 - $attempts) . " urinish qoldi";
                }
            }
        }
    }
    renderLogin($err);
}

// ============================================================
// AJAX HANDLER
// ============================================================
function handleAjax(string $mod, string $act, int $id, array $admin): void {
    // Posts
    if ($mod === 'posts') {
        if ($act === 'save') savePo($admin);
        if ($act === 'delete' && $id) { q("DELETE FROM posts WHERE id=?", [$id]); log_act($admin['id'], 'delete_post', $id); jsonOut(['ok' => true]); }
        if ($act === 'toggle_pin' && $id) {
            $cur = val("SELECT is_pinned FROM posts WHERE id=?", [$id]);
            upd('posts', ['is_pinned' => $cur ? 0 : 1], 'id=?', [$id]);
            jsonOut(['ok' => true, 'pinned' => !$cur]);
        }
        if ($act === 'toggle_status' && $id) {
            $cur = val("SELECT status FROM posts WHERE id=?", [$id]);
            $new = $cur === 'published' ? 'draft' : 'published';
            upd('posts', ['status' => $new], 'id=?', [$id]);
            jsonOut(['ok' => true, 'status' => $new]);
        }
    }
    // Appeals
    if ($mod === 'appeals') {
        if ($act === 'reply' && $id) {
            $reply = trim($_POST['reply'] ?? '');
            $status = $_POST['status'] ?? 'processing';
            if (!$reply) jsonOut(['ok' => false, 'msg' => 'Javob kiriting']);
            upd('appeals', ['reply' => $reply, 'status' => $status, 'replied_at' => date('Y-m-d H:i:s')], 'id=?', [$id]);
            log_act($admin['id'], 'reply_appeal', $id);
            jsonOut(['ok' => true]);
        }
        if ($act === 'status' && $id) {
            $status = $_POST['status'] ?? 'new';
            $ok = ['new', 'processing', 'resolved', 'rejected'];
            if (!in_array($status, $ok)) jsonOut(['ok' => false, 'msg' => 'Noto\'g\'ri holat']);
            upd('appeals', ['status' => $status], 'id=?', [$id]);
            jsonOut(['ok' => true]);
        }
    }
    // Staff
    if ($mod === 'staff') {
        if ($act === 'save') saveStaff($admin);
        if ($act === 'delete' && $id) { q("DELETE FROM staff WHERE id=?", [$id]); jsonOut(['ok' => true]); }
    }
    // Gallery
    if ($mod === 'gallery') {
        if ($act === 'upload') uploadGallery($admin);
        if ($act === 'delete' && $id) {
            $g = row("SELECT image FROM gallery WHERE id=?", [$id]);
            if ($g && file_exists(__DIR__ . '/' . $g['image'])) @unlink(__DIR__ . '/' . $g['image']);
            q("DELETE FROM gallery WHERE id=?", [$id]);
            jsonOut(['ok' => true]);
        }
    }
    // Hujjatlar
    if ($mod === 'documents') {
        if ($act === 'upload') uploadDoc($admin);
        if ($act === 'delete' && $id) {
            $d = row("SELECT file FROM documents WHERE id=?", [$id]);
            if ($d && file_exists(__DIR__ . '/' . $d['file'])) @unlink(__DIR__ . '/' . $d['file']);
            q("DELETE FROM documents WHERE id=?", [$id]);
            jsonOut(['ok' => true]);
        }
    }
    // Sliders
    if ($mod === 'sliders') {
        if ($act === 'save') saveSlider($admin);
        if ($act === 'delete' && $id) {
            $s = row("SELECT image FROM sliders WHERE id=?", [$id]);
            if ($s && file_exists(__DIR__ . '/' . $s['image'])) @unlink(__DIR__ . '/' . $s['image']);
            q("DELETE FROM sliders WHERE id=?", [$id]);
            jsonOut(['ok' => true]);
        }
        if ($act === 'toggle' && $id) {
            $cur = val("SELECT is_active FROM sliders WHERE id=?", [$id]);
            upd('sliders', ['is_active' => $cur ? 0 : 1], 'id=?', [$id]);
            jsonOut(['ok' => true]);
        }
    }
    // Settings
    if ($mod === 'settings' && $act === 'save') {
        foreach ($_POST as $k => $v) {
            if ($k === 'ajax') continue;
            $exists = val("SELECT COUNT(*) FROM settings WHERE `key`=?", [$k]);
            if ($exists) upd('settings', ['value' => $v], '`key`=?', [$k]);
            else ins('settings', ['key' => $k, 'value' => $v]);
        }
        log_act($admin['id'], 'update_settings');
        jsonOut(['ok' => true]);
    }
    // Staff
    if ($mod === 'staff' && $act === 'toggle' && $id) {
        $cur = val("SELECT is_active FROM staff WHERE id=?", [$id]);
        upd('staff', ['is_active' => $cur ? 0 : 1], 'id=?', [$id]);
        jsonOut(['ok' => true]);
    }
    // FAQ
    if ($mod === 'faq') {
        if ($act === 'save') saveFaq();
        if ($act === 'delete' && $id) { q("DELETE FROM faqs WHERE id=?", [$id]); jsonOut(['ok' => true]); }
    }
    // Events
    if ($mod === 'events') {
        if ($act === 'save') saveEvent();
        if ($act === 'delete' && $id) { q("DELETE FROM events WHERE id=?", [$id]); jsonOut(['ok' => true]); }
    }
    // Polls
    if ($mod === 'polls') {
        if ($act === 'save') savePoll();
        if ($act === 'delete' && $id) { q("DELETE FROM polls WHERE id=?", [$id]); q("DELETE FROM poll_votes WHERE poll_id=?", [$id]); jsonOut(['ok' => true]); }
        if ($act === 'toggle' && $id) {
            $cur = val("SELECT is_active FROM polls WHERE id=?", [$id]);
            upd('polls', ['is_active' => $cur ? 0 : 1], 'id=?', [$id]);
            jsonOut(['ok' => true]);
        }
    }
    // Admins
    if ($mod === 'admins') {
        if ($act === 'save') saveAdmin($admin);
        if ($act === 'delete' && $id && $id !== $admin['id']) { q("DELETE FROM admins WHERE id=?", [$id]); jsonOut(['ok' => true]); }
    }
    jsonOut(['ok' => false, 'msg' => 'Noma\'lum amal']);
}

// ============================================================
// SAVE FUNCTIONS
// ============================================================
function savePo(array $admin): void {
    $id       = (int)($_POST['id'] ?? 0);
    $title_uz = trim($_POST['title_uz'] ?? '');
    $title_cy = trim($_POST['title_cy'] ?? '');
    $title_ru = trim($_POST['title_ru'] ?? '');
    $body_uz  = $_POST['body_uz'] ?? '';
    $body_cy  = $_POST['body_cy'] ?? '';
    $body_ru  = $_POST['body_ru'] ?? '';
    $cat_id   = (int)($_POST['cat_id'] ?? 1);
    $status   = $_POST['status'] ?? 'published';
    $is_pinned   = !empty($_POST['is_pinned'])   ? 1 : 0;
    $is_featured = !empty($_POST['is_featured']) ? 1 : 0;

    if (!$title_uz) jsonOut(['ok' => false, 'msg' => 'Sarlavha kiriting']);
    if (!$body_uz)  jsonOut(['ok' => false, 'msg' => 'Matn kiriting']);

    $slug = uslug($title_uz, 'posts', $id);

    $image = $id ? val("SELECT image FROM posts WHERE id=?", [$id]) : null;
    if (!empty($_FILES['image']['tmp_name'])) {
        $up = uploadFile($_FILES['image'], 'posts');
        if ($up) $image = $up;
    }

    $d = compact('title_uz','title_cy','title_ru','body_uz','body_cy','body_ru','cat_id','status','slug','is_pinned','is_featured','image');

    if ($id) {
        upd('posts', $d, 'id=?', [$id]);
        log_act($admin['id'], 'update_post', $id);
        jsonOut(['ok' => true, 'id' => $id]);
    } else {
        $d['admin_id'] = $admin['id'];
        $newId = ins('posts', $d);
        log_act($admin['id'], 'create_post', $newId);
        jsonOut(['ok' => true, 'id' => $newId]);
    }
}

function saveStaff(array $admin): void {
    $id           = (int)($_POST['id'] ?? 0);
    $fullname     = trim($_POST['fullname'] ?? '');
    $position_uz  = trim($_POST['position_uz'] ?? '');
    $position_cy  = trim($_POST['position_cy'] ?? '');
    $position_ru  = trim($_POST['position_ru'] ?? '');
    $phone        = trim($_POST['phone'] ?? '');
    $email        = trim($_POST['email'] ?? '');
    $telegram     = trim($_POST['telegram'] ?? '');
    $reception    = trim($_POST['reception'] ?? '');
    $bio_uz       = $_POST['bio_uz'] ?? '';
    $bio_cy       = $_POST['bio_cy'] ?? '';
    $bio_ru       = $_POST['bio_ru'] ?? '';
    $sort         = (int)($_POST['sort'] ?? 0);

    if (!$fullname) jsonOut(['ok' => false, 'msg' => 'Ism kiriting']);

    $photo = $id ? val("SELECT photo FROM staff WHERE id=?", [$id]) : null;
    if (!empty($_FILES['photo']['tmp_name'])) {
        $up = uploadFile($_FILES['photo'], 'staff');
        if ($up) $photo = $up;
    }

    $d = compact('fullname','position_uz','position_cy','position_ru','phone','email','telegram','reception','bio_uz','bio_cy','bio_ru','sort','photo');
    if ($id) { upd('staff', $d, 'id=?', [$id]); jsonOut(['ok' => true]); }
    else { ins('staff', $d); jsonOut(['ok' => true]); }
}

function uploadGallery(array $admin): void {
    if (empty($_FILES['images'])) jsonOut(['ok' => false, 'msg' => 'Fayl tanlanmadi']);
    $album   = trim($_POST['album'] ?? '');
    $title   = trim($_POST['title_uz'] ?? '');
    $success = 0;
    $files   = $_FILES['images'];
    // Bir nechta fayl
    $count = is_array($files['name']) ? count($files['name']) : 1;
    for ($i = 0; $i < $count; $i++) {
        $file = is_array($files['name']) ? [
            'name'     => $files['name'][$i],
            'type'     => $files['type'][$i],
            'tmp_name' => $files['tmp_name'][$i],
            'error'    => $files['error'][$i],
            'size'     => $files['size'][$i],
        ] : $files;
        $path = uploadFile($file, 'gallery');
        if ($path) {
            ins('gallery', ['image' => $path, 'title_uz' => $title, 'album' => $album ?: null]);
            $success++;
        }
    }
    jsonOut(['ok' => true, 'count' => $success]);
}

function uploadDoc(array $admin): void {
    if (empty($_FILES['file'])) jsonOut(['ok' => false, 'msg' => 'Fayl tanlanmadi']);
    $title = trim($_POST['title_uz'] ?? '');
    $cat   = trim($_POST['cat'] ?? '');
    if (!$title) jsonOut(['ok' => false, 'msg' => 'Sarlavha kiriting']);
    $path = uploadFile($_FILES['file'], 'documents');
    if (!$path) jsonOut(['ok' => false, 'msg' => 'Fayl yuklanmadi (max 8MB, pdf/doc/xls)']);
    $size = $_FILES['file']['size'];
    ins('documents', ['title_uz' => $title, 'title_ru' => trim($_POST['title_ru'] ?? ''), 'file' => $path, 'size' => $size, 'cat' => $cat ?: null]);
    jsonOut(['ok' => true]);
}

function saveSlider(array $admin): void {
    $id       = (int)($_POST['id'] ?? 0);
    $title_uz = trim($_POST['title_uz'] ?? '');
    $title_ru = trim($_POST['title_ru'] ?? '');
    $subtitle = trim($_POST['subtitle'] ?? '');
    $link     = trim($_POST['link'] ?? '');
    $sort     = (int)($_POST['sort'] ?? 0);

    $image = $id ? val("SELECT image FROM sliders WHERE id=?", [$id]) : null;
    if (!empty($_FILES['image']['tmp_name'])) {
        $up = uploadFile($_FILES['image'], 'sliders');
        if ($up) $image = $up;
    }
    if (!$image && !$id) jsonOut(['ok' => false, 'msg' => 'Rasm tanlang']);

    $d = compact('title_uz','title_ru','subtitle','link','sort','image');
    if ($id) { upd('sliders', $d, 'id=?', [$id]); jsonOut(['ok' => true]); }
    else { ins('sliders', $d); jsonOut(['ok' => true]); }
}

function saveFaq(): void {
    $id   = (int)($_POST['id'] ?? 0);
    $q_uz = trim($_POST['q_uz'] ?? '');
    $q_ru = trim($_POST['q_ru'] ?? '');
    $a_uz = trim($_POST['a_uz'] ?? '');
    $a_ru = trim($_POST['a_ru'] ?? '');
    $sort = (int)($_POST['sort'] ?? 0);
    if (!$q_uz || !$a_uz) jsonOut(['ok' => false, 'msg' => 'Savol va javob kiriting']);
    $d = compact('q_uz','q_ru','a_uz','a_ru','sort');
    if ($id) { upd('faqs', $d, 'id=?', [$id]); jsonOut(['ok' => true]); }
    else { ins('faqs', $d); jsonOut(['ok' => true]); }
}

function saveEvent(): void {
    $id       = (int)($_POST['id'] ?? 0);
    $title_uz = trim($_POST['title_uz'] ?? '');
    $title_ru = trim($_POST['title_ru'] ?? '');
    $body_uz  = trim($_POST['body_uz'] ?? '');
    $location = trim($_POST['location'] ?? '');
    $event_date = trim($_POST['event_date'] ?? '');
    $status   = $_POST['status'] ?? 'upcoming';
    if (!$title_uz || !$event_date) jsonOut(['ok' => false, 'msg' => 'Sarlavha va sana kiriting']);
    $image = $id ? val("SELECT image FROM events WHERE id=?", [$id]) : null;
    if (!empty($_FILES['image']['tmp_name'])) { $up=uploadFile($_FILES['image'],'events'); if($up) $image=$up; }
    $d = compact('title_uz','title_ru','body_uz','location','event_date','status','image');
    if ($id) { upd('events',$d,'id=?',[$id]); jsonOut(['ok'=>true]); }
    else { ins('events',$d); jsonOut(['ok'=>true]); }
}

function savePoll(): void {
    $id          = (int)($_POST['id'] ?? 0);
    $question_uz = trim($_POST['question_uz'] ?? '');
    $question_ru = trim($_POST['question_ru'] ?? '');
    $expires_at  = trim($_POST['expires_at'] ?? '') ?: null;
    if (!$question_uz) jsonOut(['ok'=>false,'msg'=>'Savol kiriting']);
    $opts = array_values(array_filter(array_map('trim', $_POST['options'] ?? []), fn($o)=>$o!==''));
    if (count($opts) < 2) jsonOut(['ok'=>false,'msg'=>'Kamida 2 variant kiriting']);
    $d = ['question_uz'=>$question_uz,'question_ru'=>$question_ru,'options'=>json_encode($opts),'expires_at'=>$expires_at];
    if ($id) { upd('polls',$d,'id=?',[$id]); jsonOut(['ok'=>true]); }
    else { $d['is_active']=1; ins('polls',$d); jsonOut(['ok'=>true]); }
}

function saveAdmin(array $cur): void {
    $id       = (int)($_POST['id'] ?? 0);
    $fullname = trim($_POST['fullname'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $role     = $_POST['role'] ?? 'admin';
    $pass     = $_POST['password'] ?? '';
    if (!$fullname||!$username||!$email) jsonOut(['ok'=>false,'msg'=>'Barcha majburiy maydonlarni to\'ldiring']);
    $d = ['fullname'=>$fullname,'username'=>$username,'email'=>$email,'role'=>$role];
    if ($pass) $d['password'] = password_hash($pass, PASSWORD_BCRYPT, ['cost'=>12]);
    if ($id) {
        if ($id===$cur['id']&&$role==='moderator') jsonOut(['ok'=>false,'msg'=>'O\'z rolingizni o\'zgartira olmaysiz']);
        upd('admins',$d,'id=?',[$id]); jsonOut(['ok'=>true]);
    } else {
        if (!$pass) jsonOut(['ok'=>false,'msg'=>'Yangi admin uchun parol kiriting']);
        ins('admins',$d); jsonOut(['ok'=>true]);
    }
}

function log_act(int $adminId, string $action, ?int $entityId = null): void {
    ins('logs', ['admin_id'=>$adminId,'action'=>$action,'ip'=>$_SERVER['REMOTE_ADDR']??'']);
}

// ============================================================
// DATA per module
// ============================================================
$pageData = [];
$pageTitle = 'Dashboard';

if ($mod === 'dashboard') {
    $pageTitle = 'Dashboard';
    $pageData = [
        'posts_total'   => val("SELECT COUNT(*) FROM posts WHERE status='published'"),
        'posts_draft'   => val("SELECT COUNT(*) FROM posts WHERE status='draft'"),
        'appeals_new'   => val("SELECT COUNT(*) FROM appeals WHERE status='new'"),
        'appeals_total' => val("SELECT COUNT(*) FROM appeals"),
        'staff_total'   => val("SELECT COUNT(*) FROM staff WHERE is_active=1"),
        'gallery_total' => val("SELECT COUNT(*) FROM gallery"),
        'recent_appeals'=> rows("SELECT * FROM appeals ORDER BY created_at DESC LIMIT 8"),
        'recent_posts'  => rows("SELECT p.*,c.name_uz FROM posts p JOIN categories c ON c.id=p.cat_id ORDER BY p.created_at DESC LIMIT 6"),
        'logs'          => rows("SELECT l.*,a.fullname FROM logs l LEFT JOIN admins a ON a.id=l.admin_id ORDER BY l.created_at DESC LIMIT 10"),
    ];
} elseif ($mod === 'posts') {
    $pageTitle = 'Postlar';
    $catF = (int)($_GET['cat'] ?? 0);
    $statusF = $_GET['status'] ?? '';
    $where = '1'; $params = [];
    if ($catF) { $where .= ' AND p.cat_id=?'; $params[] = $catF; }
    if ($statusF) { $where .= ' AND p.status=?'; $params[] = $statusF; }
    $pg = max(1,(int)($_GET['pg']??1)); $lim=20;
    $pageData = [
        'posts'  => rows("SELECT p.*,c.name_uz FROM posts p JOIN categories c ON c.id=p.cat_id WHERE $where ORDER BY p.created_at DESC LIMIT $lim OFFSET ".($pg-1)*$lim, $params),
        'total'  => (int)val("SELECT COUNT(*) FROM posts p WHERE $where", $params),
        'cats'   => rows("SELECT * FROM categories ORDER BY sort"),
        'catF'   => $catF, 'statusF'=>$statusF, 'pg'=>$pg, 'lim'=>$lim,
        'edit'   => $id ? row("SELECT * FROM posts WHERE id=?",[$id]) : null,
    ];
    if ($act === 'new') $pageData['edit'] = ['id'=>0];
} elseif ($mod === 'appeals') {
    $pageTitle = 'Murojaatlar';
    $statusF = $_GET['status'] ?? '';
    $typeF   = $_GET['type']   ?? '';
    $where='1';$params=[];
    if($statusF){$where.=' AND status=?';$params[]=$statusF;}
    if($typeF){$where.=' AND type=?';$params[]=$typeF;}
    $pg=max(1,(int)($_GET['pg']??1));$lim=20;
    $pageData=[
        'appeals'=>rows("SELECT * FROM appeals WHERE $where ORDER BY FIELD(status,'new','processing','resolved','rejected'),created_at DESC LIMIT $lim OFFSET ".($pg-1)*$lim,$params),
        'total'=>(int)val("SELECT COUNT(*) FROM appeals WHERE $where",$params),
        'statusF'=>$statusF,'typeF'=>$typeF,'pg'=>$pg,'lim'=>$lim,
        'single'=>$id?row("SELECT * FROM appeals WHERE id=?",[$id]):null,
    ];
} elseif ($mod === 'staff') {
    $pageTitle='Xodimlar';
    $pageData=['staff'=>rows("SELECT * FROM staff ORDER BY sort,created_at"),'edit'=>$id?row("SELECT * FROM staff WHERE id=?",[$id]):null];
    if($act==='new') $pageData['edit']=['id'=>0];
} elseif ($mod === 'gallery') {
    $pageTitle='Galereya';
    $pageData=['photos'=>rows("SELECT * FROM gallery ORDER BY created_at DESC"),'albums'=>rows("SELECT DISTINCT album FROM gallery WHERE album IS NOT NULL ORDER BY album")];
} elseif ($mod === 'documents') {
    $pageTitle='Hujjatlar';
    $pageData=['docs'=>rows("SELECT * FROM documents ORDER BY created_at DESC")];
} elseif ($mod === 'sliders') {
    $pageTitle='Slayder';
    $pageData=['sliders'=>rows("SELECT * FROM sliders ORDER BY sort"),'edit'=>$id?row("SELECT * FROM sliders WHERE id=?",[$id]):null];
    if($act==='new') $pageData['edit']=['id'=>0];
} elseif ($mod === 'settings') {
    $pageTitle='Sozlamalar';
    $s=[];
    foreach(rows("SELECT `key`,`value` FROM settings") as $r) $s[$r['key']]=$r['value'];
    $pageData['s']=$s;
} elseif ($mod === 'faq') {
    $pageTitle='FAQ';
    $pageData=['faqs'=>rows("SELECT * FROM faqs ORDER BY sort"),'edit'=>$id?row("SELECT * FROM faqs WHERE id=?",[$id]):null];
    if($act==='new') $pageData['edit']=['id'=>0];
} elseif ($mod === 'events') {
    $pageTitle='Tadbirlar';
    $pageData=['events'=>rows("SELECT * FROM events ORDER BY event_date DESC"),'edit'=>$id?row("SELECT * FROM events WHERE id=?",[$id]):null];
    if($act==='new') $pageData['edit']=['id'=>0];
} elseif ($mod === 'polls') {
    $pageTitle='So\'rovnomalar';
    $pageData=['polls'=>rows("SELECT * FROM polls ORDER BY created_at DESC")];
} elseif ($mod === 'admins') {
    $pageTitle='Adminlar';
    $pageData=['admins'=>rows("SELECT id,fullname,username,email,role,is_active,last_login,created_at FROM admins ORDER BY id"),'edit'=>$id?row("SELECT id,fullname,username,email,role FROM admins WHERE id=?",[$id]):null];
    if($act==='new') $pageData['edit']=['id'=>0];
} elseif ($mod === 'logs') {
    $pageTitle='Loglar';
    $pageData=['logs'=>rows("SELECT l.*,a.fullname FROM logs l LEFT JOIN admins a ON a.id=l.admin_id ORDER BY l.created_at DESC LIMIT 100")];
}

$cats_all = rows("SELECT * FROM categories ORDER BY sort");
$appeals_new_count = (int)val("SELECT COUNT(*) FROM appeals WHERE status='new'");

// ============================================================
// RENDER LOGIN
// ============================================================
function renderLogin(string $err): void { ?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Kirish — ShakarqamishMFY</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Inter',system-ui,sans-serif;background:#0D1117;color:#E6EDF3;min-height:100vh;display:flex;align-items:center;justify-content:center}
body::before{content:'';position:fixed;inset:0;background:radial-gradient(ellipse at 30% 20%,rgba(31,111,235,.12),transparent 60%)}
.card{background:#161B22;border:1px solid #30363D;border-radius:16px;padding:36px;width:100%;max-width:400px;position:relative;z-index:1}
.brand{text-align:center;margin-bottom:28px}
.brand-ico{width:60px;height:60px;border-radius:14px;background:linear-gradient(135deg,#1F6FEB,#1148B4);display:inline-flex;align-items:center;justify-content:center;font-size:1.6rem;color:#fff;margin-bottom:12px;box-shadow:0 8px 24px rgba(31,111,235,.35)}
.brand h1{font-size:1.2rem;font-weight:800;color:#E6EDF3}
.brand p{font-size:.75rem;color:#8B949E;margin-top:3px}
.err{background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.3);color:#F85149;padding:10px 14px;border-radius:8px;font-size:.83rem;margin-bottom:16px;display:flex;align-items:center;gap:8px}
.fg{margin-bottom:14px}
.fg label{display:block;font-size:.73rem;font-weight:700;color:#8B949E;text-transform:uppercase;letter-spacing:.5px;margin-bottom:6px}
.fi{width:100%;background:#0D1117;border:1.5px solid #30363D;border-radius:9px;padding:10px 14px;color:#E6EDF3;font-family:inherit;font-size:.9rem;outline:none;transition:border-color .2s}
.fi:focus{border-color:#1F6FEB}
.btn{width:100%;padding:12px;border-radius:9px;background:#1F6FEB;color:#fff;font-weight:700;font-size:.9rem;border:none;cursor:pointer;transition:background .2s;display:flex;align-items:center;justify-content:center;gap:8px;margin-top:4px}
.btn:hover{background:#1148B4}
.foot{text-align:center;margin-top:20px;font-size:.75rem;color:#484F58}
.foot a{color:#1F6FEB}
</style>
</head>
<body>
<div class="card">
  <div class="brand">
    <div class="brand-ico"><i class="bi bi-building-fill"></i></div>
    <h1>ShakarqamishMFY</h1>
    <p>Admin boshqaruv paneli</p>
  </div>
  <?php if($err): ?><div class="err"><i class="bi bi-shield-x"></i><?= h($err) ?></div><?php endif; ?>
  <form method="post">
    <div class="fg">
      <label>Login yoki Email</label>
      <input class="fi" type="text" name="username" placeholder="admin" autocomplete="username" autofocus>
    </div>
    <div class="fg">
      <label>Parol</label>
      <input class="fi" type="password" name="password" placeholder="••••••••" autocomplete="current-password">
    </div>
    <button class="btn" type="submit"><i class="bi bi-box-arrow-in-right"></i> Kirish</button>
  </form>
  <div class="foot"><a href="/">← Saytga qaytish</a></div>
</div>
</body>
</html>
<?php }

// ============================================================
// HELPERS for view
// ============================================================
function statusBadge(string $s): string {
    $m = ['new'=>['#1F6FEB','Yangi'],'processing'=>['#D97706',"Ko'rib chiqilmoqda"],'resolved'=>['#059669','Hal qilindi'],'rejected'=>['#DC2626','Rad etildi'],'published'=>['#059669','Chop etilgan'],'draft'=>['#6B7280','Qoralama'],'upcoming'=>['#1F6FEB','Kutilmoqda'],'done'=>['#059669','Tugallandi'],'cancelled'=>['#DC2626','Bekor qilindi']];
    $c = $m[$s] ?? ['#6B7280',$s];
    return "<span style='background:{$c[0]}20;color:{$c[0]};padding:3px 10px;border-radius:20px;font-size:.7rem;font-weight:700'>{$c[1]}</span>";
}
function priorityBadge(string $p): string {
    $m=['low'=>['#6B7280','Past'],'normal'=>['#1F6FEB','Oddiy'],'high'=>['#D97706','Muhim'],'urgent'=>['#DC2626','Shoshilinch']];
    $c=$m[$p]??['#6B7280',$p];
    return "<span style='color:{$c[0]};font-weight:700;font-size:.75rem'>{$c[1]}</span>";
}

// ============================================================
// RENDER ADMIN
// ============================================================
?>
<!DOCTYPE html>
<html lang="uz" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= h($pageTitle) ?> — Admin</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
:root{--bg:#0D1117;--bg2:#161B22;--bg3:#1C2333;--border:#30363D;--text:#E6EDF3;--text-m:#8B949E;--text-l:#484F58;--p:#1F6FEB;--pd:#1148B4;--a:#3FB950;--r:#F85149;--o:#E3B341;--pu:#8957E5;--radius:10px;--sw:240px;--tr:.2s ease;--font:'Inter',system-ui,sans-serif}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--font);background:var(--bg);color:var(--text);line-height:1.5;-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}
img{max-width:100%;display:block}
button,input,select,textarea{font-family:inherit;font-size:inherit}
button{cursor:pointer;border:none;background:none}
:focus-visible{outline:2px solid var(--p);outline-offset:2px}
/* Scrollbar */
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:var(--bg)}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:var(--text-l)}

/* SIDEBAR */
.sb{position:fixed;left:0;top:0;bottom:0;width:var(--sw);background:var(--bg2);border-right:1px solid var(--border);z-index:200;overflow-y:auto;transition:transform var(--tr);display:flex;flex-direction:column}
.sb-brand{padding:16px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;flex-shrink:0}
.sb-brand-ico{width:34px;height:34px;border-radius:8px;background:var(--p);display:flex;align-items:center;justify-content:center;color:#fff;font-size:.95rem;flex-shrink:0}
.sb-brand-name{font-weight:800;font-size:.88rem}
.sb-brand-sub{font-size:.65rem;color:var(--text-m)}
.sb-body{flex:1;padding:8px 6px;overflow-y:auto}
.sb-sec{padding:12px 8px 4px;font-size:.6rem;font-weight:700;color:var(--text-l);letter-spacing:.8px;text-transform:uppercase}
.nav-it{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:8px;margin-bottom:1px;font-size:.82rem;color:var(--text-m);transition:all var(--tr);cursor:pointer;position:relative}
.nav-it:hover{background:var(--bg3);color:var(--text)}
.nav-it.on{background:rgba(31,111,235,.12);color:var(--p)}
.nav-it.on::before{content:'';position:absolute;left:0;top:6px;bottom:6px;width:3px;border-radius:2px;background:var(--p)}
.nav-it i{font-size:.95rem;width:16px;text-align:center}
.nav-badge{margin-left:auto;background:var(--r);color:#fff;font-size:.62rem;font-weight:700;padding:2px 6px;border-radius:10px}
.sb-footer{padding:12px;border-top:1px solid var(--border);flex-shrink:0}
.sb-user{display:flex;align-items:center;gap:10px}
.sb-ava{width:32px;height:32px;border-radius:8px;background:var(--p);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800;font-size:.85rem;flex-shrink:0}
.sb-user-name{font-size:.8rem;font-weight:700}
.sb-user-role{font-size:.65rem;color:var(--text-m)}

/* MAIN */
.main{margin-left:var(--sw);min-height:100vh;display:flex;flex-direction:column}
@media(max-width:768px){.main{margin-left:0}.sb{transform:translateX(-100%)}.sb.open{transform:none}}

/* TOPBAR */
.tbar{position:sticky;top:0;z-index:100;background:rgba(13,17,23,.85);backdrop-filter:blur(10px);border-bottom:1px solid var(--border);padding:10px 20px;display:flex;align-items:center;gap:12px;flex-shrink:0}
.tbar-title{font-weight:700;font-size:.95rem;flex:1}
.tbar-acts{display:flex;align-items:center;gap:8px}
.ic-btn{width:34px;height:34px;border-radius:7px;border:1px solid var(--border);background:none;color:var(--text-m);font-size:.95rem;display:flex;align-items:center;justify-content:center;transition:all var(--tr)}
.ic-btn:hover{background:var(--bg3);color:var(--text)}
.mob-tog{display:none;background:none;border:1px solid var(--border);border-radius:8px;width:36px;height:36px;align-items:center;justify-content:center;color:var(--text);font-size:1.1rem}
@media(max-width:768px){.mob-tog{display:flex}}

/* CONTENT */
.cnt{padding:20px;flex:1}
@media(max-width:640px){.cnt{padding:12px}}

/* CARDS */
.card{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);overflow:hidden}
.card-hd{display:flex;align-items:center;justify-content:space-between;padding:14px 16px;border-bottom:1px solid var(--border)}
.card-title{font-weight:700;font-size:.88rem}
.card-body{padding:16px}

/* STAT CARDS */
.stat-row{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin-bottom:20px}
@media(min-width:640px){.stat-row{grid-template-columns:repeat(4,1fr)}}
.stat-c{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);padding:16px;display:flex;align-items:center;gap:12px}
.stat-ico{width:44px;height:44px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
.stat-val{font-size:1.6rem;font-weight:800;line-height:1}
.stat-lbl{font-size:.7rem;color:var(--text-m);margin-top:3px;font-weight:600}

/* TABLE */
.tbl-wrap{overflow-x:auto}
.tbl{width:100%;border-collapse:collapse;font-size:.82rem}
.tbl th{padding:9px 12px;text-align:left;font-size:.68rem;font-weight:700;color:var(--text-l);text-transform:uppercase;letter-spacing:.5px;border-bottom:1px solid var(--border);white-space:nowrap;background:var(--bg3)}
.tbl td{padding:10px 12px;border-bottom:1px solid var(--border)}
.tbl tr:last-child td{border-bottom:none}
.tbl tr:hover td{background:rgba(255,255,255,.02)}
.tbl td:first-child{font-weight:600}

/* BUTTONS */
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 14px;border-radius:7px;font-weight:600;font-size:.8rem;transition:all var(--tr);cursor:pointer;border:1px solid transparent;white-space:nowrap}
.btn-p{background:var(--p);color:#fff}
.btn-p:hover{background:var(--pd)}
.btn-a{background:var(--a);color:#fff}
.btn-a:hover{background:#2EA043}
.btn-r{background:rgba(248,81,73,.1);color:var(--r);border-color:rgba(248,81,73,.2)}
.btn-r:hover{background:var(--r);color:#fff}
.btn-sm{background:var(--bg3);color:var(--text-m);border-color:var(--border)}
.btn-sm:hover{background:var(--border);color:var(--text)}
.btn-o{background:rgba(227,179,65,.1);color:var(--o);border-color:rgba(227,179,65,.2)}
.btn-o:hover{background:var(--o);color:#000}
.btn-sm-ic{width:30px;height:30px;padding:0;border-radius:6px;display:inline-flex;align-items:center;justify-content:center}

/* FORM */
.fg{margin-bottom:14px}
.fl{display:block;font-size:.73rem;font-weight:700;color:var(--text-m);margin-bottom:5px;text-transform:uppercase;letter-spacing:.4px}
.fi{width:100%;background:var(--bg);border:1.5px solid var(--border);border-radius:8px;padding:9px 12px;color:var(--text);font-size:.85rem;outline:none;transition:border-color var(--tr)}
.fi:focus{border-color:var(--p)}
.fi option{background:var(--bg2)}
textarea.fi{resize:vertical;min-height:80px}
.frow{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media(max-width:480px){.frow{grid-template-columns:1fr}}

/* TABS */
.tabs{display:flex;gap:0;border-bottom:1px solid var(--border);margin-bottom:16px;overflow-x:auto}
.tab{padding:9px 16px;font-size:.82rem;font-weight:600;color:var(--text-m);cursor:pointer;border-bottom:2px solid transparent;white-space:nowrap;transition:all var(--tr)}
.tab.on{color:var(--p);border-bottom-color:var(--p)}
.tab:hover{color:var(--text)}

/* PAGINATION */
.pag{display:flex;gap:4px;flex-wrap:wrap;margin-top:16px}
.pag a,.pag span{min-width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;border:1px solid var(--border);font-size:.78rem;font-weight:700;padding:0 8px}
.pag a:hover,.pag .on{background:var(--p);color:#fff;border-color:var(--p)}

/* MODAL */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:500;display:none;align-items:center;justify-content:center;padding:16px}
.modal-bg.open{display:flex}
.modal{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);width:100%;max-width:640px;max-height:90vh;display:flex;flex-direction:column}
.modal-hd{display:flex;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--border);flex-shrink:0}
.modal-title{font-weight:700;font-size:.92rem}
.modal-body{padding:18px;overflow-y:auto;flex:1}
.modal-ft{padding:14px 18px;border-top:1px solid var(--border);display:flex;gap:8px;justify-content:flex-end;flex-shrink:0;flex-wrap:wrap}

/* ALERT */
.alert{padding:10px 14px;border-radius:8px;font-size:.82rem;display:flex;align-items:center;gap:8px;margin-bottom:12px}
.alert-ok{background:rgba(63,185,80,.1);border:1px solid rgba(63,185,80,.2);color:var(--a)}
.alert-err{background:rgba(248,81,73,.1);border:1px solid rgba(248,81,73,.2);color:var(--r)}
.alert-info{background:rgba(31,111,235,.1);border:1px solid rgba(31,111,235,.2);color:var(--p)}

/* Toast */
.toast{position:fixed;bottom:20px;right:20px;z-index:1000;background:var(--bg2);border:1px solid var(--border);padding:12px 16px;border-radius:10px;font-size:.83rem;font-weight:600;box-shadow:0 8px 24px rgba(0,0,0,.4);transform:translateY(60px);opacity:0;transition:all .3s ease;display:flex;align-items:center;gap:8px;max-width:300px}
.toast.show{transform:translateY(0);opacity:1}

/* Upload area */
.upload-area{border:2px dashed var(--border);border-radius:var(--radius);padding:28px;text-align:center;cursor:pointer;transition:all var(--tr)}
.upload-area:hover,.upload-area.drag{border-color:var(--p);background:rgba(31,111,235,.04)}
.upload-area input{display:none}
.upload-ico{font-size:2rem;color:var(--text-l);margin-bottom:8px}

/* Photo grid */
.photo-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:8px}
.photo-item{position:relative;border-radius:8px;overflow:hidden;aspect-ratio:1;background:var(--bg3)}
.photo-item img{width:100%;height:100%;object-fit:cover}
.photo-del{position:absolute;top:4px;right:4px;width:24px;height:24px;border-radius:50%;background:rgba(248,81,73,.85);color:#fff;display:flex;align-items:center;justify-content:center;font-size:.75rem;cursor:pointer;transition:background var(--tr)}
.photo-del:hover{background:var(--r)}

/* Online dot */
.online-dot{width:8px;height:8px;border-radius:50%;background:var(--a);display:inline-block;animation:blink 1.5s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}

/* Tag input */
.tag-inp{display:flex;gap:6px;margin-top:8px;flex-wrap:wrap}
.opt-tag{display:flex;align-items:center;gap:4px;background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:4px 8px;font-size:.78rem}
.opt-tag .rm{cursor:pointer;color:var(--r)}

/* Chips filter */
.chips{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px}
.chip{padding:5px 12px;border-radius:20px;font-size:.75rem;font-weight:700;border:1px solid var(--border);color:var(--text-m);cursor:pointer;transition:all var(--tr)}
.chip:hover,.chip.on{background:var(--p);color:#fff;border-color:var(--p)}

/* Thumbnail preview */
.img-preview{width:80px;height:60px;border-radius:6px;object-fit:cover;border:1px solid var(--border);margin-top:6px}

/* Quick stat row for dashboard */
.qacts{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-bottom:20px}
@media(min-width:640px){.qacts{grid-template-columns:repeat(4,1fr)}}
.qact{background:var(--bg2);border:1px solid var(--border);border-radius:var(--radius);padding:14px;text-align:center;cursor:pointer;transition:all var(--tr)}
.qact:hover{border-color:var(--p)}
.qact i{font-size:1.3rem;display:block;margin-bottom:6px}
.qact span{font-size:.75rem;font-weight:700;color:var(--text-m)}

/* Rich text area */
.rich-ta{min-height:200px}
</style>
</head>
<body>

<div class="toast" id="toast"></div>

<!-- SIDEBAR -->
<aside class="sb" id="sb">
  <div class="sb-brand">
    <div class="sb-brand-ico"><i class="bi bi-building-fill"></i></div>
    <div><div class="sb-brand-name">ShakarqamishMFY</div><div class="sb-brand-sub">Admin Panel</div></div>
  </div>
  <div class="sb-body">
    <?php
    $nav = [
      'Asosiy'=>[
        ['dashboard','bi-grid-fill','Dashboard',0],
      ],
      'Kontent'=>[
        ['posts','bi-newspaper','Postlar',0],
        ['sliders','bi-images','Slayder',0],
        ['gallery','bi-camera-fill','Galereya',0],
        ['documents','bi-file-earmark-fill','Hujjatlar',0],
      ],
      'Xizmatlar'=>[
        ['appeals','bi-send-fill','Murojaatlar',$appeals_new_count],
        ['staff','bi-person-badge-fill','Xodimlar',0],
        ['events','bi-calendar-event','Tadbirlar',0],
        ['polls','bi-bar-chart-fill',"So'rovnomalar",0],
        ['faq','bi-question-circle-fill','FAQ',0],
      ],
      'Sozlamalar'=>[
        ['settings','bi-gear-fill','Site sozlamalari',0],
        ['admins','bi-people-fill','Adminlar',0],
        ['logs','bi-journal-text','Loglar',0],
      ],
    ];
    foreach($nav as $sec=>$items):
    ?>
    <div class="sb-sec"><?= $sec ?></div>
    <?php foreach($items as [$m_,$ico,$lbl,$cnt]): ?>
    <a href="/admin?m=<?= $m_ ?>" class="nav-it <?= $mod===$m_?'on':'' ?>">
      <i class="bi <?= $ico ?>"></i> <?= $lbl ?>
      <?php if($cnt): ?><span class="nav-badge"><?= $cnt ?></span><?php endif; ?>
    </a>
    <?php endforeach; endforeach; ?>
    <a href="/" target="_blank" class="nav-it"><i class="bi bi-box-arrow-up-right"></i> Saytni ko'rish</a>
    <a href="/admin?logout=1" class="nav-it" style="color:var(--r);margin-top:8px"><i class="bi bi-box-arrow-right"></i> Chiqish</a>
  </div>
  <div class="sb-footer">
    <div class="sb-user">
      <div class="sb-ava"><?= mb_strtoupper(mb_substr($admin['fullname'],0,1)) ?></div>
      <div><div class="sb-user-name"><?= h($admin['fullname']) ?></div><div class="sb-user-role"><span class="online-dot"></span> <?= h($admin['role']) ?></div></div>
    </div>
  </div>
</aside>

<!-- MAIN -->
<div class="main">
  <div class="tbar">
    <button class="mob-tog" onclick="document.getElementById('sb').classList.toggle('open')"><i class="bi bi-list"></i></button>
    <span class="tbar-title"><?= h($pageTitle) ?></span>
    <div class="tbar-acts">
      <?php if($mod==='posts'): ?><a href="/admin?m=posts&a=new" class="btn btn-p btn-sm"><i class="bi bi-plus"></i> Yangi post</a><?php endif; ?>
      <?php if($mod==='staff'): ?><button class="btn btn-p" onclick="openModal('staffModal')"><i class="bi bi-plus"></i> Xodim qo'shish</button><?php endif; ?>
      <?php if($mod==='sliders'): ?><a href="/admin?m=sliders&a=new" class="btn btn-p"><i class="bi bi-plus"></i> Yangi slayder</a><?php endif; ?>
      <?php if($mod==='faq'): ?><button class="btn btn-p" onclick="openModal('faqModal')"><i class="bi bi-plus"></i> FAQ qo'shish</button><?php endif; ?>
      <?php if($mod==='events'): ?><button class="btn btn-p" onclick="openModal('eventModal')"><i class="bi bi-plus"></i> Tadbir qo'shish</button><?php endif; ?>
      <?php if($mod==='polls'): ?><button class="btn btn-p" onclick="openModal('pollModal')"><i class="bi bi-plus"></i> So'rovnoma qo'shish</button><?php endif; ?>
      <?php if($mod==='admins'): ?><button class="btn btn-p" onclick="openModal('adminModal')"><i class="bi bi-plus"></i> Admin qo'shish</button><?php endif; ?>
    </div>
  </div>

  <div class="cnt">
<?php
// ============================================================
// MODULES
// ============================================================

// DASHBOARD
if ($mod === 'dashboard'):
?>
<div class="stat-row">
  <div class="stat-c">
    <div class="stat-ico" style="background:rgba(31,111,235,.12);color:var(--p)"><i class="bi bi-newspaper"></i></div>
    <div><div class="stat-val"><?= $pageData['posts_total'] ?></div><div class="stat-lbl">Chop etilgan</div></div>
  </div>
  <div class="stat-c">
    <div class="stat-ico" style="background:rgba(248,81,73,.12);color:var(--r)"><i class="bi bi-send-fill"></i></div>
    <div><div class="stat-val"><?= $pageData['appeals_new'] ?></div><div class="stat-lbl">Yangi murojaatlar</div></div>
  </div>
  <div class="stat-c">
    <div class="stat-ico" style="background:rgba(63,185,80,.12);color:var(--a)"><i class="bi bi-person-badge-fill"></i></div>
    <div><div class="stat-val"><?= $pageData['staff_total'] ?></div><div class="stat-lbl">Faol xodimlar</div></div>
  </div>
  <div class="stat-c">
    <div class="stat-ico" style="background:rgba(137,87,229,.12);color:var(--pu)"><i class="bi bi-images"></i></div>
    <div><div class="stat-val"><?= $pageData['gallery_total'] ?></div><div class="stat-lbl">Galereya rasmlari</div></div>
  </div>
</div>
<div class="qacts">
  <a href="/admin?m=posts&a=new" class="qact"><i class="bi bi-plus-circle-fill" style="color:var(--p)"></i><span>Yangi post</span></a>
  <a href="/admin?m=appeals" class="qact"><i class="bi bi-send-fill" style="color:var(--r)"></i><span>Murojaatlar</span></a>
  <a href="/admin?m=gallery" class="qact"><i class="bi bi-camera-fill" style="color:var(--a)"></i><span>Galereya</span></a>
  <a href="/admin?m=settings" class="qact"><i class="bi bi-gear-fill" style="color:var(--o)"></i><span>Sozlamalar</span></a>
</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px" id="dbGrid">
  <div class="card">
    <div class="card-hd"><span class="card-title">So'nggi murojaatlar</span><a href="/admin?m=appeals" class="btn btn-sm">Barchasi</a></div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Ticket</th><th>Ism</th><th>Tur</th><th>Holat</th></tr></thead>
        <tbody>
          <?php foreach($pageData['recent_appeals'] as $a): ?>
          <tr style="cursor:pointer" onclick="location='/admin?m=appeals&id=<?= $a['id'] ?>'">
            <td style="color:var(--p);font-family:monospace;font-size:.75rem"><?= h($a['ticket']) ?></td>
            <td><?= $a['is_anon']?'<em style="color:var(--text-l)">Anonim</em>':h($a['fullname']) ?></td>
            <td style="color:var(--text-m)"><?= h($a['type']) ?></td>
            <td><?= statusBadge($a['status']) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if(empty($pageData['recent_appeals'])): ?><tr><td colspan="4" style="text-align:center;color:var(--text-l);padding:24px">Murojaatlar yo'q</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div class="card">
    <div class="card-hd"><span class="card-title">So'nggi postlar</span><a href="/admin?m=posts" class="btn btn-sm">Barchasi</a></div>
    <div class="tbl-wrap">
      <table class="tbl">
        <thead><tr><th>Sarlavha</th><th>Kategoriya</th><th>Holat</th></tr></thead>
        <tbody>
          <?php foreach($pageData['recent_posts'] as $p): ?>
          <tr style="cursor:pointer" onclick="location='/admin?m=posts&id=<?= $p['id'] ?>'">
            <td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= h($p['title_uz']) ?></td>
            <td style="color:var(--text-m);font-size:.75rem"><?= h($p['name_uz']) ?></td>
            <td><?= statusBadge($p['status']) ?></td>
          </tr>
          <?php endforeach; ?>
          <?php if(empty($pageData['recent_posts'])): ?><tr><td colspan="3" style="text-align:center;color:var(--text-l);padding:24px">Postlar yo'q</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php
// POSTS
elseif ($mod === 'posts'):
if ($pageData['edit'] !== null):
  $e = $pageData['edit'];
  $isNew = empty($e['id']);
?>
<div class="card">
  <div class="card-hd">
    <span class="card-title"><?= $isNew?'Yangi post':'Postni tahrirlash' ?></span>
    <a href="/admin?m=posts" class="btn btn-sm"><i class="bi bi-arrow-left"></i> Orqaga</a>
  </div>
  <div class="card-body">
    <div id="formAlert"></div>
    <div class="tabs">
      <div class="tab on" onclick="switchTab(this,'tab-uz')">O'zbekcha</div>
      <div class="tab" onclick="switchTab(this,'tab-cy')">Ўзбекча</div>
      <div class="tab" onclick="switchTab(this,'tab-ru')">Русский</div>
      <div class="tab" onclick="switchTab(this,'tab-opts')">Sozlamalar</div>
    </div>
    <form id="postForm" enctype="multipart/form-data">
      <input type="hidden" id="pId" value="<?= $e['id']??0 ?>">

      <div id="tab-uz">
        <div class="fg"><label class="fl">Sarlavha (UZ) *</label><input class="fi" id="p_title_uz" value="<?= h($e['title_uz']??'') ?>" placeholder="Sarlavha kiriting"></div>
        <div class="fg"><label class="fl">Matn (UZ) *</label><textarea class="fi rich-ta" id="p_body_uz"><?= h($e['body_uz']??'') ?></textarea></div>
      </div>
      <div id="tab-cy" style="display:none">
        <div class="fg"><label class="fl">Sarlavha (ЎЗ)</label><input class="fi" id="p_title_cy" value="<?= h($e['title_cy']??'') ?>" placeholder="Сарлавҳа"></div>
        <div class="fg"><label class="fl">Матн (ЎЗ)</label><textarea class="fi rich-ta" id="p_body_cy"><?= h($e['body_cy']??'') ?></textarea></div>
      </div>
      <div id="tab-ru" style="display:none">
        <div class="fg"><label class="fl">Заголовок (RU)</label><input class="fi" id="p_title_ru" value="<?= h($e['title_ru']??'') ?>" placeholder="Заголовок"></div>
        <div class="fg"><label class="fl">Текст (RU)</label><textarea class="fi rich-ta" id="p_body_ru"><?= h($e['body_ru']??'') ?></textarea></div>
      </div>
      <div id="tab-opts" style="display:none">
        <div class="frow">
          <div class="fg"><label class="fl">Kategoriya *</label>
            <select class="fi" id="p_cat_id">
              <?php foreach($cats_all as $c): ?>
              <option value="<?= $c['id'] ?>" <?= ($e['cat_id']??1)==$c['id']?'selected':'' ?>><?= h($c['name_uz']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="fg"><label class="fl">Holat</label>
            <select class="fi" id="p_status">
              <option value="published" <?= ($e['status']??'published')==='published'?'selected':'' ?>>Chop etilgan</option>
              <option value="draft" <?= ($e['status']??'')=='draft'?'selected':'' ?>>Qoralama</option>
            </select>
          </div>
        </div>
        <div class="frow">
          <div class="fg" style="display:flex;align-items:center;gap:8px;padding-top:22px">
            <input type="checkbox" id="p_pinned" <?= !empty($e['is_pinned'])?'checked':'' ?> style="width:16px;height:16px;accent-color:var(--p)">
            <label for="p_pinned" style="font-size:.83rem;cursor:pointer">Muhim (pin)</label>
          </div>
          <div class="fg" style="display:flex;align-items:center;gap:8px;padding-top:22px">
            <input type="checkbox" id="p_featured" <?= !empty($e['is_featured'])?'checked':'' ?> style="width:16px;height:16px;accent-color:var(--p)">
            <label for="p_featured" style="font-size:.83rem;cursor:pointer">Tanlangan</label>
          </div>
        </div>
        <div class="fg">
          <label class="fl">Asosiy rasm</label>
          <?php if(!empty($e['image'])): ?><img src="/<?= h($e['image']) ?>" class="img-preview" id="imgPreview"><?php else: ?><img class="img-preview" id="imgPreview" style="display:none"><?php endif; ?>
          <input type="file" class="fi" id="p_image" accept="image/*" onchange="previewImg(this,'imgPreview')" style="margin-top:6px">
        </div>
      </div>

      <div style="display:flex;gap:8px;margin-top:16px">
        <button type="button" class="btn btn-p" onclick="savePost()"><i class="bi bi-check-circle-fill"></i> Saqlash</button>
        <a href="/admin?m=posts" class="btn btn-sm">Bekor</a>
      </div>
    </form>
  </div>
</div>
<?php else: ?>
<div class="card">
  <div class="card-hd">
    <span class="card-title">Barcha postlar (<?= $pageData['total'] ?>)</span>
    <div style="display:flex;gap:8px">
      <a href="/admin?m=posts&a=new" class="btn btn-p"><i class="bi bi-plus"></i> Yangi</a>
    </div>
  </div>
  <div class="card-body" style="padding-bottom:0">
    <div class="chips">
      <a href="/admin?m=posts" class="chip <?= !$pageData['statusF']?'on':'' ?>">Barchasi</a>
      <a href="/admin?m=posts&status=published" class="chip <?= $pageData['statusF']==='published'?'on':'' ?>">Chop etilgan</a>
      <a href="/admin?m=posts&status=draft" class="chip <?= $pageData['statusF']==='draft'?'on':'' ?>">Qoralama</a>
      <?php foreach($pageData['cats'] as $c): ?>
      <a href="/admin?m=posts&cat=<?= $c['id'] ?>" class="chip <?= $pageData['catF']==$c['id']?'on':'' ?>"><?= h($c['name_uz']) ?></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>#</th><th>Rasm</th><th>Sarlavha</th><th>Kategoriya</th><th>Holat</th><th>Ko'rishlar</th><th>Sana</th><th>Amallar</th></tr></thead>
      <tbody>
        <?php foreach($pageData['posts'] as $p): ?>
        <tr>
          <td style="color:var(--text-l)"><?= $p['id'] ?></td>
          <td><?php if($p['image']): ?><img src="/<?= h($p['image']) ?>" style="width:48px;height:36px;object-fit:cover;border-radius:5px"><?php endif; ?></td>
          <td>
            <div style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600"><?= h($p['title_uz']) ?></div>
            <?php if($p['is_pinned']): ?><span style="font-size:.65rem;color:var(--o)"><i class="bi bi-pin-fill"></i> Muhim</span><?php endif; ?>
          </td>
          <td style="color:var(--text-m);font-size:.78rem"><?= h($p['name_uz']) ?></td>
          <td><?= statusBadge($p['status']) ?></td>
          <td><?= number_format($p['views']) ?></td>
          <td style="color:var(--text-m);font-size:.75rem;white-space:nowrap"><?= date('d.m.Y',strtotime($p['created_at'])) ?></td>
          <td>
            <div style="display:flex;gap:4px">
              <a href="/admin?m=posts&a=edit&id=<?= $p['id'] ?>" class="btn btn-sm btn-sm-ic" title="Tahrirlash"><i class="bi bi-pencil"></i></a>
              <button class="btn btn-sm-ic <?= $p['is_pinned']?'btn-o':'btn-sm' ?>" onclick="togglePin(<?= $p['id'] ?>,this)" title="Pin"><i class="bi bi-pin"></i></button>
              <button class="btn btn-r btn-sm-ic" onclick="delPost(<?= $p['id'] ?>)" title="O'chirish"><i class="bi bi-trash"></i></button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($pageData['posts'])): ?><tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-l)">Postlar yo'q</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($pageData['pages']>1): $pg=$pageData['pg']; ?>
  <div class="card-body">
    <div class="pag">
      <?php if($pg>1): ?><a href="/admin?m=posts&pg=<?= $pg-1 ?>&status=<?= $pageData['statusF'] ?>&cat=<?= $pageData['catF'] ?>"><i class="bi bi-chevron-left"></i></a><?php endif; ?>
      <?php for($i=max(1,$pg-2);$i<=min($pageData['pages'],$pg+2);$i++): ?>
      <a href="/admin?m=posts&pg=<?= $i ?>&status=<?= $pageData['statusF'] ?>&cat=<?= $pageData['catF'] ?>" class="<?= $i===$pg?'on':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
      <?php if($pg<$pageData['pages']): ?><a href="/admin?m=posts&pg=<?= $pg+1 ?>&status=<?= $pageData['statusF'] ?>&cat=<?= $pageData['catF'] ?>"><i class="bi bi-chevron-right"></i></a><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<?php
// APPEALS
elseif ($mod === 'appeals'):
if ($pageData['single']):
  $a = $pageData['single'];
?>
<div class="card" style="max-width:700px">
  <div class="card-hd">
    <span class="card-title">Murojaat: <?= h($a['ticket']) ?></span>
    <a href="/admin?m=appeals" class="btn btn-sm"><i class="bi bi-arrow-left"></i></a>
  </div>
  <div class="card-body">
    <div class="frow" style="margin-bottom:14px">
      <div><div style="font-size:.7rem;color:var(--text-l);margin-bottom:3px">HOLAT</div><?= statusBadge($a['status']) ?></div>
      <div><div style="font-size:.7rem;color:var(--text-l);margin-bottom:3px">PRIORITET</div><?= priorityBadge($a['priority']) ?></div>
      <div><div style="font-size:.7rem;color:var(--text-l);margin-bottom:3px">TUR</div><span style="font-weight:600"><?= h($a['type']) ?></span></div>
      <div><div style="font-size:.7rem;color:var(--text-l);margin-bottom:3px">SANA</div><span style="font-size:.78rem"><?= date('d.m.Y H:i',strtotime($a['created_at'])) ?></span></div>
    </div>
    <div style="background:var(--bg3);border-radius:8px;padding:14px;margin-bottom:14px">
      <div style="font-size:.7rem;color:var(--text-l);margin-bottom:6px">MUROJAAT EGASI</div>
      <div style="font-weight:700"><?= $a['is_anon']?'<em>Anonim</em>':h($a['fullname']) ?></div>
      <?php if(!$a['is_anon']): ?>
      <div style="font-size:.82rem;color:var(--text-m);margin-top:3px"><i class="bi bi-telephone-fill"></i> <a href="tel:<?= h($a['phone']) ?>"><?= h($a['phone']) ?></a></div>
      <?php if($a['address']): ?><div style="font-size:.82rem;color:var(--text-m);margin-top:3px"><i class="bi bi-geo-alt-fill"></i> <?= h($a['address']) ?></div><?php endif; ?>
      <?php endif; ?>
    </div>
    <div style="margin-bottom:14px">
      <div style="font-size:.7rem;color:var(--text-l);margin-bottom:6px">MAVZU</div>
      <div style="font-weight:700"><?= h($a['subject']) ?></div>
    </div>
    <div style="background:var(--bg3);border-radius:8px;padding:14px;margin-bottom:16px;line-height:1.7;font-size:.88rem">
      <?= nl2br(h($a['body'])) ?>
    </div>
    <?php if($a['file']): ?>
    <div style="margin-bottom:14px"><a href="/<?= h($a['file']) ?>" target="_blank" class="btn btn-sm"><i class="bi bi-paperclip"></i> Fayl ko'rish</a></div>
    <?php endif; ?>
    <?php if($a['reply']): ?>
    <div class="alert alert-ok" style="margin-bottom:14px"><i class="bi bi-chat-fill"></i><div><div style="font-weight:700">Javob berilgan: <?= date('d.m.Y',strtotime($a['replied_at'])) ?></div><div><?= nl2br(h($a['reply'])) ?></div></div></div>
    <?php endif; ?>
    <div style="border-top:1px solid var(--border);padding-top:14px">
      <div id="replyAlert"></div>
      <div class="fg"><label class="fl">Holat</label>
        <select class="fi" id="repStatus">
          <option value="new" <?= $a['status']==='new'?'selected':'' ?>>Yangi</option>
          <option value="processing" <?= $a['status']==='processing'?'selected':'' ?>>Ko'rib chiqilmoqda</option>
          <option value="resolved" <?= $a['status']==='resolved'?'selected':'' ?>>Hal qilindi</option>
          <option value="rejected" <?= $a['status']==='rejected'?'selected':'' ?>>Rad etildi</option>
        </select>
      </div>
      <div class="fg"><label class="fl">Javob</label><textarea class="fi" id="repText" rows="4" placeholder="Javob yozing..."><?= h($a['reply']??'') ?></textarea></div>
      <button class="btn btn-p" onclick="sendReply(<?= $a['id'] ?>)"><i class="bi bi-send-fill"></i> Javob yuborish</button>
    </div>
  </div>
</div>
<?php else: ?>
<div class="card">
  <div class="card-hd"><span class="card-title">Murojaatlar (<?= $pageData['total'] ?>)</span></div>
  <div class="card-body" style="padding-bottom:0">
    <div class="chips">
      <a href="/admin?m=appeals" class="chip <?= !$pageData['statusF']?'on':'' ?>">Barchasi</a>
      <a href="/admin?m=appeals&status=new" class="chip <?= $pageData['statusF']==='new'?'on':'' ?>">Yangi</a>
      <a href="/admin?m=appeals&status=processing" class="chip <?= $pageData['statusF']==='processing'?'on':'' ?>">Ko'rib chiqilmoqda</a>
      <a href="/admin?m=appeals&status=resolved" class="chip <?= $pageData['statusF']==='resolved'?'on':'' ?>">Hal qilindi</a>
      <a href="/admin?m=appeals&status=rejected" class="chip <?= $pageData['statusF']==='rejected'?'on':'' ?>">Rad etildi</a>
    </div>
  </div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>Ticket</th><th>Ism</th><th>Mavzu</th><th>Tur</th><th>Prioritet</th><th>Holat</th><th>Sana</th><th></th></tr></thead>
      <tbody>
        <?php foreach($pageData['appeals'] as $a): ?>
        <tr>
          <td><a href="/admin?m=appeals&id=<?= $a['id'] ?>" style="color:var(--p);font-family:monospace;font-size:.75rem"><?= h($a['ticket']) ?></a></td>
          <td><?= $a['is_anon']?'<em style="color:var(--text-l)">Anonim</em>':h($a['fullname']) ?></td>
          <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= h($a['subject']) ?></td>
          <td style="font-size:.75rem;color:var(--text-m)"><?= h($a['type']) ?></td>
          <td><?= priorityBadge($a['priority']) ?></td>
          <td><?= statusBadge($a['status']) ?></td>
          <td style="font-size:.72rem;color:var(--text-m);white-space:nowrap"><?= date('d.m.Y H:i',strtotime($a['created_at'])) ?></td>
          <td><a href="/admin?m=appeals&id=<?= $a['id'] ?>" class="btn btn-sm btn-sm-ic"><i class="bi bi-eye"></i></a></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($pageData['appeals'])): ?><tr><td colspan="8" style="text-align:center;padding:32px;color:var(--text-l)">Murojaatlar yo'q</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php
// STAFF
elseif ($mod === 'staff'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">Xodimlar (<?= count($pageData['staff']) ?>)</span><button class="btn btn-p" onclick="openModal('staffModal',0)"><i class="bi bi-plus"></i> Qo'shish</button></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>Rasm</th><th>F.I.O</th><th>Lavozim</th><th>Telefon</th><th>Tartib</th><th>Holat</th><th>Amallar</th></tr></thead>
      <tbody>
        <?php foreach($pageData['staff'] as $st): ?>
        <tr>
          <td><?php if($st['photo']): ?><img src="/<?= h($st['photo']) ?>" style="width:40px;height:40px;border-radius:50%;object-fit:cover"><?php else: ?><div style="width:40px;height:40px;border-radius:50%;background:var(--p);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700"><?= mb_strtoupper(mb_substr($st['fullname'],0,1)) ?></div><?php endif; ?></td>
          <td style="font-weight:700"><?= h($st['fullname']) ?></td>
          <td style="color:var(--text-m);font-size:.78rem"><?= h($st['position_uz']) ?></td>
          <td style="font-size:.78rem"><?= h($st['phone']) ?></td>
          <td><?= $st['sort'] ?></td>
          <td><?= $st['is_active']?'<span style="color:var(--a);font-weight:700">Faol</span>':'<span style="color:var(--r)">Nofaol</span>' ?></td>
          <td>
            <div style="display:flex;gap:4px">
              <button class="btn btn-sm btn-sm-ic" onclick="editStaff(<?= $st['id'] ?>)" title="Tahrirlash"><i class="bi bi-pencil"></i></button>
              <button class="btn btn-sm btn-sm-ic" onclick="toggleStaff(<?= $st['id'] ?>)" title="Holat"><i class="bi bi-toggle-on"></i></button>
              <button class="btn btn-r btn-sm-ic" onclick="delStaff(<?= $st['id'] ?>)"><i class="bi bi-trash"></i></button>
            </div>
          </td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($pageData['staff'])): ?><tr><td colspan="7" style="text-align:center;padding:32px;color:var(--text-l)">Xodimlar yo'q</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<!-- Staff modal -->
<div class="modal-bg" id="staffModal">
  <div class="modal">
    <div class="modal-hd"><span class="modal-title">Xodim</span><button onclick="closeModal('staffModal')"><i class="bi bi-x-lg"></i></button></div>
    <div class="modal-body">
      <input type="hidden" id="st_id" value="0">
      <div class="fg"><label class="fl">F.I.O *</label><input class="fi" id="st_fullname"></div>
      <div class="tabs" style="margin-bottom:12px">
        <div class="tab on" onclick="switchTab(this,'st-uz')">UZ</div>
        <div class="tab" onclick="switchTab(this,'st-cy')">ЎЗ</div>
        <div class="tab" onclick="switchTab(this,'st-ru')">RU</div>
      </div>
      <div id="st-uz"><div class="fg"><label class="fl">Lavozim (UZ)</label><input class="fi" id="st_pos_uz"></div><div class="fg"><label class="fl">Bio (UZ)</label><textarea class="fi" id="st_bio_uz"></textarea></div></div>
      <div id="st-cy" style="display:none"><div class="fg"><label class="fl">Lavozim (ЎЗ)</label><input class="fi" id="st_pos_cy"></div><div class="fg"><label class="fl">Биография</label><textarea class="fi" id="st_bio_cy"></textarea></div></div>
      <div id="st-ru" style="display:none"><div class="fg"><label class="fl">Должность (RU)</label><input class="fi" id="st_pos_ru"></div><div class="fg"><label class="fl">Биография</label><textarea class="fi" id="st_bio_ru"></textarea></div></div>
      <div class="frow">
        <div class="fg"><label class="fl">Telefon</label><input class="fi" id="st_phone" placeholder="+998..."></div>
        <div class="fg"><label class="fl">Email</label><input class="fi" id="st_email" type="email"></div>
      </div>
      <div class="frow">
        <div class="fg"><label class="fl">Qabul kunlari</label><input class="fi" id="st_reception" placeholder="Du-Ju 9:00-17:00"></div>
        <div class="fg"><label class="fl">Tartib raqam</label><input class="fi" id="st_sort" type="number" value="0"></div>
      </div>
      <div class="fg"><label class="fl">Rasm</label><img id="st_img_preview" class="img-preview" style="display:none"><input type="file" class="fi" id="st_photo" accept="image/*" onchange="previewImg(this,'st_img_preview')" style="margin-top:6px"></div>
    </div>
    <div class="modal-ft"><button class="btn btn-sm" onclick="closeModal('staffModal')">Bekor</button><button class="btn btn-p" onclick="saveStaff()"><i class="bi bi-check-circle-fill"></i> Saqlash</button></div>
  </div>
</div>
<script>
const staffData = <?= json_encode($pageData['staff']) ?>;
function editStaff(id){
  const s=staffData.find(x=>x.id==id); if(!s) return;
  document.getElementById('st_id').value=s.id;
  document.getElementById('st_fullname').value=s.fullname||'';
  document.getElementById('st_pos_uz').value=s.position_uz||'';
  document.getElementById('st_pos_cy').value=s.position_cy||'';
  document.getElementById('st_pos_ru').value=s.position_ru||'';
  document.getElementById('st_phone').value=s.phone||'';
  document.getElementById('st_email').value=s.email||'';
  document.getElementById('st_reception').value=s.reception||'';
  document.getElementById('st_sort').value=s.sort||0;
  document.getElementById('st_bio_uz').value=s.bio_uz||'';
  document.getElementById('st_bio_cy').value=s.bio_cy||'';
  document.getElementById('st_bio_ru').value=s.bio_ru||'';
  const prev=document.getElementById('st_img_preview');
  if(s.photo){prev.src='/'+s.photo;prev.style.display='block';}else{prev.style.display='none';}
  openModal('staffModal');
}
async function saveStaff(){
  const fd=new FormData();
  fd.append('ajax',1); fd.append('id',document.getElementById('st_id').value);
  ['fullname','pos_uz','pos_cy','pos_ru','phone','email','reception','sort','bio_uz','bio_cy','bio_ru'].forEach(k=>{
    const el=document.getElementById('st_'+k); if(el) fd.append(k==='pos_uz'?'position_uz':(k==='pos_cy'?'position_cy':(k==='pos_ru'?'position_ru':k)),el.value);
  });
  const ph=document.getElementById('st_photo');
  if(ph?.files[0]) fd.append('photo',ph.files[0]);
  const r=await ajaxPost('/admin?m=staff&a=save',fd);
  if(r.ok){showToast('Saqlandi!');setTimeout(()=>location.reload(),700);}
  else showToast(r.msg||'Xato','err');
}
async function delStaff(id){if(!confirm('O\'chirishni tasdiqlaysizmi?')) return; const r=await ajaxPost('/admin?m=staff&a=delete&id='+id,new FormData()); if(r.ok){showToast('O\'chirildi!');location.reload();}}
async function toggleStaff(id){const fd=new FormData();fd.append('ajax',1);const r=await fetch('/admin?m=staff&a=toggle&id='+id,{method:'POST',body:fd});location.reload();}
</script>

<?php
// GALLERY
elseif ($mod === 'gallery'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">Galereya (<?= count($pageData['photos']) ?> ta rasm)</span><button class="btn btn-p" onclick="openModal('galModal')"><i class="bi bi-cloud-upload"></i> Yuklash</button></div>
  <div class="card-body">
    <?php if(empty($pageData['photos'])): ?>
    <div style="text-align:center;padding:48px;color:var(--text-l)"><i class="bi bi-images" style="font-size:3rem;display:block;margin-bottom:12px"></i>Rasmlar yo'q</div>
    <?php else: ?>
    <div class="photo-grid">
      <?php foreach($pageData['photos'] as $g): ?>
      <div class="photo-item">
        <img src="/<?= h($g['image']) ?>" alt="" loading="lazy">
        <button class="photo-del" onclick="delGallery(<?= $g['id'] ?>)" title="O'chirish"><i class="bi bi-x"></i></button>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>
<div class="modal-bg" id="galModal">
  <div class="modal">
    <div class="modal-hd"><span class="modal-title">Rasm yuklash</span><button onclick="closeModal('galModal')"><i class="bi bi-x-lg"></i></button></div>
    <div class="modal-body">
      <div class="fg"><label class="fl">Album nomi</label><input class="fi" id="gal_album" placeholder="masalan: Tadbirlar 2025"></div>
      <div class="fg"><label class="fl">Sarlavha</label><input class="fi" id="gal_title"></div>
      <div class="fg">
        <label class="fl">Rasmlar (bir nechta tanlash mumkin)</label>
        <div class="upload-area" onclick="document.getElementById('gal_files').click()" id="uploadArea">
          <input type="file" id="gal_files" multiple accept="image/*" onchange="showFilenames(this)" style="display:none">
          <div class="upload-ico"><i class="bi bi-cloud-upload"></i></div>
          <div style="font-size:.85rem;color:var(--text-m)">Bosing yoki rasmlarni tashlang</div>
          <div id="fileNames" style="font-size:.75rem;color:var(--text-l);margin-top:8px"></div>
        </div>
      </div>
      <div id="galUploadProgress" style="display:none">
        <div style="background:var(--border);border-radius:4px;height:4px"><div id="galProgressBar" style="background:var(--p);height:100%;border-radius:4px;width:0;transition:width .3s"></div></div>
        <div style="font-size:.75rem;color:var(--text-m);margin-top:4px" id="galProgressText">Yuklanmoqda...</div>
      </div>
    </div>
    <div class="modal-ft"><button class="btn btn-sm" onclick="closeModal('galModal')">Bekor</button><button class="btn btn-p" id="galUploadBtn" onclick="uploadGallery()"><i class="bi bi-cloud-upload"></i> Yuklash</button></div>
  </div>
</div>
<script>
function showFilenames(inp){
  const names=Array.from(inp.files).map(f=>f.name).join(', ');
  document.getElementById('fileNames').textContent=names||'';
}
async function uploadGallery(){
  const files=document.getElementById('gal_files').files;
  if(!files.length){showToast('Rasm tanlang','err');return;}
  const fd=new FormData(); fd.append('ajax',1);
  fd.append('album',document.getElementById('gal_album').value);
  fd.append('title_uz',document.getElementById('gal_title').value);
  for(let i=0;i<files.length;i++) fd.append('images[]',files[i]);
  document.getElementById('galUploadProgress').style.display='block';
  document.getElementById('galUploadBtn').disabled=true;
  document.getElementById('galProgressBar').style.width='60%';
  const r=await ajaxPost('/admin?m=gallery&a=upload',fd);
  document.getElementById('galProgressBar').style.width='100%';
  if(r.ok){showToast(r.count+' ta rasm yuklandi!');setTimeout(()=>location.reload(),700);}
  else{showToast(r.msg||'Yuklash xatosi','err');document.getElementById('galUploadBtn').disabled=false;}
}
async function delGallery(id){if(!confirm('Rasmni o\'chirasizmi?'))return; const fd=new FormData();fd.append('ajax',1); const r=await ajaxPost('/admin?m=gallery&a=delete&id='+id,fd); if(r.ok){showToast('O\'chirildi!');location.reload();}}
</script>

<?php
// DOCUMENTS
elseif ($mod === 'documents'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">Hujjatlar (<?= count($pageData['docs']) ?>)</span><button class="btn btn-p" onclick="openModal('docModal')"><i class="bi bi-cloud-upload"></i> Yuklash</button></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>Nom</th><th>Kategoriya</th><th>Hajm</th><th>Yuklamalar</th><th>Sana</th><th></th></tr></thead>
      <tbody>
        <?php foreach($pageData['docs'] as $d):
          $ext=strtolower(pathinfo($d['file'],PATHINFO_EXTENSION));
          $size=$d['size']>1048576?round($d['size']/1048576,1).' MB':round($d['size']/1024).' KB';
        ?>
        <tr>
          <td>
            <div style="display:flex;align-items:center;gap:8px">
              <i class="bi bi-file-earmark-<?= $ext==='pdf'?'pdf':($ext==='doc'||$ext==='docx'?'word':($ext==='xls'||$ext==='xlsx'?'excel':'fill')) ?>-fill" style="font-size:1.1rem;color:<?= $ext==='pdf'?'var(--r)':($ext==='doc'||$ext==='docx'?'var(--p)':'var(--a)') ?>"></i>
              <div style="font-weight:600;font-size:.83rem"><?= h($d['title_uz']) ?></div>
            </div>
          </td>
          <td style="color:var(--text-m);font-size:.75rem"><?= h($d['cat']??'—') ?></td>
          <td style="font-size:.75rem"><?= $size ?></td>
          <td><?= $d['downloads'] ?></td>
          <td style="font-size:.72rem;color:var(--text-m)"><?= date('d.m.Y',strtotime($d['created_at'])) ?></td>
          <td><div style="display:flex;gap:4px"><a href="/<?= h($d['file']) ?>" target="_blank" class="btn btn-sm btn-sm-ic"><i class="bi bi-eye"></i></a><button class="btn btn-r btn-sm-ic" onclick="delDoc(<?= $d['id'] ?>)"><i class="bi bi-trash"></i></button></div></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($pageData['docs'])): ?><tr><td colspan="6" style="text-align:center;padding:32px;color:var(--text-l)">Hujjatlar yo'q</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<div class="modal-bg" id="docModal">
  <div class="modal">
    <div class="modal-hd"><span class="modal-title">Hujjat yuklash</span><button onclick="closeModal('docModal')"><i class="bi bi-x-lg"></i></button></div>
    <div class="modal-body">
      <div class="fg"><label class="fl">Sarlavha (UZ) *</label><input class="fi" id="doc_title_uz" placeholder="Hujjat nomi"></div>
      <div class="fg"><label class="fl">Sarlavha (RU)</label><input class="fi" id="doc_title_ru"></div>
      <div class="fg"><label class="fl">Kategoriya</label><input class="fi" id="doc_cat" placeholder="masalan: Qarorlar, Nizomlar..."></div>
      <div class="fg"><label class="fl">Fayl (PDF, DOC, XLS) *</label><input type="file" class="fi" id="doc_file" accept=".pdf,.doc,.docx,.xls,.xlsx"></div>
    </div>
    <div class="modal-ft"><button class="btn btn-sm" onclick="closeModal('docModal')">Bekor</button><button class="btn btn-p" onclick="uploadDoc()"><i class="bi bi-cloud-upload"></i> Yuklash</button></div>
  </div>
</div>
<script>
async function uploadDoc(){
  const fd=new FormData();fd.append('ajax',1);
  fd.append('title_uz',document.getElementById('doc_title_uz').value);
  fd.append('title_ru',document.getElementById('doc_title_ru').value);
  fd.append('cat',document.getElementById('doc_cat').value);
  const f=document.getElementById('doc_file');
  if(!f.files[0]){showToast('Fayl tanlang','err');return;}
  fd.append('file',f.files[0]);
  const r=await ajaxPost('/admin?m=documents&a=upload',fd);
  if(r.ok){showToast('Yuklandi!');setTimeout(()=>location.reload(),700);}
  else showToast(r.msg||'Xato','err');
}
async function delDoc(id){if(!confirm('O\'chirasizmi?'))return;const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=documents&a=delete&id='+id,fd);if(r.ok){showToast('O\'chirildi');location.reload();}}
</script>

<?php
// SETTINGS
elseif ($mod === 'settings'):
$s = $pageData['s'];
?>
<div class="card">
  <div class="card-hd"><span class="card-title">Sayt sozlamalari</span><button class="btn btn-a" onclick="saveSettings()"><i class="bi bi-check-circle-fill"></i> Saqlash</button></div>
  <div class="card-body">
    <div id="settAlert"></div>
    <div class="tabs">
      <div class="tab on" onclick="switchTab(this,'set-gen')">Umumiy</div>
      <div class="tab" onclick="switchTab(this,'set-contact')">Bog'lanish</div>
      <div class="tab" onclick="switchTab(this,'set-social')">Ijtimoiy</div>
      <div class="tab" onclick="switchTab(this,'set-stats')">Statistika</div>
      <div class="tab" onclick="switchTab(this,'set-tg')">Telegram bot</div>
      <div class="tab" onclick="switchTab(this,'set-seo')">SEO</div>
    </div>
    <div id="set-gen">
      <div class="frow">
        <div class="fg"><label class="fl">Sayt nomi</label><input class="fi sett" data-key="site_name" value="<?= h($s['site_name']??SITE_NAME) ?>"></div>
        <div class="fg"><label class="fl">Asos yil</label><input class="fi sett" data-key="founded_year" value="<?= h($s['founded_year']??'1992') ?>"></div>
      </div>
      <div class="fg"><label class="fl">Ticker matni (| bilan ajrating)</label><textarea class="fi sett" data-key="ticker_text" rows="3"><?= h($s['ticker_text']??'') ?></textarea></div>
      <div class="fg"><label class="fl">Google Maps Embed kodi</label><textarea class="fi sett" data-key="maps_embed" rows="4"><?= h($s['maps_embed']??'') ?></textarea></div>
    </div>
    <div id="set-contact" style="display:none">
      <div class="frow">
        <div class="fg"><label class="fl">Telefon 1</label><input class="fi sett" data-key="site_phone" value="<?= h($s['site_phone']??'') ?>"></div>
        <div class="fg"><label class="fl">Telefon 2</label><input class="fi sett" data-key="site_phone2" value="<?= h($s['site_phone2']??'') ?>"></div>
      </div>
      <div class="fg"><label class="fl">Email</label><input class="fi sett" data-key="site_email" value="<?= h($s['site_email']??'') ?>" type="email"></div>
      <div class="fg"><label class="fl">Manzil</label><input class="fi sett" data-key="site_address" value="<?= h($s['site_address']??'') ?>"></div>
    </div>
    <div id="set-social" style="display:none">
      <div class="fg"><label class="fl">Telegram kanal URL</label><input class="fi sett" data-key="site_telegram" value="<?= h($s['site_telegram']??'') ?>" placeholder="https://t.me/..."></div>
      <div class="fg"><label class="fl">Facebook URL</label><input class="fi sett" data-key="site_facebook" value="<?= h($s['site_facebook']??'') ?>"></div>
      <div class="fg"><label class="fl">Instagram URL</label><input class="fi sett" data-key="site_instagram" value="<?= h($s['site_instagram']??'') ?>"></div>
      <div class="fg"><label class="fl">YouTube URL</label><input class="fi sett" data-key="site_youtube" value="<?= h($s['site_youtube']??'') ?>"></div>
    </div>
    <div id="set-stats" style="display:none">
      <div class="frow">
        <div class="fg"><label class="fl">Aholi soni</label><input class="fi sett" data-key="population" value="<?= h($s['population']??'0') ?>" type="number"></div>
        <div class="fg"><label class="fl">Uy-xonadonlar</label><input class="fi sett" data-key="households" value="<?= h($s['households']??'0') ?>" type="number"></div>
      </div>
      <div class="fg"><label class="fl">Ko'chalar soni</label><input class="fi sett" data-key="streets" value="<?= h($s['streets']??'0') ?>" type="number"></div>
    </div>
    <div id="set-tg" style="display:none">
      <div class="alert alert-info"><i class="bi bi-info-circle"></i> Telegram bot tokenini @BotFather dan oling</div>
      <div class="fg"><label class="fl">Bot Token</label><input class="fi sett" data-key="telegram_bot" value="<?= h($s['telegram_bot']??'') ?>" placeholder="123456789:AAH..."></div>
      <div class="fg"><label class="fl">Admin Chat ID</label><input class="fi sett" data-key="telegram_chat" value="<?= h($s['telegram_chat']??'') ?>" placeholder="-100123456789"></div>
    </div>
    <div id="set-seo" style="display:none">
      <div class="fg"><label class="fl">Meta description</label><textarea class="fi sett" data-key="meta_desc" rows="3"><?= h($s['meta_desc']??'') ?></textarea></div>
      <div class="fg"><label class="fl">Meta keywords</label><input class="fi sett" data-key="meta_keywords" value="<?= h($s['meta_keywords']??'') ?>"></div>
    </div>
  </div>
</div>
<script>
async function saveSettings(){
  const fd=new FormData(); fd.append('ajax',1);
  document.querySelectorAll('.sett').forEach(el=>fd.append(el.dataset.key, el.value));
  const r=await ajaxPost('/admin?m=settings&a=save',fd);
  const el=document.getElementById('settAlert');
  if(r.ok){el.innerHTML='<div class="alert alert-ok"><i class="bi bi-check-circle-fill"></i> Saqlandi!</div>';showToast('Sozlamalar saqlandi!');}
  else{el.innerHTML='<div class="alert alert-err">'+r.msg+'</div>';}
  setTimeout(()=>{if(el)el.innerHTML=''},3000);
}
</script>

<?php
// FAQ
elseif ($mod === 'faq'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">FAQ (<?= count($pageData['faqs']) ?>)</span><button class="btn btn-p" onclick="openModal('faqModal',0)"><i class="bi bi-plus"></i> Qo'shish</button></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>#</th><th>Savol</th><th>Tartib</th><th>Amallar</th></tr></thead>
      <tbody>
        <?php foreach($pageData['faqs'] as $f): ?>
        <tr>
          <td><?= $f['id'] ?></td>
          <td style="max-width:300px"><?= h(mb_substr($f['q_uz'],0,80)) ?>...</td>
          <td><?= $f['sort'] ?></td>
          <td><div style="display:flex;gap:4px"><button class="btn btn-sm btn-sm-ic" onclick="editFaq(<?= $f['id'] ?>)"><i class="bi bi-pencil"></i></button><button class="btn btn-r btn-sm-ic" onclick="delFaq(<?= $f['id'] ?>)"><i class="bi bi-trash"></i></button></div></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($pageData['faqs'])): ?><tr><td colspan="4" style="text-align:center;padding:32px;color:var(--text-l)">FAQ yo'q</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<div class="modal-bg" id="faqModal">
  <div class="modal">
    <div class="modal-hd"><span class="modal-title">FAQ</span><button onclick="closeModal('faqModal')"><i class="bi bi-x-lg"></i></button></div>
    <div class="modal-body">
      <input type="hidden" id="faq_id" value="0">
      <div class="tabs" style="margin-bottom:12px"><div class="tab on" onclick="switchTab(this,'fq-uz')">UZ</div><div class="tab" onclick="switchTab(this,'fq-ru')">RU</div></div>
      <div id="fq-uz">
        <div class="fg"><label class="fl">Savol (UZ) *</label><input class="fi" id="faq_q_uz"></div>
        <div class="fg"><label class="fl">Javob (UZ) *</label><textarea class="fi" id="faq_a_uz" rows="4"></textarea></div>
      </div>
      <div id="fq-ru" style="display:none">
        <div class="fg"><label class="fl">Вопрос (RU)</label><input class="fi" id="faq_q_ru"></div>
        <div class="fg"><label class="fl">Ответ (RU)</label><textarea class="fi" id="faq_a_ru" rows="4"></textarea></div>
      </div>
      <div class="fg"><label class="fl">Tartib raqam</label><input class="fi" id="faq_sort" type="number" value="0"></div>
    </div>
    <div class="modal-ft"><button class="btn btn-sm" onclick="closeModal('faqModal')">Bekor</button><button class="btn btn-p" onclick="saveFaq()">Saqlash</button></div>
  </div>
</div>
<script>
const faqData=<?= json_encode($pageData['faqs']) ?>;
function editFaq(id){const f=faqData.find(x=>x.id==id);if(!f)return;document.getElementById('faq_id').value=f.id;document.getElementById('faq_q_uz').value=f.q_uz||'';document.getElementById('faq_a_uz').value=f.a_uz||'';document.getElementById('faq_q_ru').value=f.q_ru||'';document.getElementById('faq_a_ru').value=f.a_ru||'';document.getElementById('faq_sort').value=f.sort||0;openModal('faqModal');}
async function saveFaq(){const fd=new FormData();fd.append('ajax',1);fd.append('id',document.getElementById('faq_id').value);['q_uz','q_ru','a_uz','a_ru','sort'].forEach(k=>{fd.append(k,document.getElementById('faq_'+k).value);});const r=await ajaxPost('/admin?m=faq&a=save',fd);if(r.ok){showToast('Saqlandi!');setTimeout(()=>location.reload(),700);}else showToast(r.msg||'Xato','err');}
async function delFaq(id){if(!confirm('O\'chirasizmi?'))return;const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=faq&a=delete&id='+id,fd);if(r.ok){showToast('O\'chirildi');location.reload();}}
</script>

<?php
// EVENTS
elseif ($mod === 'events'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">Tadbirlar (<?= count($pageData['events']) ?>)</span><button class="btn btn-p" onclick="openModal('eventModal',0)"><i class="bi bi-plus"></i> Qo'shish</button></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>Nomi</th><th>Joyi</th><th>Sana</th><th>Holat</th><th>Amallar</th></tr></thead>
      <tbody>
        <?php foreach($pageData['events'] as $ev): ?>
        <tr>
          <td style="font-weight:600"><?= h($ev['title_uz']) ?></td>
          <td style="color:var(--text-m)"><?= h($ev['location']??'—') ?></td>
          <td style="font-size:.78rem;white-space:nowrap"><?= date('d.m.Y H:i',strtotime($ev['event_date'])) ?></td>
          <td><?= statusBadge($ev['status']) ?></td>
          <td><div style="display:flex;gap:4px"><button class="btn btn-sm btn-sm-ic" onclick="editEvent(<?= $ev['id'] ?>)"><i class="bi bi-pencil"></i></button><button class="btn btn-r btn-sm-ic" onclick="delEvent(<?= $ev['id'] ?>)"><i class="bi bi-trash"></i></button></div></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($pageData['events'])): ?><tr><td colspan="5" style="text-align:center;padding:32px;color:var(--text-l)">Tadbirlar yo'q</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<div class="modal-bg" id="eventModal">
  <div class="modal">
    <div class="modal-hd"><span class="modal-title">Tadbir</span><button onclick="closeModal('eventModal')"><i class="bi bi-x-lg"></i></button></div>
    <div class="modal-body">
      <input type="hidden" id="ev_id" value="0">
      <div class="fg"><label class="fl">Nomi (UZ) *</label><input class="fi" id="ev_title_uz"></div>
      <div class="fg"><label class="fl">Nomi (RU)</label><input class="fi" id="ev_title_ru"></div>
      <div class="frow">
        <div class="fg"><label class="fl">Joyi</label><input class="fi" id="ev_location" placeholder="Manzil"></div>
        <div class="fg"><label class="fl">Sana va vaqt *</label><input class="fi" id="ev_date" type="datetime-local"></div>
      </div>
      <div class="fg"><label class="fl">Holat</label><select class="fi" id="ev_status"><option value="upcoming">Kutilmoqda</option><option value="done">Tugallandi</option><option value="cancelled">Bekor qilindi</option></select></div>
      <div class="fg"><label class="fl">Tavsif (UZ)</label><textarea class="fi" id="ev_body_uz" rows="3"></textarea></div>
      <div class="fg"><label class="fl">Rasm</label><img id="ev_img_preview" class="img-preview" style="display:none"><input type="file" class="fi" id="ev_image" accept="image/*" onchange="previewImg(this,'ev_img_preview')" style="margin-top:6px"></div>
    </div>
    <div class="modal-ft"><button class="btn btn-sm" onclick="closeModal('eventModal')">Bekor</button><button class="btn btn-p" onclick="saveEvent()">Saqlash</button></div>
  </div>
</div>
<script>
const evData=<?= json_encode($pageData['events']) ?>;
function editEvent(id){const ev=evData.find(x=>x.id==id);if(!ev)return;document.getElementById('ev_id').value=ev.id;document.getElementById('ev_title_uz').value=ev.title_uz||'';document.getElementById('ev_title_ru').value=ev.title_ru||'';document.getElementById('ev_location').value=ev.location||'';document.getElementById('ev_date').value=ev.event_date?.slice(0,16)||'';document.getElementById('ev_status').value=ev.status||'upcoming';document.getElementById('ev_body_uz').value=ev.body_uz||'';const prev=document.getElementById('ev_img_preview');if(ev.image){prev.src='/'+ev.image;prev.style.display='block';}else prev.style.display='none';openModal('eventModal');}
async function saveEvent(){const fd=new FormData();fd.append('ajax',1);fd.append('id',document.getElementById('ev_id').value);['title_uz','title_ru','location','ev_date'=>'event_date','status','body_uz'].forEach(k=>{let fk=k==='ev_date'?'event_date':k;let el=document.getElementById('ev_'+k);if(el)fd.append(fk,el.value);});
// Fix: manually add
fd.set('event_date',document.getElementById('ev_date').value);
fd.set('title_uz',document.getElementById('ev_title_uz').value);
fd.set('title_ru',document.getElementById('ev_title_ru').value);
fd.set('location',document.getElementById('ev_location').value);
fd.set('status',document.getElementById('ev_status').value);
fd.set('body_uz',document.getElementById('ev_body_uz').value);
const img=document.getElementById('ev_image');if(img?.files[0])fd.append('image',img.files[0]);
const r=await ajaxPost('/admin?m=events&a=save',fd);if(r.ok){showToast('Saqlandi!');setTimeout(()=>location.reload(),700);}else showToast(r.msg||'Xato','err');}
async function delEvent(id){if(!confirm('O\'chirasizmi?'))return;const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=events&a=delete&id='+id,fd);if(r.ok){showToast('O\'chirildi');location.reload();}}
</script>

<?php
// POLLS
elseif ($mod === 'polls'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">So'rovnomalar</span><button class="btn btn-p" onclick="openModal('pollModal',0)"><i class="bi bi-plus"></i> Qo'shish</button></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>Savol</th><th>Holat</th><th>Yaratilgan</th><th>Amallar</th></tr></thead>
      <tbody>
        <?php foreach($pageData['polls'] as $pl):
          $opts=json_decode($pl['options'],true)??[];
          $votes=json_decode($pl['votes']??'{}',true)??[];
          $total=array_sum($votes);
        ?>
        <tr>
          <td>
            <div style="font-weight:600;max-width:280px"><?= h(mb_substr($pl['question_uz'],0,80)) ?></div>
            <div style="font-size:.72rem;color:var(--text-l)"><?= count($opts) ?> ta variant · <?= $total ?> ta ovoz</div>
          </td>
          <td><?= $pl['is_active']?'<span style="color:var(--a);font-weight:700">Faol</span>':'<span style="color:var(--text-l)">Nofaol</span>' ?></td>
          <td style="font-size:.75rem;color:var(--text-m)"><?= date('d.m.Y',strtotime($pl['created_at'])) ?></td>
          <td><div style="display:flex;gap:4px">
            <button class="btn btn-sm btn-sm-ic" onclick="togglePoll(<?= $pl['id'] ?>)" title="Faol/Nofaol"><i class="bi bi-toggle-on"></i></button>
            <button class="btn btn-r btn-sm-ic" onclick="delPoll(<?= $pl['id'] ?>)"><i class="bi bi-trash"></i></button>
          </div></td>
        </tr>
        <?php endforeach; ?>
        <?php if(empty($pageData['polls'])): ?><tr><td colspan="4" style="text-align:center;padding:32px;color:var(--text-l)">So'rovnomalar yo'q</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<div class="modal-bg" id="pollModal">
  <div class="modal">
    <div class="modal-hd"><span class="modal-title">So'rovnoma</span><button onclick="closeModal('pollModal')"><i class="bi bi-x-lg"></i></button></div>
    <div class="modal-body">
      <div class="fg"><label class="fl">Savol (UZ) *</label><input class="fi" id="poll_q_uz" placeholder="Savol kiriting"></div>
      <div class="fg"><label class="fl">Savol (RU)</label><input class="fi" id="poll_q_ru"></div>
      <div class="fg"><label class="fl">Variantlar *</label>
        <div id="pollOptsWrap" style="display:flex;flex-direction:column;gap:6px">
          <input class="fi poll-opt" placeholder="1-variant">
          <input class="fi poll-opt" placeholder="2-variant">
        </div>
        <button type="button" class="btn btn-sm" style="margin-top:6px" onclick="addOpt()"><i class="bi bi-plus"></i> Variant qo'shish</button>
      </div>
      <div class="fg"><label class="fl">Muddat (ixtiyoriy)</label><input class="fi" id="poll_expires" type="date"></div>
    </div>
    <div class="modal-ft"><button class="btn btn-sm" onclick="closeModal('pollModal')">Bekor</button><button class="btn btn-p" onclick="savePoll()">Saqlash</button></div>
  </div>
</div>
<script>
function addOpt(){const w=document.getElementById('pollOptsWrap');const inp=document.createElement('input');inp.className='fi poll-opt';inp.placeholder=(w.children.length+1)+'-variant';w.appendChild(inp);}
async function savePoll(){
  const fd=new FormData();fd.append('ajax',1);
  fd.append('question_uz',document.getElementById('poll_q_uz').value);
  fd.append('question_ru',document.getElementById('poll_q_ru').value);
  fd.append('expires_at',document.getElementById('poll_expires').value);
  document.querySelectorAll('.poll-opt').forEach(o=>fd.append('options[]',o.value));
  const r=await ajaxPost('/admin?m=polls&a=save',fd);
  if(r.ok){showToast('Saqlandi!');setTimeout(()=>location.reload(),700);}else showToast(r.msg||'Xato','err');
}
async function delPoll(id){if(!confirm('O\'chirasizmi?'))return;const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=polls&a=delete&id='+id,fd);if(r.ok){showToast('O\'chirildi');location.reload();}}
async function togglePoll(id){const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=polls&a=toggle&id='+id,fd);if(r.ok)location.reload();}
</script>

<?php
// ADMINS
elseif ($mod === 'admins'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">Adminlar</span><button class="btn btn-p" onclick="openModal('adminModal',0)"><i class="bi bi-plus"></i> Qo'shish</button></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>#</th><th>Ism</th><th>Login</th><th>Email</th><th>Rol</th><th>Kirgan</th><th>Amallar</th></tr></thead>
      <tbody>
        <?php foreach($pageData['admins'] as $a): ?>
        <tr>
          <td><?= $a['id'] ?></td>
          <td style="font-weight:600"><?= h($a['fullname']) ?></td>
          <td style="font-family:monospace;color:var(--text-m)"><?= h($a['username']) ?></td>
          <td style="font-size:.78rem"><?= h($a['email']) ?></td>
          <td><span style="background:rgba(31,111,235,.12);color:var(--p);padding:2px 8px;border-radius:4px;font-size:.72rem;font-weight:700"><?= h($a['role']) ?></span></td>
          <td style="font-size:.72rem;color:var(--text-m)"><?= $a['last_login']?date('d.m.Y',strtotime($a['last_login'])):'—' ?></td>
          <td><div style="display:flex;gap:4px">
            <button class="btn btn-sm btn-sm-ic" onclick="editAdmin(<?= $a['id'] ?>)"><i class="bi bi-pencil"></i></button>
            <?php if($a['id']!==$admin['id']): ?><button class="btn btn-r btn-sm-ic" onclick="delAdmin(<?= $a['id'] ?>)"><i class="bi bi-trash"></i></button><?php endif; ?>
          </div></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<div class="modal-bg" id="adminModal">
  <div class="modal">
    <div class="modal-hd"><span class="modal-title">Admin</span><button onclick="closeModal('adminModal')"><i class="bi bi-x-lg"></i></button></div>
    <div class="modal-body">
      <input type="hidden" id="adm_id" value="0">
      <div class="frow">
        <div class="fg"><label class="fl">F.I.O *</label><input class="fi" id="adm_fullname"></div>
        <div class="fg"><label class="fl">Login *</label><input class="fi" id="adm_username"></div>
      </div>
      <div class="frow">
        <div class="fg"><label class="fl">Email *</label><input class="fi" id="adm_email" type="email"></div>
        <div class="fg"><label class="fl">Rol</label><select class="fi" id="adm_role"><option value="admin">Admin</option><option value="moderator">Moderator</option><option value="superadmin">Super Admin</option></select></div>
      </div>
      <div class="fg"><label class="fl">Parol <span style="opacity:.6">(o'zgartirish uchun)</span></label><input class="fi" id="adm_pass" type="password" placeholder="Yangi parol"></div>
    </div>
    <div class="modal-ft"><button class="btn btn-sm" onclick="closeModal('adminModal')">Bekor</button><button class="btn btn-p" onclick="saveAdmin()">Saqlash</button></div>
  </div>
</div>
<script>
const admData=<?= json_encode($pageData['admins']) ?>;
function editAdmin(id){const a=admData.find(x=>x.id==id);if(!a)return;document.getElementById('adm_id').value=a.id;document.getElementById('adm_fullname').value=a.fullname;document.getElementById('adm_username').value=a.username;document.getElementById('adm_email').value=a.email;document.getElementById('adm_role').value=a.role;document.getElementById('adm_pass').value='';openModal('adminModal');}
async function saveAdmin(){const fd=new FormData();fd.append('ajax',1);fd.append('id',document.getElementById('adm_id').value);fd.append('fullname',document.getElementById('adm_fullname').value);fd.append('username',document.getElementById('adm_username').value);fd.append('email',document.getElementById('adm_email').value);fd.append('role',document.getElementById('adm_role').value);fd.append('password',document.getElementById('adm_pass').value);const r=await ajaxPost('/admin?m=admins&a=save',fd);if(r.ok){showToast('Saqlandi!');setTimeout(()=>location.reload(),700);}else showToast(r.msg||'Xato','err');}
async function delAdmin(id){if(!confirm('O\'chirasizmi?'))return;const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=admins&a=delete&id='+id,fd);if(r.ok){showToast('O\'chirildi');location.reload();}}
</script>

<?php
// LOGS
elseif ($mod === 'logs'):
?>
<div class="card">
  <div class="card-hd"><span class="card-title">So'nggi loglar (100 ta)</span></div>
  <div class="tbl-wrap">
    <table class="tbl">
      <thead><tr><th>Admin</th><th>Amal</th><th>IP</th><th>Sana</th></tr></thead>
      <tbody>
        <?php foreach($pageData['logs'] as $l): ?>
        <tr>
          <td><?= h($l['fullname']??'—') ?></td>
          <td><code style="background:var(--bg3);padding:2px 6px;border-radius:4px;font-size:.75rem"><?= h($l['action']) ?></code></td>
          <td style="font-size:.75rem;color:var(--text-m)"><?= h($l['ip']??'—') ?></td>
          <td style="font-size:.72rem;color:var(--text-m)"><?= date('d.m.Y H:i',strtotime($l['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

  </div><!-- /cnt -->
</div><!-- /main -->

<script>
// ============================================================
// GLOBAL JS
// ============================================================
// Toast
function showToast(msg,type='ok'){
  const t=document.getElementById('toast');
  t.innerHTML=(type==='ok'?'<i class="bi bi-check-circle-fill" style="color:#3FB950"></i>':'<i class="bi bi-exclamation-circle-fill" style="color:#F85149"></i>')+' '+msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),3000);
}

// AJAX POST
async function ajaxPost(url,fd){
  try{const r=await fetch(url,{method:'POST',body:fd});return await r.json();}
  catch(e){return{ok:false,msg:'Ulanish xatosi'};}
}

// Modal
function openModal(id){document.getElementById(id).classList.add('open');}
function closeModal(id){document.getElementById(id).classList.remove('open');}
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal-bg.open').forEach(m=>m.classList.remove('open'));});
document.querySelectorAll('.modal-bg').forEach(m=>{m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('open');});});

// Tabs
function switchTab(btn,tabId){
  const parent=btn.closest('.tabs');
  parent.querySelectorAll('.tab').forEach(t=>t.classList.remove('on'));
  btn.classList.add('on');
  const allTabs=btn.closest('.card,.modal-body')?.querySelectorAll('[id^="tab-"],[id^="st-"],[id^="fq-"],[id^="set-"],[id^="fk-"]')||document.querySelectorAll('[id]');
  // Find sibling tab panels
  const panels=[];
  const prefixMatch=tabId.split('-').slice(0,-1).join('-');
  document.querySelectorAll('[id^="'+prefixMatch+'"]').forEach(p=>{if(p.id!==tabId&&p.id.startsWith(prefixMatch+'-'))panels.push(p);});
  panels.forEach(p=>p.style.display='none');
  const target=document.getElementById(tabId);
  if(target) target.style.display='block';
}

// Img preview
function previewImg(inp,previewId){
  const f=inp.files[0]; if(!f) return;
  const prev=document.getElementById(previewId);
  prev.src=URL.createObjectURL(f); prev.style.display='block';
}

// Dashboard grid
function fixDbGrid(){
  const g=document.getElementById('dbGrid');
  if(g) g.style.gridTemplateColumns=window.innerWidth>=768?'1fr 1fr':'1fr';
}
fixDbGrid(); window.addEventListener('resize',fixDbGrid);

// POST functions
async function delPost(id){if(!confirm('Postni o\'chirasizmi?'))return;const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=posts&a=delete&id='+id,fd);if(r.ok){showToast('O\'chirildi');location.reload();}else showToast(r.msg||'Xato','err');}

async function togglePin(id,btn){const fd=new FormData();fd.append('ajax',1);const r=await ajaxPost('/admin?m=posts&a=toggle_pin&id='+id,fd);if(r.ok){showToast(r.pinned?'Muhim qilindi':'Pin olib tashlandi');location.reload();}else showToast('Xato','err');}

async function savePost(){
  const fd=new FormData();
  fd.append('ajax',1);
  fd.append('id',document.getElementById('pId')?.value||0);
  fd.append('title_uz',document.getElementById('p_title_uz')?.value||'');
  fd.append('title_cy',document.getElementById('p_title_cy')?.value||'');
  fd.append('title_ru',document.getElementById('p_title_ru')?.value||'');
  fd.append('body_uz',document.getElementById('p_body_uz')?.value||'');
  fd.append('body_cy',document.getElementById('p_body_cy')?.value||'');
  fd.append('body_ru',document.getElementById('p_body_ru')?.value||'');
  fd.append('cat_id',document.getElementById('p_cat_id')?.value||1);
  fd.append('status',document.getElementById('p_status')?.value||'published');
  fd.append('is_pinned',document.getElementById('p_pinned')?.checked?1:0);
  fd.append('is_featured',document.getElementById('p_featured')?.checked?1:0);
  const img=document.getElementById('p_image');
  if(img?.files[0]) fd.append('image',img.files[0]);
  const al=document.getElementById('formAlert');
  const r=await ajaxPost('/admin?m=posts&a=save',fd);
  if(r.ok){al.innerHTML='<div class="alert alert-ok"><i class="bi bi-check-circle-fill"></i> Saqlandi!</div>';showToast('Post saqlandi!');setTimeout(()=>location.href='/admin?m=posts',900);}
  else{al.innerHTML='<div class="alert alert-err">'+r.msg+'</div>';showToast(r.msg||'Xato','err');}
}

// Appeal reply
async function sendReply(id){
  const text=document.getElementById('repText')?.value?.trim();
  const status=document.getElementById('repStatus')?.value;
  if(!text){showToast('Javob kiriting','err');return;}
  const fd=new FormData(); fd.append('ajax',1); fd.append('reply',text); fd.append('status',status);
  const r=await ajaxPost('/admin?m=appeals&a=reply&id='+id,fd);
  const al=document.getElementById('replyAlert');
  if(r.ok){al.innerHTML='<div class="alert alert-ok"><i class="bi bi-check-circle-fill"></i> Javob yuborildi!</div>';showToast('Javob saqlandi!');}
  else{al.innerHTML='<div class="alert alert-err">'+(r.msg||'Xato')+'</div>';showToast('Xato','err');}
}

// Drag & drop for upload
const ua=document.getElementById('uploadArea');
if(ua){
  ua.addEventListener('dragover',e=>{e.preventDefault();ua.classList.add('drag');});
  ua.addEventListener('dragleave',()=>ua.classList.remove('drag'));
  ua.addEventListener('drop',e=>{e.preventDefault();ua.classList.remove('drag');const f=document.getElementById('gal_files');if(f&&e.dataTransfer.files.length){const dt=new DataTransfer();for(const file of e.dataTransfer.files)dt.items.add(file);f.files=dt.files;showFilenames(f);}});
}
</script>
</body>
</html>
