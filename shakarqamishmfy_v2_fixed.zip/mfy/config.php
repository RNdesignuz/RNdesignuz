<?php
// ============================================================
// ShakarqamishMFY — Konfiguratsiya
// ============================================================
define('DB_HOST', 'localhost');
define('DB_NAME', 'c552_mahalla');
define('DB_USER', 'c552_mahalla');
define('DB_PASS', '21-Mart2001');
define('DB_CHARSET', 'utf8mb4');

define('SITE_URL',   'https://shakarqamishmfy.uz');
define('SITE_NAME',  'ShakarqamishMFY');
define('ADMIN_PATH', 'admin');
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('UPLOAD_URL', SITE_URL . '/uploads/');

// Session
define('SESSION_NAME', 'smfy_sess');
define('SESSION_LIFE', 7200);

// Xavfsizlik
define('APP_KEY', 'smfy_secret_key_2025_change_me');

error_reporting(0);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Tashkent');
mb_internal_encoding('UTF-8');

// Session
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    session_name(SESSION_NAME);
    session_start();
}

// Upload papka
if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);

// ============================================================
// DATABASE
// ============================================================
function db(): PDO {
    static $pdo = null;
    if ($pdo) return $pdo;
    try {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        die(json_encode(['ok' => false, 'msg' => 'DB ulanmadi: ' . $e->getMessage()]));
    }
    return $pdo;
}

function q(string $sql, array $p = []): PDOStatement {
    $s = db()->prepare($sql);
    $s->execute($p);
    return $s;
}
function row(string $sql, array $p = []): ?array   { return q($sql, $p)->fetch() ?: null; }
function rows(string $sql, array $p = []): array   { return q($sql, $p)->fetchAll(); }
function val(string $sql, array $p = []): mixed    { return q($sql, $p)->fetchColumn(); }
function ins(string $t, array $d): string {
    $cols = implode(',', array_map(fn($k) => "`$k`", array_keys($d)));
    $phs  = implode(',', array_fill(0, count($d), '?'));
    q("INSERT INTO `$t` ($cols) VALUES ($phs)", array_values($d));
    return db()->lastInsertId();
}
function upd(string $t, array $d, string $w, array $wp = []): void {
    $set = implode(',', array_map(fn($k) => "`$k`=?", array_keys($d)));
    q("UPDATE `$t` SET $set WHERE $w", array_merge(array_values($d), $wp));
}

// ============================================================
// YORDAMCHI
// ============================================================
function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
function slug(string $t): string {
    $m = ['а'=>'a','б'=>'b','в'=>'v','г'=>'g','д'=>'d','е'=>'e','ё'=>'yo','ж'=>'j','з'=>'z','и'=>'i','й'=>'y','к'=>'k','л'=>'l','м'=>'m','н'=>'n','о'=>'o','п'=>'p','р'=>'r','с'=>'s','т'=>'t','у'=>'u','ф'=>'f','х'=>'x','ц'=>'ts','ч'=>'ch','ш'=>'sh','щ'=>'sh','ъ'=>'','ы'=>'i','ь'=>'','э'=>'e','ю'=>'yu','я'=>'ya',"o'"=>'o',"g'"=>'g','ğ'=>'g','ş'=>'sh'];
    $t = mb_strtolower(strtr($t, $m));
    $t = preg_replace('/[^a-z0-9]+/', '-', $t);
    return trim($t, '-') ?: 'post-' . time();
}
function uslug(string $t, string $tbl, int $excl = 0): string {
    $base = $s = slug($t); $i = 1;
    while (val("SELECT id FROM `$tbl` WHERE slug=? AND id!=?", [$s, $excl])) $s = $base . '-' . $i++;
    return $s;
}
function ticket(): string {
    return 'MFY-' . date('y') . '-' . strtoupper(bin2hex(random_bytes(3)));
}
function csrf(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(24));
    return $_SESSION['csrf'];
}
function vcsrf(): bool {
    return !empty($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf']);
}
function ago(string $dt): string {
    $diff = time() - strtotime($dt);
    if ($diff < 60)     return $diff . ' soniya oldin';
    if ($diff < 3600)   return intdiv($diff, 60) . ' daqiqa oldin';
    if ($diff < 86400)  return intdiv($diff, 3600) . ' soat oldin';
    if ($diff < 604800) return intdiv($diff, 86400) . ' kun oldin';
    return date('d.m.Y', strtotime($dt));
}
function fdate(string $dt): string { return date('d.m.Y', strtotime($dt)); }

// Fayl yuklash
function uploadFile(array $f, string $sub = 'general'): ?string {
    if ($f['error'] !== 0) return null;
    if ($f['size'] > 8 * 1024 * 1024) return null;
    $ext  = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
    $ok   = ['jpg','jpeg','png','gif','webp','pdf','doc','docx','xls','xlsx'];
    if (!in_array($ext, $ok)) return null;
    $dir  = UPLOAD_DIR . $sub . '/' . date('Y/m') . '/';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $name = bin2hex(random_bytes(10)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], $dir . $name)) return null;
    return 'uploads/' . $sub . '/' . date('Y/m') . '/' . $name;
}

// Auth
function isAdmin(): bool {
    return !empty($_SESSION['admin_id']);
}
function requireAdmin(): void {
    if (!isAdmin()) { header('Location: /' . ADMIN_PATH . '/login'); exit; }
}

// JSON javob
function jsonOut(mixed $d, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($d, JSON_UNESCAPED_UNICODE);
    exit;
}

// Settings
function setting(string $key, string $def = ''): string {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try { foreach (rows("SELECT `key`,`value` FROM settings") as $r) $cache[$r['key']] = $r['value']; } catch(Exception $e) {}
    }
    return $cache[$key] ?? $def;
}
