<?php
require_once __DIR__ . '/config.php';

// ============================================================
// TIL TIZIMI
// ============================================================
$langs = ['uz' => 'O\'zbekcha', 'cy' => 'Ўзбекча', 'ru' => 'Русский'];
if (!empty($_GET['lang']) && isset($langs[$_GET['lang']])) {
    $_SESSION['lang'] = $_GET['lang'];
    // Faqat o'z domenimizdan kelsa — ochiq redirect oldini olish
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    $back = '/';
    if ($referer) {
        $refHost = parse_url($referer, PHP_URL_HOST);
        $ownHost = parse_url(SITE_URL, PHP_URL_HOST);
        if ($refHost === $ownHost) {
            $back = strtok($referer, '?') ?: '/';
        }
    }
    header('Location: ' . $back);
    exit;
}
$lang = $_SESSION['lang'] ?? 'uz';

function t(array $row, string $field): string {
    global $lang;
    $col = $field . '_' . $lang;
    if (!empty($row[$col])) return $row[$col];
    if (!empty($row[$field . '_uz'])) return $row[$field . '_uz'];
    return $row[$field] ?? '';
}

// ============================================================
// ROUTING
// ============================================================
$uri   = rtrim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/') ?: '/';
$query = $_GET;
$page  = $query['p'] ?? 'home';

// Eski URL-lar uchun ham
if ($uri === '/yangiliklar') $page = 'news';
elseif ($uri === '/elonlar')  $page = 'elonlar';
elseif ($uri === '/kengash')  $page = 'kengash';
elseif ($uri === '/galereya') $page = 'galereya';
elseif ($uri === '/hujjatlar')$page = 'hujjatlar';
elseif ($uri === '/faq')      $page = 'faq';
elseif ($uri === '/murojaat') $page = 'murojaat';
elseif ($uri === '/tadbirlar')$page = 'tadbirlar';
elseif ($uri === '/mahalla')  $page = 'mahalla';
elseif (preg_match('#^/post/(.+)$#', $uri, $m)) { $page = 'post'; $query['slug'] = $m[1]; }

// ============================================================
// AJAX / FORM HANDLERS
// ============================================================
// CSRF token hosil qilish (barcha sahifalar uchun)
$csrfToken = csrf();

if (!empty($_POST['action'])) {
    $action = $_POST['action'];

    // Murojaat yuborish
    if ($action === 'appeal') {
        if (!vcsrf()) jsonOut(['ok'=>false,'msg'=>'Xavfsizlik xatosi. Sahifani yangilab qayta urinib ko\'ring.']);
        $fn   = trim($_POST['fullname'] ?? '');
        $ph   = trim($_POST['phone'] ?? '');
        $subj = trim($_POST['subject'] ?? '');
        $body = trim($_POST['body'] ?? '');
        $type = $_POST['type'] ?? 'ariza';
        $prio = $_POST['priority'] ?? 'normal';
        $anon = !empty($_POST['is_anon']) ? 1 : 0;
        $addr = trim($_POST['address'] ?? '');

        if (mb_strlen($fn) < 2 || mb_strlen($ph) < 7 || mb_strlen($subj) < 3 || mb_strlen($body) < 10)
            jsonOut(['ok'=>false,'msg'=>'Barcha maydonlarni to\'liq to\'ldiring']);

        $validTypes = ['shikoyat','taklif','ariza','muammo','kommunal','yoshlar','ayollar','minnatdorchilik'];
        if (!in_array($type, $validTypes)) $type = 'ariza';
        if (!in_array($prio, ['low','normal','high','urgent'])) $prio = 'normal';

        $file = null;
        if (!empty($_FILES['file']['tmp_name'])) $file = uploadFile($_FILES['file'], 'appeals');

        $tk = ticket();
        ins('appeals', [
            'ticket'   => $tk,
            'fullname' => mb_substr(h($fn),0,150),
            'phone'    => mb_substr($ph,0,20),
            'address'  => mb_substr(h($addr),0,300),
            'type'     => $type,
            'subject'  => mb_substr(h($subj),0,300),
            'body'     => mb_substr(h($body),0,5000),
            'priority' => $prio,
            'is_anon'  => $anon,
            'file'     => $file,
            'ip'       => $_SERVER['REMOTE_ADDR'] ?? '',
        ]);

        // Telegram
        $tg_token = setting('telegram_bot');
        $tg_chat  = setting('telegram_chat');
        if ($tg_token && $tg_chat) {
            $nm = $anon ? 'Anonim' : $fn;
            $msg = "📨 *Yangi murojaat!*\n🎫 `$tk`\n👤 $nm\n📞 $ph\n📂 $type\n📝 $subj\n\n" . mb_substr($body,0,300);
            @file_get_contents("https://api.telegram.org/bot$tg_token/sendMessage?" . http_build_query([
                'chat_id'=>$tg_chat,'text'=>$msg,'parse_mode'=>'Markdown'
            ]));
        }

        jsonOut(['ok'=>true,'ticket'=>$tk]);
    }

    // Murojaat holati
    if ($action === 'check_appeal') {
        $tk = strtoupper(trim($_POST['ticket'] ?? ''));
        if (!$tk) jsonOut(['ok'=>false,'msg'=>'Ticket kiriting']);
        $a = row("SELECT ticket,subject,type,status,priority,created_at,reply FROM appeals WHERE ticket=?", [$tk]);
        if (!$a) jsonOut(['ok'=>false,'msg'=>'Murojaat topilmadi']);
        jsonOut(['ok'=>true,'data'=>$a]);
    }

    // Ovoz berish
    if ($action === 'vote') {
        if (!vcsrf()) jsonOut(['ok'=>false,'msg'=>'Xavfsizlik xatosi.']);
        $pid = (int)($_POST['poll_id'] ?? 0);
        $opt = (int)($_POST['option'] ?? 0);
        $ip  = $_SERVER['REMOTE_ADDR'] ?? '0';
        $poll = row("SELECT * FROM polls WHERE id=? AND is_active=1", [$pid]);
        if (!$poll) jsonOut(['ok'=>false,'msg'=>'So\'rovnoma topilmadi']);
        $exists = val("SELECT COUNT(*) FROM poll_votes WHERE poll_id=? AND ip=?", [$pid, $ip]);
        if ($exists) jsonOut(['ok'=>false,'msg'=>'Siz allaqachon ovoz berdingiz']);
        $opts = json_decode($poll['options'], true);
        if (!isset($opts[$opt])) jsonOut(['ok'=>false,'msg'=>'Variant topilmadi']);
        ins('poll_votes', ['poll_id'=>$pid,'opt'=>$opt,'ip'=>$ip]);
        $votes = json_decode($poll['votes'] ?? '{}', true) ?: [];
        $votes[$opt] = ($votes[$opt] ?? 0) + 1;
        upd('polls', ['votes'=>json_encode($votes)], 'id=?', [$pid]);
        $total = array_sum($votes);
        $result = [];
        foreach ($opts as $i => $o) {
            $cnt = $votes[$i] ?? 0;
            $result[] = ['text'=>$o, 'count'=>$cnt, 'pct'=>$total ? round($cnt/$total*100) : 0];
        }
        jsonOut(['ok'=>true,'total'=>$total,'results'=>$result]);
    }

    exit;
}

// ============================================================
// Ma'lumotlar (sahifaga qarab)
// ============================================================
$data = [];

if ($page === 'home') {
    $data['sliders']  = rows("SELECT * FROM sliders WHERE is_active=1 ORDER BY sort LIMIT 5");
    $data['pinned']   = rows("SELECT p.*,c.name_uz,c.name_cy,c.name_ru,c.slug as cslug,c.color FROM posts p JOIN categories c ON c.id=p.cat_id WHERE p.status='published' AND p.is_pinned=1 ORDER BY p.created_at DESC LIMIT 3");
    $data['news']     = rows("SELECT p.*,c.name_uz,c.name_cy,c.name_ru,c.color FROM posts p JOIN categories c ON c.id=p.cat_id WHERE p.status='published' AND p.cat_id=1 ORDER BY p.created_at DESC LIMIT 6");
    $data['elonlar']  = rows("SELECT p.*,c.name_uz,c.name_cy,c.name_ru,c.color FROM posts p JOIN categories c ON c.id=p.cat_id WHERE p.status='published' AND p.cat_id=2 ORDER BY p.created_at DESC LIMIT 4");
    $data['staff']    = rows("SELECT * FROM staff WHERE is_active=1 ORDER BY sort LIMIT 4");
    $data['gallery']  = rows("SELECT * FROM gallery ORDER BY sort,created_at DESC LIMIT 8");
    $data['events']   = rows("SELECT * FROM events WHERE event_date >= NOW() ORDER BY event_date LIMIT 3");
    $data['poll']     = row("SELECT * FROM polls WHERE is_active=1 ORDER BY created_at DESC LIMIT 1");
    $data['faqs']     = rows("SELECT * FROM faqs ORDER BY sort LIMIT 5");
    $data['docs']     = rows("SELECT * FROM documents ORDER BY created_at DESC LIMIT 4");
    $data['cats']     = rows("SELECT * FROM categories ORDER BY sort");
    $data['stats']    = [
        'population' => setting('population','0'),
        'households' => setting('households','0'),
        'streets'    => setting('streets','0'),
        'founded'    => setting('founded_year','1992'),
        'posts'      => val("SELECT COUNT(*) FROM posts WHERE status='published'"),
        'appeals_done'=> val("SELECT COUNT(*) FROM appeals WHERE status='resolved'"),
    ];
}
elseif ($page === 'news') {
    $cat   = (int)($query['cat'] ?? 1);
    $pg    = max(1,(int)($query['pg'] ?? 1));
    $limit = 9;
    $data['cats']  = rows("SELECT * FROM categories ORDER BY sort");
    $data['total'] = (int)val("SELECT COUNT(*) FROM posts WHERE status='published' AND cat_id=?", [$cat]);
    $data['posts'] = rows("SELECT p.*,c.name_uz,c.name_cy,c.name_ru,c.color FROM posts p JOIN categories c ON c.id=p.cat_id WHERE p.status='published' AND p.cat_id=? ORDER BY p.is_pinned DESC,p.created_at DESC LIMIT $limit OFFSET ". ($pg-1)*$limit, [$cat]);
    $data['cat']   = row("SELECT * FROM categories WHERE id=?", [$cat]);
    $data['pg']    = $pg;
    $data['pages'] = max(1, (int)ceil($data['total']/$limit));
}
elseif ($page === 'elonlar') {
    $pg = max(1,(int)($query['pg'] ?? 1));
    $limit = 9;
    $data['total'] = (int)val("SELECT COUNT(*) FROM posts WHERE status='published' AND cat_id=2");
    $data['posts'] = rows("SELECT p.*,c.name_uz,c.name_cy,c.name_ru,c.color FROM posts p JOIN categories c ON c.id=p.cat_id WHERE p.status='published' AND cat_id=2 ORDER BY p.is_pinned DESC,p.created_at DESC LIMIT $limit OFFSET ".($pg-1)*$limit);
    $data['pg']    = $pg;
    $data['pages'] = max(1,(int)ceil($data['total']/$limit));
}
elseif ($page === 'post') {
    $sl = $query['slug'] ?? '';
    $data['post'] = row("SELECT p.*,c.name_uz,c.name_cy,c.name_ru,c.color FROM posts p JOIN categories c ON c.id=p.cat_id WHERE p.slug=? AND p.status='published'", [$sl]);
    if ($data['post']) {
        q("UPDATE posts SET views=views+1 WHERE slug=?", [$sl]);
        $data['related'] = rows("SELECT p.*,c.name_uz,c.color FROM posts p JOIN categories c ON c.id=p.cat_id WHERE p.status='published' AND p.cat_id=? AND p.slug!=? ORDER BY RAND() LIMIT 3", [$data['post']['cat_id'],$sl]);
    }
}
elseif ($page === 'kengash') {
    $data['staff'] = rows("SELECT * FROM staff WHERE is_active=1 ORDER BY sort");
    $data['single'] = null;
    if (!empty($query['id'])) $data['single'] = row("SELECT * FROM staff WHERE id=?", [(int)$query['id']]);
}
elseif ($page === 'galereya') {
    $data['albums'] = rows("SELECT DISTINCT album FROM gallery WHERE album IS NOT NULL AND album!='' ORDER BY album");
    $alb = $query['album'] ?? '';
    if ($alb) $data['photos'] = rows("SELECT * FROM gallery WHERE album=? ORDER BY sort,created_at DESC", [$alb]);
    else $data['photos'] = rows("SELECT * FROM gallery ORDER BY sort,created_at DESC");
}
elseif ($page === 'hujjatlar') {
    $data['cats'] = rows("SELECT DISTINCT cat FROM documents WHERE cat IS NOT NULL AND cat!='' ORDER BY cat");
    $cat = $query['cat'] ?? '';
    if ($cat) $data['docs'] = rows("SELECT * FROM documents WHERE cat=? ORDER BY created_at DESC", [$cat]);
    else $data['docs'] = rows("SELECT * FROM documents ORDER BY created_at DESC");
    // Download
    if (!empty($query['dl'])) {
        $doc = row("SELECT * FROM documents WHERE id=?", [(int)$query['dl']]);
        if ($doc) {
            q("UPDATE documents SET downloads=downloads+1 WHERE id=?", [(int)$query['dl']]);
            header('Location: /' . $doc['file']);
            exit;
        }
    }
}
elseif ($page === 'faq') {
    $data['faqs'] = rows("SELECT * FROM faqs ORDER BY sort");
}
elseif ($page === 'tadbirlar') {
    $data['upcoming'] = rows("SELECT * FROM events WHERE event_date>=NOW() AND status='upcoming' ORDER BY event_date");
    $data['past']     = rows("SELECT * FROM events WHERE event_date<NOW() OR status='done' ORDER BY event_date DESC LIMIT 6");
}
elseif ($page === 'mahalla') {
    $data['staff_count'] = val("SELECT COUNT(*) FROM staff WHERE is_active=1");
}

// ============================================================
// SETTINGS
// ============================================================
$siteName = setting('site_name', SITE_NAME);
$ticker   = setting('ticker_text', 'ShakarqamishMFY portaliga xush kelibsiz!');

// Page title
$pageTitles = [
    'home'     => $siteName . ' — Rasmiy Portal',
    'news'     => 'Yangiliklar — ' . $siteName,
    'elonlar'  => "E'lonlar — " . $siteName,
    'post'     => (t($data['post'] ?? ['title_uz'=>'Post'], 'title')) . ' — ' . $siteName,
    'kengash'  => 'Kengash — ' . $siteName,
    'galereya' => 'Galereya — ' . $siteName,
    'hujjatlar'=> 'Hujjatlar — ' . $siteName,
    'faq'      => 'FAQ — ' . $siteName,
    'murojaat' => 'Murojaat — ' . $siteName,
    'tadbirlar'=> 'Tadbirlar — ' . $siteName,
    'mahalla'  => 'Mahalla haqida — ' . $siteName,
];
$pageTitle = $pageTitles[$page] ?? $siteName;

// Til labellari
$i18n = [
    'uz' => [
        'home'=>'Bosh sahifa','news'=>'Yangiliklar','elonlar'=>"E'lonlar",
        'kengash'=>'Kengash','galereya'=>'Galereya','hujjatlar'=>'Hujjatlar',
        'faq'=>'FAQ','murojaat'=>'Murojaat','tadbirlar'=>'Tadbirlar','mahalla'=>'Mahalla haqida',
        'more'=>"Ko'proq",'all'=>'Barchasi','read'=>"O'qish",'send'=>'Yuborish',
        'search'=>'Qidirish','views'=>"Ko'rishlar",'date'=>'Sana','download'=>'Yuklab olish',
        'population'=>'Aholi','households'=>"Uy-xonadonlar",'streets'=>"Ko'chalar",
        'founded'=>'Tashkil topgan','appeals'=>'Murojaatlar',
        'appeal_form'=>'Murojaat shakli','appeal_check'=>'Murojaat holati',
        'name'=>'Ism Familiya','phone'=>'Telefon','address'=>'Manzil',
        'subject'=>'Mavzu','message'=>'Murojaat matni','type'=>'Murojaat turi',
        'priority'=>'Muhimlik darajasi','anon'=>'Anonim yuborish',
        'ticket_ph'=>'MFY-XX-XXXXXX','check'=>'Tekshirish',
        'upcoming'=>"Kelgusi tadbirlar",'past'=>"O'tgan tadbirlar",
        'no_data'=>"Ma'lumot topilmadi",'loading'=>'Yuklanmoqda...',
        'vote'=>'Ovoz berish','vote_done'=>'Ovoz berildi!',
        'new'=>'Yangi','processing'=>"Ko'rib chiqilmoqda",'resolved'=>'Hal qilindi','rejected'=>'Rad etildi',
        'lang_uz'=>"O'zbekcha",'lang_cy'=>'Ўзбекча','lang_ru'=>'Русский',
        'copy_link'=>'Havolani nusxa olish','share'=>'Ulashish',
        'pinned'=>'Muhim','featured'=>'Tanlangan',
    ],
    'cy' => [
        'home'=>'Бош саҳифа','news'=>'Янгиликлар','elonlar'=>'Эълонлар',
        'kengash'=>'Кенгаш','galereya'=>'Галерея','hujjatlar'=>'Ҳужжатлар',
        'faq'=>'FAQ','murojaat'=>'Мурожаат','tadbirlar'=>'Тадбирлар','mahalla'=>'Маҳалла ҳақида',
        'more'=>'Кўпроқ','all'=>'Барчаси','read'=>'Ўқиш','send'=>'Юбориш',
        'search'=>'Қидириш','views'=>'Кўришлар','date'=>'Сана','download'=>'Юклаб олиш',
        'population'=>'Аҳоли','households'=>'Уй-хонадонлар','streets'=>'Кўчалар',
        'founded'=>'Ташкил топган','appeals'=>'Мурожаатлар',
        'appeal_form'=>'Мурожаат шакли','appeal_check'=>'Мурожаат ҳолати',
        'name'=>'Исм Фамилия','phone'=>'Телефон','address'=>'Манзил',
        'subject'=>'Мавзу','message'=>'Мурожаат матни','type'=>'Мурожаат тури',
        'priority'=>'Муҳимлик даражаси','anon'=>'Аноним юбориш',
        'ticket_ph'=>'MFY-XX-XXXXXX','check'=>'Текшириш',
        'upcoming'=>'Келгуси тадбирлар','past'=>'Ўтган тадбирлар',
        'no_data'=>'Маълумот топилмади','loading'=>'Юкланмоқда...',
        'vote'=>'Овоз бериш','vote_done'=>'Овоз берилди!',
        'new'=>'Янги','processing'=>'Кўриб чиқилмоқда','resolved'=>'Ҳал қилинди','rejected'=>'Рад этилди',
        'lang_uz'=>"O'zbekcha",'lang_cy'=>'Ўзбекча','lang_ru'=>'Русский',
        'copy_link'=>'Ҳаволани нусха олиш','share'=>'Улашиш',
        'pinned'=>'Муҳим','featured'=>'Танланган',
    ],
    'ru' => [
        'home'=>'Главная','news'=>'Новости','elonlar'=>'Объявления',
        'kengash'=>'Совет','galereya'=>'Галерея','hujjatlar'=>'Документы',
        'faq'=>'FAQ','murojaat'=>'Обращение','tadbirlar'=>'Мероприятия','mahalla'=>'О махалле',
        'more'=>'Ещё','all'=>'Все','read'=>'Читать','send'=>'Отправить',
        'search'=>'Поиск','views'=>'Просмотры','date'=>'Дата','download'=>'Скачать',
        'population'=>'Население','households'=>'Домохозяйства','streets'=>'Улицы',
        'founded'=>'Основан','appeals'=>'Обращения',
        'appeal_form'=>'Форма обращения','appeal_check'=>'Статус обращения',
        'name'=>'ФИО','phone'=>'Телефон','address'=>'Адрес',
        'subject'=>'Тема','message'=>'Текст обращения','type'=>'Тип обращения',
        'priority'=>'Приоритет','anon'=>'Анонимно',
        'ticket_ph'=>'MFY-XX-XXXXXX','check'=>'Проверить',
        'upcoming'=>'Предстоящие мероприятия','past'=>'Прошедшие мероприятия',
        'no_data'=>'Данные не найдены','loading'=>'Загрузка...',
        'vote'=>'Голосовать','vote_done'=>'Голос принят!',
        'new'=>'Новый','processing'=>'Рассматривается','resolved'=>'Решено','rejected'=>'Отклонено',
        'lang_uz'=>"O'zbekcha",'lang_cy'=>'Ўзбекча','lang_ru'=>'Русский',
        'copy_link'=>'Копировать ссылку','share'=>'Поделиться',
        'pinned'=>'Важное','featured'=>'Избранное',
    ],
];
$L = $i18n[$lang];

?><!DOCTYPE html>
<html lang="<?= $lang === 'ru' ? 'ru' : 'uz' ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<meta name="description" content="<?= h(setting('meta_desc')) ?>">
<title><?= h($pageTitle) ?></title>
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
/* ======================================================
   CSS VARIABLES
====================================================== */
:root {
  --c-p:   #1A56DB;
  --c-pd:  #1148B4;
  --c-pl:  #EBF2FF;
  --c-a:   #0E9F6E;
  --c-al:  #E6FFF4;
  --c-g:   #F8A100;
  --c-r:   #E02424;
  --c-rl:  #FEF2F2;
  --c-bg:  #F3F6FB;
  --c-bg2: #FFFFFF;
  --c-t:   #111928;
  --c-tm:  #4B5563;
  --c-tl:  #9CA3AF;
  --c-br:  #E5E7EB;
  --sh:    0 1px 3px rgba(0,0,0,.08),0 4px 16px rgba(26,86,219,.07);
  --sh-h:  0 4px 12px rgba(0,0,0,.1),0 12px 40px rgba(26,86,219,.14);
  --r:     12px;
  --r-sm:  8px;
  --tr:    .25s ease;
  --font:  'Inter', system-ui, sans-serif;
  --serif: 'Playfair Display', Georgia, serif;
  --sbw:   260px;
}
[data-theme="dark"] {
  --c-bg:  #111827;
  --c-bg2: #1F2937;
  --c-t:   #F9FAFB;
  --c-tm:  #D1D5DB;
  --c-tl:  #6B7280;
  --c-br:  #374151;
  --c-pl:  #1E3A5F;
}

/* ======================================================
   RESET
====================================================== */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth;-webkit-text-size-adjust:100%}
body{font-family:var(--font);background:var(--c-bg);color:var(--c-t);line-height:1.6;-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}
img{max-width:100%;height:auto;display:block}
ul,ol{list-style:none}
button,input,select,textarea{font-family:inherit;font-size:inherit}
button{cursor:pointer;border:none;background:none}
:focus-visible{outline:2px solid var(--c-p);outline-offset:2px}

/* ======================================================
   LAYOUT
====================================================== */
.wrap{width:100%;max-width:1280px;margin:0 auto;padding:0 16px}
@media(min-width:768px){.wrap{padding:0 24px}}
@media(min-width:1024px){.wrap{padding:0 32px}}

/* ======================================================
   TOPBAR
====================================================== */
.topbar{
  background:var(--c-pd);
  color:rgba(255,255,255,.85);
  font-size:.75rem;
  padding:5px 0;
}
.topbar-in{
  display:flex;justify-content:space-between;align-items:center;
  flex-wrap:wrap;gap:6px;
}
.topbar a{color:rgba(255,255,255,.85);transition:color var(--tr)}
.topbar a:hover{color:#fff}
.topbar-l,.topbar-r{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
#tb-clock{font-weight:600;color:#fff}
.tb-weather{display:flex;align-items:center;gap:4px}

/* ======================================================
   HEADER
====================================================== */
.site-header{
  background:var(--c-bg2);
  border-bottom:1px solid var(--c-br);
  position:sticky;top:0;z-index:900;
  box-shadow:0 1px 8px rgba(0,0,0,.06);
  transition:box-shadow var(--tr);
}
.header-in{
  display:flex;align-items:center;gap:16px;
  padding:10px 0;
}
.logo{display:flex;align-items:center;gap:12px;flex-shrink:0}
.logo-ico{
  width:46px;height:46px;border-radius:10px;
  background:linear-gradient(135deg,var(--c-p),var(--c-pd));
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:1.3rem;flex-shrink:0;
  box-shadow:0 2px 8px rgba(26,86,219,.3);
}
.logo-txt h1{font-size:1.05rem;font-weight:800;color:var(--c-p);line-height:1.1}
.logo-txt p{font-size:.6rem;color:var(--c-tl);font-weight:600;letter-spacing:.3px;white-space:nowrap}

/* Desktop nav */
.main-nav{
  display:none;
  flex:1;justify-content:center;
}
@media(min-width:1024px){.main-nav{display:flex;align-items:center;gap:2px}}
.main-nav a{
  padding:7px 11px;border-radius:7px;font-weight:600;font-size:.83rem;
  color:var(--c-tm);transition:all var(--tr);white-space:nowrap;
}
.main-nav a:hover,.main-nav a.active{
  background:var(--c-pl);color:var(--c-p);
}

/* Header actions */
.h-actions{display:flex;align-items:center;gap:8px;margin-left:auto;flex-shrink:0}
.h-btn{
  width:36px;height:36px;border-radius:8px;border:1.5px solid var(--c-br);
  background:none;color:var(--c-tm);font-size:1rem;
  display:flex;align-items:center;justify-content:center;
  transition:all var(--tr);flex-shrink:0;
}
.h-btn:hover{background:var(--c-pl);color:var(--c-p);border-color:var(--c-p)}

/* Language switcher */
.lang-sw{
  display:flex;gap:2px;background:var(--c-bg);
  border:1.5px solid var(--c-br);border-radius:8px;padding:2px;
}
.lang-sw a{
  padding:3px 9px;border-radius:6px;font-size:.73rem;font-weight:700;
  color:var(--c-tl);transition:all var(--tr);
}
.lang-sw a.on{background:var(--c-p);color:#fff}

/* Appeal CTA button */
.btn-cta{
  background:var(--c-a);color:#fff;
  padding:8px 14px;border-radius:9px;font-weight:700;font-size:.8rem;
  display:flex;align-items:center;gap:6px;
  transition:all var(--tr);white-space:nowrap;flex-shrink:0;
}
.btn-cta:hover{background:#0A7D57;transform:translateY(-1px);box-shadow:0 4px 12px rgba(14,159,110,.35)}

/* Mobile menu toggle */
.mob-toggle{
  display:flex;background:none;border:1.5px solid var(--c-br);
  border-radius:8px;width:38px;height:38px;
  align-items:center;justify-content:center;color:var(--c-t);font-size:1.2rem;
  transition:all var(--tr);
}
.mob-toggle:hover{background:var(--c-pl);color:var(--c-p);border-color:var(--c-p)}
@media(min-width:1024px){.mob-toggle{display:none}}

/* Mobile nav drawer */
.mob-nav{
  display:none;
  background:var(--c-bg2);
  border-top:1px solid var(--c-br);
  padding:8px;
}
.mob-nav.open{display:block}
.mob-nav a{
  display:flex;align-items:center;gap:10px;
  padding:11px 14px;border-radius:8px;font-weight:600;font-size:.88rem;
  color:var(--c-tm);margin-bottom:2px;transition:all var(--tr);
}
.mob-nav a:hover,.mob-nav a.active{background:var(--c-pl);color:var(--c-p)}
.mob-nav a i{font-size:1rem;width:16px;text-align:center;color:var(--c-p)}
.mob-nav-bottom{
  padding:12px 14px;border-top:1px solid var(--c-br);margin-top:6px;
  display:flex;flex-direction:column;gap:10px;
}
.mob-lang{display:flex;gap:6px}
.mob-lang a{flex:1;text-align:center;padding:7px;border-radius:7px;border:1.5px solid var(--c-br);font-size:.8rem;font-weight:700;color:var(--c-tm);transition:all var(--tr)}
.mob-lang a.on{background:var(--c-p);color:#fff;border-color:var(--c-p)}

/* ======================================================
   TICKER
====================================================== */
.ticker{
  background:var(--c-p);color:#fff;padding:8px 0;
  overflow:hidden;
}
.ticker-in{display:flex;align-items:center;gap:0}
.ticker-lbl{
  background:var(--c-a);padding:3px 12px;border-radius:3px;
  font-size:.72rem;font-weight:800;letter-spacing:.5px;
  white-space:nowrap;flex-shrink:0;margin-right:16px;
}
.ticker-wrap{flex:1;overflow:hidden}
.ticker-txt{
  display:inline-block;white-space:nowrap;
  animation:ticker 35s linear infinite;
  font-size:.82rem;font-weight:500;
}
.ticker-txt span+span::before{content:' · ';opacity:.5;margin:0 12px}
@keyframes ticker{0%{transform:translateX(100vw)}100%{transform:translateX(-100%)}}

/* ======================================================
   SEARCH OVERLAY
====================================================== */
.search-ov{
  position:fixed;inset:0;background:rgba(0,0,0,.6);backdrop-filter:blur(4px);
  z-index:1000;display:flex;align-items:flex-start;justify-content:center;
  padding:80px 16px 16px;
  opacity:0;pointer-events:none;transition:all var(--tr);
}
.search-ov.open{opacity:1;pointer-events:all}
.search-box{
  background:var(--c-bg2);border-radius:var(--r);padding:20px;
  width:100%;max-width:600px;box-shadow:var(--sh-h);
}
.search-row{display:flex;gap:8px}
.search-input{
  flex:1;border:2px solid var(--c-br);border-radius:8px;
  padding:10px 14px;font-size:.95rem;background:var(--c-bg);
  color:var(--c-t);outline:none;transition:border-color var(--tr);
}
.search-input:focus{border-color:var(--c-p)}
.search-res{margin-top:12px;max-height:300px;overflow-y:auto}
.search-res-item{
  padding:10px;border-radius:8px;cursor:pointer;
  display:flex;align-items:center;gap:10px;
  transition:background var(--tr);font-size:.87rem;
}
.search-res-item:hover{background:var(--c-pl)}

/* ======================================================
   HERO SLIDER
====================================================== */
.hero{position:relative;background:var(--c-pd);overflow:hidden}
.hero-slides{position:relative}
.hero-slide{
  position:absolute;inset:0;opacity:0;transition:opacity .7s ease;
  background-size:cover;background-position:center;
}
.hero-slide::after{
  content:'';position:absolute;inset:0;
  background:linear-gradient(110deg,rgba(10,18,50,.82) 0%,rgba(10,18,50,.4) 60%,transparent 100%);
}
.hero-slide.on{opacity:1;position:relative;min-height:440px}
@media(min-width:768px){.hero-slide.on{min-height:520px}}
.hero-cnt{
  position:absolute;inset:0;z-index:2;
  display:flex;align-items:center;
}
.hero-inner{padding:0 20px;max-width:640px}
@media(min-width:768px){.hero-inner{padding:0 48px}}
.hero-badge{
  display:inline-flex;align-items:center;gap:6px;
  background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);
  padding:5px 12px;border-radius:20px;font-size:.72rem;font-weight:700;
  color:rgba(255,255,255,.9);margin-bottom:14px;letter-spacing:.5px;
}
.hero-h1{
  font-family:var(--serif);
  font-size:clamp(1.7rem,5vw,3rem);font-weight:900;
  color:#fff;line-height:1.15;margin-bottom:12px;
}
.hero-p{
  font-size:.95rem;color:rgba(255,255,255,.88);
  margin-bottom:24px;max-width:480px;line-height:1.65;
}
.hero-acts{display:flex;gap:10px;flex-wrap:wrap}
.btn-hero-p{
  background:var(--c-a);color:#fff;
  padding:11px 22px;border-radius:9px;font-weight:700;font-size:.88rem;
  border:2px solid var(--c-a);transition:all var(--tr);
  display:flex;align-items:center;gap:7px;
}
.btn-hero-p:hover{background:transparent;color:var(--c-a)}
.btn-hero-o{
  background:transparent;color:#fff;
  padding:11px 22px;border-radius:9px;font-weight:700;font-size:.88rem;
  border:2px solid rgba(255,255,255,.45);transition:all var(--tr);
}
.btn-hero-o:hover{background:rgba(255,255,255,.12)}

/* Slider dots & arrows */
.hero-dots{
  position:absolute;bottom:16px;left:50%;transform:translateX(-50%);
  z-index:3;display:flex;gap:6px;align-items:center;
}
.h-dot{
  width:8px;height:8px;border-radius:4px;
  background:rgba(255,255,255,.4);border:none;
  transition:all .3s ease;flex-shrink:0;
}
.h-dot.on{background:#fff;width:24px}
.hero-arr{
  position:absolute;top:50%;transform:translateY(-50%);z-index:3;
  width:42px;height:42px;border-radius:50%;
  border:1.5px solid rgba(255,255,255,.35);
  background:rgba(255,255,255,.1);backdrop-filter:blur(4px);
  color:#fff;font-size:1.1rem;
  display:flex;align-items:center;justify-content:center;
  transition:all var(--tr);
}
.hero-arr:hover{background:rgba(255,255,255,.22);border-color:#fff}
.hero-arr.prev{left:12px}
.hero-arr.next{right:12px}
@media(max-width:480px){.hero-arr{display:none}}

/* ======================================================
   STATS BAR
====================================================== */
.stats-bar{
  background:linear-gradient(135deg,var(--c-p),var(--c-pd));
  color:#fff;
}
.stats-grid{
  display:grid;
  grid-template-columns:repeat(2,1fr);
  gap:0;
}
@media(min-width:640px){.stats-grid{grid-template-columns:repeat(4,1fr)}}
.stat-it{
  text-align:center;padding:20px 12px;
  border-right:1px solid rgba(255,255,255,.12);
  border-bottom:1px solid rgba(255,255,255,.12);
}
@media(min-width:640px){.stat-it{border-bottom:none;padding:24px 16px}}
.stat-it:last-child{border-right:none}
.stat-ico{font-size:1.6rem;opacity:.75;margin-bottom:6px}
.stat-num{
  font-family:var(--serif);font-size:2rem;font-weight:900;line-height:1;
}
@media(min-width:768px){.stat-num{font-size:2.4rem}}
.stat-lbl{font-size:.72rem;opacity:.78;margin-top:4px;font-weight:600;letter-spacing:.3px}

/* ======================================================
   SECTION HEADER
====================================================== */
.sec{padding:56px 0}
.sec-hd{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:28px;flex-wrap:wrap;gap:12px}
.sec-hd-l{}
.sec-badge{
  display:inline-flex;align-items:center;gap:5px;
  background:var(--c-pl);color:var(--c-p);
  padding:4px 12px;border-radius:20px;font-size:.71rem;font-weight:700;
  letter-spacing:.4px;margin-bottom:8px;
}
.sec-title{
  font-family:var(--serif);
  font-size:clamp(1.4rem,3vw,2rem);font-weight:900;
  line-height:1.2;
}
.sec-more{
  display:inline-flex;align-items:center;gap:5px;
  color:var(--c-p);font-weight:700;font-size:.83rem;
  white-space:nowrap;transition:gap var(--tr);
  padding:7px 14px;border-radius:8px;border:1.5px solid var(--c-p);
}
.sec-more:hover{gap:9px;background:var(--c-pl)}

/* ======================================================
   QUICK LINKS (Cards)
====================================================== */
.quick-grid{
  display:grid;
  grid-template-columns:repeat(2,1fr);
  gap:10px;
}
@media(min-width:480px){.quick-grid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:768px){.quick-grid{grid-template-columns:repeat(4,1fr)}}
@media(min-width:1024px){.quick-grid{grid-template-columns:repeat(5,1fr)}}
.quick-card{
  background:var(--c-bg2);border-radius:var(--r);padding:20px 12px;
  text-align:center;border:1.5px solid var(--c-br);
  box-shadow:var(--sh);transition:all var(--tr);
  display:flex;flex-direction:column;align-items:center;gap:10px;
}
.quick-card:hover{border-color:var(--c-p);transform:translateY(-4px);box-shadow:var(--sh-h)}
.quick-ico{
  width:52px;height:52px;border-radius:14px;
  display:flex;align-items:center;justify-content:center;
  font-size:1.5rem;transition:transform var(--tr);
}
.quick-card:hover .quick-ico{transform:scale(1.1)}
.quick-lbl{font-weight:700;font-size:.82rem;color:var(--c-t)}
.quick-desc{font-size:.7rem;color:var(--c-tl)}

/* ======================================================
   NEWS GRID
====================================================== */
.news-grid{display:grid;gap:20px}
@media(min-width:768px){.news-grid{grid-template-columns:repeat(2,1fr)}}
@media(min-width:1024px){.news-grid{grid-template-columns:repeat(3,1fr)}}

.post-card{
  background:var(--c-bg2);border-radius:var(--r);overflow:hidden;
  box-shadow:var(--sh);transition:all var(--tr);
  display:flex;flex-direction:column;border:1px solid var(--c-br);
}
.post-card:hover{transform:translateY(-4px);box-shadow:var(--sh-h);border-color:transparent}
.post-card-img{
  height:180px;overflow:hidden;background:var(--c-pl);
  position:relative;flex-shrink:0;
}
.post-card-img img{width:100%;height:100%;object-fit:cover;transition:transform .5s ease}
.post-card:hover .post-card-img img{transform:scale(1.05)}
.post-card-img .no-img{
  width:100%;height:100%;display:flex;align-items:center;justify-content:center;
  font-size:2.5rem;color:var(--c-p);opacity:.3;
}
.post-cat-badge{
  position:absolute;top:10px;left:10px;
  padding:3px 10px;border-radius:20px;font-size:.68rem;font-weight:800;
  background:var(--c-p);color:#fff;letter-spacing:.3px;
}
.post-card-body{padding:16px;flex:1;display:flex;flex-direction:column}
.post-card-title{
  font-weight:800;font-size:.95rem;color:var(--c-t);
  margin-bottom:8px;line-height:1.35;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;
}
.post-card-title:hover{color:var(--c-p)}
.post-card-exc{
  font-size:.82rem;color:var(--c-tm);flex:1;margin-bottom:12px;line-height:1.55;
  display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;
}
.post-card-foot{display:flex;align-items:center;justify-content:space-between}
.post-meta{display:flex;gap:10px;font-size:.72rem;color:var(--c-tl)}
.post-meta i{font-size:.72rem}
.post-pin{
  position:absolute;top:10px;right:10px;
  background:var(--c-g);color:#fff;width:24px;height:24px;
  border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.7rem;
}

/* Elonlar — announcement style */
.elon-card{
  background:var(--c-bg2);border-radius:var(--r);overflow:hidden;
  border:1.5px solid var(--c-br);box-shadow:var(--sh);
  transition:all var(--tr);display:flex;flex-direction:column;
}
.elon-card:hover{border-color:var(--c-g);box-shadow:var(--sh-h);transform:translateY(-3px)}
.elon-card-head{
  background:linear-gradient(135deg,#FFF8E6,#FFECC0);
  padding:14px 16px;display:flex;align-items:center;gap:10px;
  border-bottom:1px solid #FFE0A0;
}
.elon-badge{
  background:var(--c-g);color:#fff;
  padding:4px 10px;border-radius:6px;font-size:.7rem;font-weight:800;white-space:nowrap;
}
.elon-date{font-size:.72rem;color:var(--c-tm);margin-left:auto}
.elon-body{padding:14px 16px;flex:1}
.elon-title{font-weight:800;font-size:.93rem;color:var(--c-t);margin-bottom:6px;line-height:1.3}
.elon-title:hover{color:var(--c-p)}
.elon-exc{font-size:.8rem;color:var(--c-tm);line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.elon-foot{padding:10px 16px;border-top:1px solid var(--c-br);display:flex;justify-content:flex-end}

/* Featured post (big) */
.post-featured{
  background:var(--c-bg2);border-radius:var(--r);overflow:hidden;
  box-shadow:var(--sh);border:1px solid var(--c-br);
  display:grid;grid-template-columns:1fr;
  transition:all var(--tr);
}
@media(min-width:640px){.post-featured{grid-template-columns:1.3fr 1fr}}
.post-featured:hover{box-shadow:var(--sh-h);border-color:transparent}
.post-featured-img{
  min-height:240px;overflow:hidden;background:var(--c-pl);position:relative;
}
.post-featured-img img{width:100%;height:100%;object-fit:cover;transition:transform .6s ease}
.post-featured:hover .post-featured-img img{transform:scale(1.04)}
.post-featured-body{padding:24px;display:flex;flex-direction:column;justify-content:center}
.post-featured-title{
  font-family:var(--serif);font-size:1.25rem;font-weight:900;
  margin-bottom:10px;line-height:1.3;color:var(--c-t);
}
.post-featured-title:hover{color:var(--c-p)}

/* ======================================================
   APPEAL SECTION
====================================================== */
.appeal-sec{
  background:linear-gradient(135deg,var(--c-p) 0%,var(--c-pd) 100%);
  color:#fff;padding:60px 0;
  position:relative;overflow:hidden;
}
.appeal-sec::before{
  content:'';position:absolute;right:-60px;top:-60px;
  width:280px;height:280px;border-radius:50%;
  background:rgba(255,255,255,.05);
}
.appeal-grid{
  display:grid;gap:40px;
  grid-template-columns:1fr;
}
@media(min-width:768px){.appeal-grid{grid-template-columns:1fr 1fr;align-items:start}}
.appeal-info h2{
  font-family:var(--serif);font-size:clamp(1.6rem,3vw,2.2rem);
  font-weight:900;margin-bottom:12px;
}
.appeal-info p{opacity:.88;font-size:.95rem;margin-bottom:24px;line-height:1.65}
.appeal-feats{display:flex;flex-direction:column;gap:14px}
.appeal-feat{display:flex;gap:12px;align-items:flex-start}
.appeal-feat-ico{
  width:38px;height:38px;border-radius:9px;
  background:rgba(255,255,255,.12);flex-shrink:0;
  display:flex;align-items:center;justify-content:center;font-size:1.1rem;
}
.appeal-feat h4{font-weight:700;font-size:.88rem;margin-bottom:2px}
.appeal-feat p{opacity:.75;font-size:.78rem;line-height:1.4}

/* Appeal form */
.appeal-form{
  background:rgba(255,255,255,.09);backdrop-filter:blur(10px);
  border:1px solid rgba(255,255,255,.14);border-radius:var(--r);
  padding:24px;
}
.appeal-form h3{font-size:1rem;font-weight:800;margin-bottom:16px}
.f-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
@media(max-width:480px){.f-row{grid-template-columns:1fr}}
.f-grp{margin-bottom:12px}
.f-grp label{display:block;font-size:.75rem;font-weight:700;opacity:.85;margin-bottom:5px}
.f-ctrl{
  width:100%;padding:10px 12px;border-radius:8px;
  border:1.5px solid rgba(255,255,255,.2);
  background:rgba(255,255,255,.08);color:#fff;
  font-family:inherit;font-size:.87rem;outline:none;
  transition:border-color var(--tr);
}
.f-ctrl:focus{border-color:rgba(255,255,255,.55)}
.f-ctrl::placeholder{color:rgba(255,255,255,.45)}
.f-ctrl option{color:#333;background:#fff}
textarea.f-ctrl{resize:vertical;min-height:90px}
.f-check{display:flex;align-items:center;gap:8px;margin-bottom:12px}
.f-check input{width:16px;height:16px;cursor:pointer;accent-color:var(--c-a)}
.f-check label{font-size:.8rem;opacity:.85;cursor:pointer}
.btn-submit{
  width:100%;padding:12px;border-radius:9px;
  background:var(--c-a);color:#fff;font-weight:700;font-size:.9rem;
  border:none;cursor:pointer;transition:all var(--tr);
  display:flex;align-items:center;justify-content:center;gap:7px;
}
.btn-submit:hover{background:#0A7D57}
.btn-submit:disabled{opacity:.6;cursor:not-allowed}

/* Check ticket */
.check-form{margin-top:16px;padding-top:16px;border-top:1px solid rgba(255,255,255,.12)}
.check-row{display:flex;gap:8px}
.check-inp{
  flex:1;padding:10px 12px;border-radius:8px;
  border:1.5px solid rgba(255,255,255,.2);
  background:rgba(255,255,255,.08);color:#fff;
  font-family:inherit;font-size:.87rem;outline:none;
  text-transform:uppercase;
}
.check-inp:focus{border-color:rgba(255,255,255,.5)}
.check-inp::placeholder{color:rgba(255,255,255,.4)}
.btn-check{
  padding:10px 16px;border-radius:8px;
  background:rgba(255,255,255,.15);color:#fff;font-weight:700;font-size:.83rem;
  border:1.5px solid rgba(255,255,255,.25);cursor:pointer;transition:all var(--tr);
  white-space:nowrap;
}
.btn-check:hover{background:rgba(255,255,255,.25)}

/* ======================================================
   STAFF
====================================================== */
.staff-grid{
  display:grid;gap:16px;
  grid-template-columns:repeat(2,1fr);
}
@media(min-width:640px){.staff-grid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:1024px){.staff-grid{grid-template-columns:repeat(4,1fr)}}
.staff-card{
  background:var(--c-bg2);border-radius:var(--r);overflow:hidden;
  box-shadow:var(--sh);border:1px solid var(--c-br);
  text-align:center;transition:all var(--tr);
}
.staff-card:hover{transform:translateY(-4px);box-shadow:var(--sh-h)}
.staff-card-top{
  height:130px;
  background:linear-gradient(135deg,var(--c-p),var(--c-pd));
  display:flex;align-items:flex-end;justify-content:center;padding-bottom:0;
}
.staff-ava{
  width:80px;height:80px;border-radius:50%;
  border:3px solid #fff;object-fit:cover;
  background:var(--c-pl);
  display:flex;align-items:center;justify-content:center;
  color:rgba(255,255,255,.6);font-size:2rem;
  margin-bottom:-40px;
}
.staff-ava img{width:100%;height:100%;object-fit:cover;border-radius:50%}
.staff-card-body{padding:48px 12px 16px}
.staff-name{font-weight:800;font-size:.88rem;margin-bottom:4px}
.staff-pos{font-size:.73rem;color:var(--c-p);font-weight:700;margin-bottom:10px}
.staff-ph{font-size:.75rem;color:var(--c-tm);display:flex;align-items:center;justify-content:center;gap:4px}
.btn-staff{
  width:100%;margin-top:10px;padding:7px;
  border-radius:7px;border:1.5px solid var(--c-p);
  color:var(--c-p);font-weight:700;font-size:.75rem;
  transition:all var(--tr);
}
.btn-staff:hover{background:var(--c-p);color:#fff}

/* ======================================================
   GALLERY
====================================================== */
.gallery-grid{
  display:grid;gap:8px;
  grid-template-columns:repeat(2,1fr);
}
@media(min-width:480px){.gallery-grid{grid-template-columns:repeat(3,1fr)}}
@media(min-width:768px){.gallery-grid{grid-template-columns:repeat(4,1fr)}}
.gal-item{
  aspect-ratio:1;border-radius:var(--r-sm);overflow:hidden;
  background:var(--c-pl);cursor:pointer;position:relative;
}
.gal-item:first-child{
  grid-column:span 2;grid-row:span 2;aspect-ratio:auto;
}
.gal-item img{width:100%;height:100%;object-fit:cover;transition:transform .5s ease}
.gal-item:hover img{transform:scale(1.06)}
.gal-ov{
  position:absolute;inset:0;background:rgba(0,0,0,.4);
  opacity:0;transition:opacity var(--tr);
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:1.6rem;
}
.gal-item:hover .gal-ov{opacity:1}

/* Lightbox */
.lb{
  position:fixed;inset:0;background:rgba(0,0,0,.93);z-index:1100;
  display:none;align-items:center;justify-content:center;
  padding:16px;
}
.lb.open{display:flex}
.lb img{max-width:100%;max-height:90vh;border-radius:8px;object-fit:contain}
.lb-close{
  position:absolute;top:16px;right:16px;
  width:40px;height:40px;border-radius:50%;
  background:rgba(255,255,255,.15);color:#fff;font-size:1.3rem;
  display:flex;align-items:center;justify-content:center;
  cursor:pointer;transition:background var(--tr);
}
.lb-close:hover{background:rgba(255,255,255,.3)}

/* ======================================================
   POLL
====================================================== */
.poll-box{
  background:var(--c-bg2);border-radius:var(--r);padding:24px;
  border:1.5px solid var(--c-br);box-shadow:var(--sh);
}
.poll-q{font-weight:700;font-size:.95rem;margin-bottom:16px;line-height:1.4}
.poll-opts{display:flex;flex-direction:column;gap:8px;margin-bottom:16px}
.poll-opt{
  display:flex;align-items:center;gap:10px;padding:10px 14px;
  border-radius:8px;border:1.5px solid var(--c-br);cursor:pointer;
  transition:all var(--tr);font-size:.85rem;font-weight:600;
}
.poll-opt:hover{border-color:var(--c-p);background:var(--c-pl);color:var(--c-p)}
.poll-opt input{accent-color:var(--c-p);width:16px;height:16px;cursor:pointer;flex-shrink:0}
/* Result bars */
.poll-bar-wrap{margin-bottom:8px}
.poll-bar-head{display:flex;justify-content:space-between;font-size:.8rem;font-weight:600;margin-bottom:4px}
.poll-bar-bg{height:8px;background:var(--c-br);border-radius:4px;overflow:hidden}
.poll-bar-fill{height:100%;background:var(--c-p);border-radius:4px;transition:width .6s ease}
.poll-total{font-size:.75rem;color:var(--c-tl);text-align:center;margin-top:8px}

/* ======================================================
   DOCUMENTS
====================================================== */
.doc-list{display:flex;flex-direction:column;gap:10px}
.doc-row{
  display:flex;align-items:center;gap:12px;
  background:var(--c-bg2);border-radius:var(--r-sm);padding:14px 16px;
  border:1.5px solid var(--c-br);transition:all var(--tr);
}
.doc-row:hover{border-color:var(--c-p);box-shadow:var(--sh)}
.doc-ico{
  width:40px;height:40px;border-radius:8px;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;font-size:1.2rem;
}
.doc-ico.pdf{background:#FEE2E2;color:#DC2626}
.doc-ico.doc,.doc-ico.docx{background:#DBEAFE;color:#1D4ED8}
.doc-ico.xls,.doc-ico.xlsx{background:#D1FAE5;color:#065F46}
.doc-ico.other{background:var(--c-pl);color:var(--c-p)}
.doc-info{flex:1;min-width:0}
.doc-title{font-weight:700;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.doc-meta{font-size:.72rem;color:var(--c-tl);margin-top:2px}
.btn-dl{
  padding:6px 14px;border-radius:7px;border:1.5px solid var(--c-p);
  color:var(--c-p);font-weight:700;font-size:.76rem;
  transition:all var(--tr);white-space:nowrap;flex-shrink:0;
  display:flex;align-items:center;gap:4px;
}
.btn-dl:hover{background:var(--c-p);color:#fff}

/* ======================================================
   EVENTS
====================================================== */
.events-list{display:flex;flex-direction:column;gap:12px}
.event-row{
  background:var(--c-bg2);border-radius:var(--r-sm);
  border:1.5px solid var(--c-br);overflow:hidden;
  display:flex;gap:0;box-shadow:var(--sh);transition:all var(--tr);
}
.event-row:hover{border-color:var(--c-a);box-shadow:var(--sh-h)}
.event-date-box{
  width:70px;background:linear-gradient(135deg,var(--c-p),var(--c-pd));
  color:#fff;text-align:center;display:flex;flex-direction:column;
  align-items:center;justify-content:center;flex-shrink:0;padding:10px 5px;
}
.event-day{font-family:var(--serif);font-size:1.8rem;font-weight:900;line-height:1}
.event-mon{font-size:.65rem;font-weight:700;opacity:.8;text-transform:uppercase}
.event-body{padding:12px;flex:1}
.event-title{font-weight:700;font-size:.88rem;margin-bottom:4px;line-height:1.3}
.event-loc{font-size:.75rem;color:var(--c-tl);display:flex;align-items:center;gap:4px}

/* ======================================================
   FAQ
====================================================== */
.faq-list{display:flex;flex-direction:column;gap:8px}
.faq-item{
  background:var(--c-bg2);border-radius:var(--r-sm);
  border:1.5px solid var(--c-br);overflow:hidden;
  transition:border-color var(--tr);
}
.faq-item.open{border-color:var(--c-p)}
.faq-q{
  width:100%;display:flex;align-items:center;justify-content:space-between;
  padding:14px 16px;font-weight:700;font-size:.9rem;
  text-align:left;background:none;color:var(--c-t);
  transition:color var(--tr);gap:8px;
}
.faq-item.open .faq-q{color:var(--c-p)}
.faq-ico{font-size:.85rem;flex-shrink:0;transition:transform .3s ease;color:var(--c-tl)}
.faq-item.open .faq-ico{transform:rotate(180deg);color:var(--c-p)}
.faq-a{
  display:none;padding:0 16px 14px;font-size:.87rem;
  color:var(--c-tm);line-height:1.65;
}
.faq-item.open .faq-a{display:block}

/* ======================================================
   SOCIAL
====================================================== */
.social-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
@media(min-width:480px){.social-grid{grid-template-columns:repeat(4,1fr)}}
.soc-card{
  background:var(--c-bg2);border-radius:var(--r-sm);padding:14px;
  text-align:center;border:1.5px solid var(--c-br);
  transition:all var(--tr);
}
.soc-card:hover{border-color:currentColor;transform:translateY(-2px);box-shadow:var(--sh)}
.soc-ico{font-size:1.5rem;margin-bottom:6px;display:block}
.soc-name{font-size:.75rem;font-weight:700;color:var(--c-tm)}

/* ======================================================
   BREADCRUMB
====================================================== */
.bc{
  display:flex;align-items:center;gap:6px;
  font-size:.78rem;color:var(--c-tl);padding:14px 0;
  flex-wrap:wrap;
}
.bc a{color:var(--c-p);font-weight:600}
.bc a:hover{text-decoration:underline}
.bc i{font-size:.65rem}

/* ======================================================
   PAGE HERO
====================================================== */
.pg-hero{
  background:linear-gradient(135deg,var(--c-p),var(--c-pd));
  color:#fff;padding:40px 0 50px;position:relative;overflow:hidden;
}
.pg-hero::before{
  content:'';position:absolute;right:-50px;bottom:-50px;
  width:220px;height:220px;border-radius:50%;
  background:rgba(255,255,255,.06);
}
.pg-hero h1{
  font-family:var(--serif);font-size:clamp(1.6rem,4vw,2.5rem);
  font-weight:900;position:relative;z-index:1;
}
.pg-hero p{opacity:.85;margin-top:8px;font-size:.92rem;position:relative;z-index:1}

/* ======================================================
   POST DETAIL
====================================================== */
.post-detail{
  background:var(--c-bg2);border-radius:var(--r);
  border:1px solid var(--c-br);box-shadow:var(--sh);
  overflow:hidden;
}
.post-detail-hero{position:relative;max-height:400px;overflow:hidden}
.post-detail-hero img{width:100%;object-fit:cover}
.post-detail-body{padding:24px}
@media(min-width:768px){.post-detail-body{padding:36px}}
.post-detail-cat{
  display:inline-block;padding:4px 12px;border-radius:20px;
  font-size:.72rem;font-weight:800;letter-spacing:.3px;
  background:var(--c-pl);color:var(--c-p);margin-bottom:14px;
}
.post-detail-h{
  font-family:var(--serif);font-size:clamp(1.5rem,4vw,2.2rem);
  font-weight:900;margin-bottom:14px;line-height:1.2;
}
.post-detail-meta{
  display:flex;gap:16px;flex-wrap:wrap;
  font-size:.78rem;color:var(--c-tl);margin-bottom:24px;
  padding-bottom:20px;border-bottom:1px solid var(--c-br);
}
.post-detail-cnt{
  font-size:.95rem;line-height:1.8;color:var(--c-tm);
}
.post-detail-cnt p{margin-bottom:14px}
.post-detail-cnt h2,.post-detail-cnt h3{color:var(--c-t);margin:20px 0 10px;font-family:var(--serif)}
.post-detail-cnt img{border-radius:var(--r-sm);margin:12px 0}

/* Share */
.share-bar{
  display:flex;align-items:center;gap:10px;
  padding:16px 0;margin-top:24px;border-top:1px solid var(--c-br);
  flex-wrap:wrap;
}
.share-bar span{font-size:.8rem;font-weight:700;color:var(--c-tl)}
.share-btn{
  width:34px;height:34px;border-radius:8px;
  display:flex;align-items:center;justify-content:center;
  color:#fff;font-size:.95rem;transition:transform var(--tr);
}
.share-btn:hover{transform:scale(1.1)}

/* ======================================================
   SIDEBAR (post detail)
====================================================== */
.post-layout{
  display:grid;gap:24px;
  grid-template-columns:1fr;
}
@media(min-width:1024px){.post-layout{grid-template-columns:1fr 320px}}
.sidebar-widget{
  background:var(--c-bg2);border-radius:var(--r);padding:20px;
  border:1.5px solid var(--c-br);box-shadow:var(--sh);margin-bottom:16px;
}
.sw-title{
  font-weight:800;font-size:.85rem;margin-bottom:14px;
  padding-bottom:8px;border-bottom:2px solid var(--c-pl);
  color:var(--c-t);
}
.sw-title i{color:var(--c-p);margin-right:5px}
.related-item{
  display:flex;gap:10px;padding:8px 0;border-bottom:1px solid var(--c-br);
}
.related-item:last-child{border-bottom:none}
.related-img{
  width:70px;height:55px;border-radius:6px;overflow:hidden;flex-shrink:0;
  background:var(--c-pl);
}
.related-img img{width:100%;height:100%;object-fit:cover}
.related-title{font-size:.8rem;font-weight:700;line-height:1.3;color:var(--c-t)}
.related-title:hover{color:var(--c-p)}
.related-date{font-size:.68rem;color:var(--c-tl);margin-top:3px}

/* ======================================================
   PAGINATION
====================================================== */
.pag{display:flex;gap:6px;justify-content:center;margin-top:32px;flex-wrap:wrap}
.pag a,.pag span{
  min-width:38px;height:38px;border-radius:8px;
  display:flex;align-items:center;justify-content:center;
  border:1.5px solid var(--c-br);background:var(--c-bg2);
  color:var(--c-tm);font-weight:700;font-size:.83rem;
  transition:all var(--tr);padding:0 10px;
}
.pag a:hover,.pag a.on{background:var(--c-p);color:#fff;border-color:var(--c-p)}

/* ======================================================
   TAGS & BADGES
====================================================== */
.badge{padding:3px 10px;border-radius:20px;font-size:.7rem;font-weight:700}
.badge-blue{background:var(--c-pl);color:var(--c-p)}
.badge-green{background:var(--c-al);color:var(--c-a)}
.badge-orange{background:#FFF8E6;color:var(--c-g)}
.badge-red{background:var(--c-rl);color:var(--c-r)}
.badge-gray{background:#F3F4F6;color:var(--c-tl)}

/* ======================================================
   ALERT / TOAST
====================================================== */
.alert{padding:12px 16px;border-radius:9px;font-size:.85rem;margin-bottom:14px;display:flex;align-items:center;gap:8px}
.alert-ok{background:var(--c-al);border:1px solid #6EE7B7;color:#065F46}
.alert-err{background:var(--c-rl);border:1px solid #FECACA;color:#991B1B}
.alert-info{background:var(--c-pl);border:1px solid #BFDBFE;color:#1E40AF}

.toast{
  position:fixed;bottom:24px;right:24px;z-index:2000;
  background:var(--c-t);color:var(--c-bg);
  padding:12px 18px;border-radius:10px;font-size:.85rem;font-weight:600;
  box-shadow:0 8px 24px rgba(0,0,0,.25);
  transform:translateY(80px);opacity:0;transition:all .35s ease;
  display:flex;align-items:center;gap:8px;max-width:320px;
}
.toast.show{transform:translateY(0);opacity:1}

/* ======================================================
   FOOTER
====================================================== */
footer{background:#0F1728;color:rgba(255,255,255,.75);padding:48px 0 0}
.footer-grid{
  display:grid;gap:32px;
  grid-template-columns:1fr;margin-bottom:32px;
}
@media(min-width:640px){.footer-grid{grid-template-columns:1fr 1fr}}
@media(min-width:1024px){.footer-grid{grid-template-columns:1.6fr 1fr 1fr 1fr}}
.footer-brand p{font-size:.82rem;opacity:.7;line-height:1.65;margin:10px 0 16px}
.footer-soc{display:flex;gap:8px}
.footer-soc a{
  width:34px;height:34px;border-radius:8px;
  border:1.5px solid rgba(255,255,255,.15);
  display:flex;align-items:center;justify-content:center;
  font-size:.95rem;color:rgba(255,255,255,.65);
  transition:all var(--tr);
}
.footer-soc a:hover{background:var(--c-p);border-color:var(--c-p);color:#fff}
.footer-title{font-weight:800;font-size:.8rem;letter-spacing:.4px;color:#fff;text-transform:uppercase;margin-bottom:14px}
.footer-links a{
  display:block;font-size:.82rem;color:rgba(255,255,255,.6);
  padding:4px 0;transition:color var(--tr);
}
.footer-links a:hover{color:#fff}
.footer-contact div{font-size:.82rem;color:rgba(255,255,255,.6);padding:4px 0;display:flex;gap:8px;align-items:flex-start}
.footer-contact i{color:var(--c-a);margin-top:2px;flex-shrink:0}
.footer-bot{
  border-top:1px solid rgba(255,255,255,.08);padding:16px 0;
  display:flex;justify-content:space-between;align-items:center;
  flex-wrap:wrap;gap:8px;font-size:.74rem;color:rgba(255,255,255,.4);
}

/* ======================================================
   SCROLL TOP
====================================================== */
.scroll-top{
  position:fixed;bottom:20px;right:20px;z-index:400;
  width:42px;height:42px;border-radius:10px;
  background:var(--c-p);color:#fff;
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;box-shadow:0 4px 14px rgba(26,86,219,.4);
  opacity:0;transform:translateY(20px);
  transition:all var(--tr);border:none;cursor:pointer;
}
.scroll-top.show{opacity:1;transform:translateY(0)}
.scroll-top:hover{background:var(--c-pd)}

/* ======================================================
   UTILITIES
====================================================== */
.text-center{text-align:center}
.mt-8{margin-top:8px}.mt-12{margin-top:12px}.mt-16{margin-top:16px}.mt-24{margin-top:24px}.mt-32{margin-top:32px}
.mb-16{margin-bottom:16px}.mb-24{margin-bottom:24px}
.d-flex{display:flex}.gap-8{gap:8px}.gap-12{gap:12px}.align-c{align-items:center}.justify-b{justify-content:space-between}
.hidden{display:none}
.skeleton{background:linear-gradient(90deg,var(--c-br) 25%,var(--c-bg) 50%,var(--c-br) 75%);background-size:200%;animation:sk 1.5s infinite;border-radius:6px}
@keyframes sk{0%{background-position:200% 0}100%{background-position:-200% 0}}

/* ======================================================
   RESPONSIVE HELPERS
====================================================== */
@media(max-width:640px){
  .sec{padding:36px 0}
  .pg-hero{padding:28px 0 36px}
  .appeal-sec{padding:36px 0}
  footer{padding:36px 0 0}
  .stat-num{font-size:1.7rem}
}
</style>
</head>
<body>

<!-- SEARCH OVERLAY -->
<div class="search-ov" id="searchOv" onclick="if(event.target===this)closeSearch()">
  <div class="search-box">
    <div class="search-row">
      <input class="search-input" id="searchInput" type="text" placeholder="<?= $L['search'] ?>...">
      <button class="h-btn" onclick="closeSearch()" style="width:42px;border-radius:8px"><i class="bi bi-x-lg"></i></button>
    </div>
    <div class="search-res" id="searchRes"></div>
  </div>
</div>

<!-- LIGHTBOX -->
<div class="lb" id="lb" onclick="if(event.target===this||event.target.closest('.lb-close'))this.classList.remove('open')">
  <button class="lb-close"><i class="bi bi-x-lg"></i></button>
  <img id="lb-img" src="" alt="">
</div>

<!-- TOAST -->
<div class="toast" id="toast"></div>

<!-- TOPBAR -->
<div class="topbar">
  <div class="wrap">
    <div class="topbar-in">
      <div class="topbar-l">
        <span><i class="bi bi-geo-alt-fill"></i> Surxondaryo, Oltinsoy</span>
        <a href="tel:<?= h(setting('site_phone')) ?>"><i class="bi bi-telephone-fill"></i> <?= h(setting('site_phone')) ?></a>
        <span id="tb-clock"></span>
      </div>
      <div class="topbar-r">
        <div class="tb-weather"><i class="bi bi-thermometer-half" style="color:#FCD34D"></i> <span id="temp">—°C</span></div>
        <a href="/?p=murojaat"><i class="bi bi-send-fill"></i> <?= $L['murojaat'] ?></a>
        <a href="/admin" target="_blank"><i class="bi bi-lock-fill"></i> Admin</a>
      </div>
    </div>
  </div>
</div>

<!-- HEADER -->
<header class="site-header">
  <div class="wrap">
    <div class="header-in">
      <!-- Logo -->
      <a href="/" class="logo">
        <div class="logo-ico"><i class="bi bi-building-fill"></i></div>
        <div class="logo-txt">
          <h1><?= h($siteName) ?></h1>
          <p>MAHALLA FUQAROLAR YIG'INI</p>
        </div>
      </a>

      <!-- Desktop nav -->
      <nav class="main-nav">
        <?php
        $navItems = [
          'home'     => ['icon'=>'bi-house-fill',       'label'=>$L['home']],
          'news'     => ['icon'=>'bi-newspaper',        'label'=>$L['news']],
          'elonlar'  => ['icon'=>'bi-megaphone-fill',   'label'=>$L['elonlar']],
          'kengash'  => ['icon'=>'bi-person-badge-fill','label'=>$L['kengash']],
          'tadbirlar'=> ['icon'=>'bi-calendar-event',   'label'=>$L['tadbirlar']],
          'galereya' => ['icon'=>'bi-images',           'label'=>$L['galereya']],
          'hujjatlar'=> ['icon'=>'bi-file-earmark',     'label'=>$L['hujjatlar']],
          'murojaat' => ['icon'=>'bi-send-fill',        'label'=>$L['murojaat']],
        ];
        foreach ($navItems as $p_ => $item):
        ?>
        <a href="/?p=<?= $p_ ?>" class="<?= $page === $p_ ? 'active' : '' ?>">
          <?= $item['label'] ?>
        </a>
        <?php endforeach; ?>
      </nav>

      <!-- Actions -->
      <div class="h-actions">
        <!-- Lang switcher (desktop) -->
        <div class="lang-sw" style="display:none" id="deskLang">
          <a href="/?lang=uz<?= $page!=='home'?'&p='.$page:'' ?>" class="<?= $lang==='uz'?'on':'' ?>">UZ</a>
          <a href="/?lang=cy<?= $page!=='home'?'&p='.$page:'' ?>" class="<?= $lang==='cy'?'on':'' ?>">ЎЗ</a>
          <a href="/?lang=ru<?= $page!=='home'?'&p='.$page:'' ?>" class="<?= $lang==='ru'?'on':'' ?>">RU</a>
        </div>
        <button class="h-btn" onclick="openSearch()" title="<?= $L['search'] ?>"><i class="bi bi-search"></i></button>
        <button class="h-btn" onclick="toggleTheme()" id="themeBtn" title="Mavzu"><i class="bi bi-moon"></i></button>
        <a href="/?p=murojaat" class="btn-cta"><i class="bi bi-send-fill"></i> <?= $L['murojaat'] ?></a>
        <button class="mob-toggle" id="mobToggle" onclick="toggleMobMenu()" aria-label="Menu">
          <i class="bi bi-list"></i>
        </button>
      </div>
    </div>
  </div>

  <!-- Mobile nav -->
  <div class="mob-nav" id="mobNav">
    <?php foreach ($navItems as $p_ => $item): ?>
    <a href="/?p=<?= $p_ ?>" class="<?= $page===$p_?'active':'' ?>">
      <i class="bi <?= $item['icon'] ?>"></i><?= $item['label'] ?>
    </a>
    <?php endforeach; ?>
    <div class="mob-nav-bottom">
      <div class="mob-lang">
        <a href="/?lang=uz<?= $page!=='home'?'&p='.$page:'' ?>" class="<?= $lang==='uz'?'on':'' ?>">O'zbekcha</a>
        <a href="/?lang=cy<?= $page!=='home'?'&p='.$page:'' ?>" class="<?= $lang==='cy'?'on':'' ?>">Ўзбекча</a>
        <a href="/?lang=ru<?= $page!=='home'?'&p='.$page:'' ?>" class="<?= $lang==='ru'?'on':'' ?>">Русский</a>
      </div>
    </div>
  </div>
</header>

<!-- TICKER -->
<div class="ticker">
  <div class="wrap">
    <div class="ticker-in">
      <span class="ticker-lbl"><i class="bi bi-megaphone-fill"></i> XABAR</span>
      <div class="ticker-wrap">
        <div class="ticker-txt" id="tickerTxt">
          <?php
          $tItems = array_map('trim', explode('|', $ticker));
          foreach ($tItems as $ti) echo '<span>' . h($ti) . '</span>';
          // Takrorlash
          foreach ($tItems as $ti) echo '<span>' . h($ti) . '</span>';
          ?>
        </div>
      </div>
    </div>
  </div>
</div>

<?php
// ============================================================
// PAGE CONTENT
// ============================================================

if ($page === 'home'): ?>

<!-- ======================================================
     HERO SLIDER
====================================================== -->
<section class="hero">
<?php if (!empty($data['sliders'])): ?>
  <div id="heroSlides">
  <?php foreach ($data['sliders'] as $i => $sl): ?>
    <div class="hero-slide <?= $i===0?'on':'' ?>"
         style="background-image:url('/<?= h($sl['image']) ?>');">
      <div class="hero-cnt">
        <div class="hero-inner">
          <div class="hero-badge"><i class="bi bi-patch-check-fill"></i> Rasmiy Portal</div>
          <h1 class="hero-h1"><?= h($lang==='ru'&&$sl['title_ru']?$sl['title_ru']:$sl['title_uz']) ?></h1>
          <?php if ($sl['subtitle']): ?>
          <p class="hero-p"><?= h($sl['subtitle']) ?></p>
          <?php endif; ?>
          <div class="hero-acts">
            <a href="/?p=murojaat" class="btn-hero-p"><i class="bi bi-send-fill"></i> <?= $L['murojaat'] ?></a>
            <a href="/?p=news" class="btn-hero-o"><?= $L['news'] ?></a>
          </div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  </div>
  <button class="hero-arr prev" onclick="hPrev()"><i class="bi bi-chevron-left"></i></button>
  <button class="hero-arr next" onclick="hNext()"><i class="bi bi-chevron-right"></i></button>
  <div class="hero-dots" id="heroDots">
    <?php foreach ($data['sliders'] as $i => $sl): ?>
    <button class="h-dot <?= $i===0?'on':'' ?>" onclick="hGo(<?= $i ?>)"></button>
    <?php endforeach; ?>
  </div>
<?php else: ?>
  <div class="hero-slide on" style="background:linear-gradient(135deg,#0F2C6F,#1A3FAA)">
    <div class="hero-cnt">
      <div class="hero-inner">
        <div class="hero-badge"><i class="bi bi-patch-check-fill"></i> Rasmiy Portal</div>
        <h1 class="hero-h1">Shakarqamish<br>Mahalla Fuqarolar<br>Yig'ini</h1>
        <p class="hero-p">Surxondaryo viloyati Oltinsoy tumani — birgalikda qurilayotgan kelajak</p>
        <div class="hero-acts">
          <a href="/?p=murojaat" class="btn-hero-p"><i class="bi bi-send-fill"></i> Murojaat yuborish</a>
          <a href="/?p=mahalla" class="btn-hero-o">Mahalla haqida</a>
        </div>
      </div>
    </div>
  </div>
<?php endif; ?>
</section>

<!-- STATS BAR -->
<div class="stats-bar">
  <div class="wrap">
    <div class="stats-grid">
      <div class="stat-it">
        <div class="stat-ico"><i class="bi bi-people-fill"></i></div>
        <div class="stat-num" data-count="<?= (int)$data['stats']['population'] ?>"><?= (int)$data['stats']['population'] ?></div>
        <div class="stat-lbl"><?= $L['population'] ?></div>
      </div>
      <div class="stat-it">
        <div class="stat-ico"><i class="bi bi-house-fill"></i></div>
        <div class="stat-num" data-count="<?= (int)$data['stats']['households'] ?>"><?= (int)$data['stats']['households'] ?></div>
        <div class="stat-lbl"><?= $L['households'] ?></div>
      </div>
      <div class="stat-it">
        <div class="stat-ico"><i class="bi bi-signpost-2-fill"></i></div>
        <div class="stat-num" data-count="<?= (int)$data['stats']['streets'] ?>"><?= (int)$data['stats']['streets'] ?></div>
        <div class="stat-lbl"><?= $L['streets'] ?></div>
      </div>
      <div class="stat-it">
        <div class="stat-ico"><i class="bi bi-calendar-check-fill"></i></div>
        <div class="stat-num"><?= h($data['stats']['founded']) ?></div>
        <div class="stat-lbl"><?= $L['founded'] ?></div>
      </div>
    </div>
  </div>
</div>

<!-- QUICK LINKS -->
<section class="sec" style="padding-bottom:0">
  <div class="wrap">
    <div class="quick-grid">
      <a href="/?p=murojaat" class="quick-card">
        <div class="quick-ico" style="background:#DBEAFE;color:#1D4ED8"><i class="bi bi-send-fill"></i></div>
        <div class="quick-lbl"><?= $L['murojaat'] ?></div>
        <div class="quick-desc">Online ariza</div>
      </a>
      <a href="/?p=news" class="quick-card">
        <div class="quick-ico" style="background:#D1FAE5;color:#065F46"><i class="bi bi-newspaper"></i></div>
        <div class="quick-lbl"><?= $L['news'] ?></div>
        <div class="quick-desc">So'nggi xabarlar</div>
      </a>
      <a href="/?p=elonlar" class="quick-card">
        <div class="quick-ico" style="background:#FEF9C3;color:#92400E"><i class="bi bi-megaphone-fill"></i></div>
        <div class="quick-lbl"><?= $L['elonlar'] ?></div>
        <div class="quick-desc">Muhim e'lonlar</div>
      </a>
      <a href="/?p=hujjatlar" class="quick-card">
        <div class="quick-ico" style="background:#FEE2E2;color:#991B1B"><i class="bi bi-file-earmark-pdf-fill"></i></div>
        <div class="quick-lbl"><?= $L['hujjatlar'] ?></div>
        <div class="quick-desc">Yuklab olish</div>
      </a>
      <a href="/?p=kengash" class="quick-card">
        <div class="quick-ico" style="background:#EDE9FE;color:#5B21B6"><i class="bi bi-person-badge-fill"></i></div>
        <div class="quick-lbl"><?= $L['kengash'] ?></div>
        <div class="quick-desc">Xodimlar</div>
      </a>
    </div>
  </div>
</section>

<!-- MUHIM E'LONLAR (PINNED) -->
<?php if (!empty($data['pinned'])): ?>
<section class="sec" style="padding-bottom:16px">
  <div class="wrap">
    <div class="sec-hd">
      <div class="sec-hd-l">
        <div class="sec-badge"><i class="bi bi-pin-angle-fill"></i> <?= $L['pinned'] ?></div>
        <h2 class="sec-title">Muhim e'lonlar</h2>
      </div>
    </div>
    <div class="news-grid">
      <?php foreach ($data['pinned'] as $post): ?>
      <article class="elon-card" style="border-color:#F8A100">
        <div class="elon-card-head">
          <span class="elon-badge"><i class="bi bi-pin-fill"></i> MUHIM</span>
          <span class="elon-date"><?= fdate($post['created_at']) ?></span>
        </div>
        <div class="elon-body">
          <a href="/?p=post&slug=<?= h($post['slug']) ?>" class="elon-title"><?= h(t($post,'title')) ?></a>
          <p class="elon-exc"><?= h(mb_substr(strip_tags(t($post,'body')),0,120)) ?>...</p>
        </div>
        <div class="elon-foot">
          <a href="/?p=post&slug=<?= h($post['slug']) ?>" class="btn-dl" style="border-color:var(--c-p);color:var(--c-p)">
            <?= $L['read'] ?> <i class="bi bi-arrow-right"></i>
          </a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- YANGILIKLAR -->
<?php if (!empty($data['news'])): ?>
<section class="sec">
  <div class="wrap">
    <div class="sec-hd">
      <div class="sec-hd-l">
        <div class="sec-badge"><i class="bi bi-newspaper"></i> <?= $L['news'] ?></div>
        <h2 class="sec-title">So'nggi yangiliklar</h2>
      </div>
      <a href="/?p=news" class="sec-more"><?= $L['all'] ?> <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="news-grid">
      <?php foreach ($data['news'] as $i => $post):
        $slug_ = h($post['slug']);
        $title_ = h(t($post,'title'));
        $body_  = h(mb_substr(strip_tags(t($post,'body')),0,130));
        $cat_   = h(t($post,'name'));
        $col_   = h($post['color'] ?? 'var(--c-p)');
      ?>
      <?php if ($i === 0): // Featured first post ?>
      <article class="post-featured" style="grid-column:1/-1">
        <div class="post-featured-img">
          <?php if ($post['image']): ?><img src="/<?= h($post['image']) ?>" alt="<?= $title_ ?>" loading="lazy">
          <?php else: ?><div style="height:240px;background:linear-gradient(135deg,var(--c-p),var(--c-pd));display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.3);font-size:4rem"><i class="bi bi-newspaper"></i></div><?php endif; ?>
          <span class="post-cat-badge" style="background:<?= $col_ ?>"><?= $cat_ ?></span>
          <?php if ($post['is_pinned']): ?><div class="post-pin"><i class="bi bi-pin-fill"></i></div><?php endif; ?>
        </div>
        <div class="post-featured-body">
          <a href="/?p=post&slug=<?= $slug_ ?>" class="post-featured-title"><?= $title_ ?></a>
          <p style="font-size:.87rem;color:var(--c-tm);line-height:1.65;margin-bottom:16px"><?= $body_ ?>...</p>
          <div class="post-meta" style="margin-bottom:14px">
            <span><i class="bi bi-calendar3"></i> <?= fdate($post['created_at']) ?></span>
            <span><i class="bi bi-eye"></i> <?= number_format($post['views']) ?></span>
          </div>
          <a href="/?p=post&slug=<?= $slug_ ?>" class="sec-more"><?= $L['read'] ?> <i class="bi bi-arrow-right"></i></a>
        </div>
      </article>
      <?php else: ?>
      <article class="post-card">
        <div class="post-card-img">
          <?php if ($post['image']): ?><img src="/<?= h($post['image']) ?>" alt="<?= $title_ ?>" loading="lazy">
          <?php else: ?><div class="no-img"><i class="bi bi-newspaper"></i></div><?php endif; ?>
          <span class="post-cat-badge" style="background:<?= $col_ ?>"><?= $cat_ ?></span>
          <?php if ($post['is_pinned']): ?><div class="post-pin"><i class="bi bi-pin-fill"></i></div><?php endif; ?>
        </div>
        <div class="post-card-body">
          <a href="/?p=post&slug=<?= $slug_ ?>" class="post-card-title"><?= $title_ ?></a>
          <p class="post-card-exc"><?= $body_ ?>...</p>
          <div class="post-card-foot">
            <div class="post-meta">
              <span><i class="bi bi-calendar3"></i><?= fdate($post['created_at']) ?></span>
              <span><i class="bi bi-eye"></i><?= number_format($post['views']) ?></span>
            </div>
            <a href="/?p=post&slug=<?= $slug_ ?>" class="badge badge-blue"><?= $L['read'] ?> →</a>
          </div>
        </div>
      </article>
      <?php endif; ?>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- E'LONLAR -->
<?php if (!empty($data['elonlar'])): ?>
<section class="sec" style="background:var(--c-bg2);padding:48px 0">
  <div class="wrap">
    <div class="sec-hd">
      <div class="sec-hd-l">
        <div class="sec-badge" style="background:#FEF9C3;color:#92400E"><i class="bi bi-megaphone-fill"></i> E'lonlar</div>
        <h2 class="sec-title">Joriy e'lonlar</h2>
      </div>
      <a href="/?p=elonlar" class="sec-more"><?= $L['all'] ?> <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="news-grid">
      <?php foreach ($data['elonlar'] as $el):
        $slug_ = h($el['slug']);
        $title_ = h(t($el,'title'));
      ?>
      <article class="elon-card">
        <div class="elon-card-head">
          <span class="elon-badge"><i class="bi bi-megaphone-fill"></i> E'LON</span>
          <?php if ($el['is_pinned']): ?><span class="badge badge-red ml-6"><i class="bi bi-pin-fill"></i> MUHIM</span><?php endif; ?>
          <span class="elon-date"><?= fdate($el['created_at']) ?></span>
        </div>
        <div class="elon-body">
          <a href="/?p=post&slug=<?= $slug_ ?>" class="elon-title"><?= $title_ ?></a>
          <p class="elon-exc"><?= h(mb_substr(strip_tags(t($el,'body')),0,130)) ?>...</p>
        </div>
        <div class="elon-foot">
          <a href="/?p=post&slug=<?= $slug_ ?>" class="btn-dl">
            <?= $L['read'] ?> <i class="bi bi-arrow-right"></i>
          </a>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- MUROJAAT SECTION -->
<section class="appeal-sec" id="murojaat-sec">
  <div class="wrap">
    <div class="appeal-grid">
      <!-- Info -->
      <div class="appeal-info">
        <div class="sec-badge" style="background:rgba(255,255,255,.12);color:#fff"><i class="bi bi-send-fill"></i> Online Murojaat</div>
        <h2>Murojaatingizni bizga yuboring</h2>
        <p>Har qanday savol, shikoyat yoki takliflaringizni onlayn yuborin. 24 soat ichida javob beramiz.</p>
        <div class="appeal-feats">
          <div class="appeal-feat">
            <div class="appeal-feat-ico"><i class="bi bi-shield-check"></i></div>
            <div><h4>Xavfsiz va maxfiy</h4><p>Anonim yuborish mumkin</p></div>
          </div>
          <div class="appeal-feat">
            <div class="appeal-feat-ico"><i class="bi bi-clock-history"></i></div>
            <div><h4>Tezkor javob</h4><p>24 soat ichida ko'rib chiqiladi</p></div>
          </div>
          <div class="appeal-feat">
            <div class="appeal-feat-ico"><i class="bi bi-ticket-perforated"></i></div>
            <div><h4>Ticket raqami</h4><p>Holatini kuzatib boring</p></div>
          </div>
        </div>
        <!-- Check ticket -->
        <div class="check-form">
          <p style="font-size:.82rem;opacity:.8;margin-bottom:10px"><i class="bi bi-search"></i> Murojaat holatini tekshirish:</p>
          <div class="check-row">
            <input class="check-inp" id="chkInp" type="text" placeholder="MFY-25-XXXXXX" maxlength="20">
            <button class="btn-check" onclick="checkTicket()"><i class="bi bi-search"></i> <?= $L['check'] ?></button>
          </div>
          <div id="chkResult" style="margin-top:10px;font-size:.82rem"></div>
        </div>
      </div>

      <!-- Form -->
      <div class="appeal-form">
        <h3><i class="bi bi-pencil-fill" style="color:var(--c-a)"></i> <?= $L['appeal_form'] ?></h3>
        <div id="appealSuccess" class="hidden">
          <div class="alert alert-ok">
            <i class="bi bi-check-circle-fill"></i>
            <span>Murojaatingiz qabul qilindi! Ticket: <strong id="appealTicket"></strong></span>
          </div>
        </div>
        <form id="appealForm">
          <div class="f-row">
            <div class="f-grp">
              <label><?= $L['name'] ?> *</label>
              <input class="f-ctrl" name="fullname" type="text" placeholder="F.I.O" required>
            </div>
            <div class="f-grp">
              <label><?= $L['phone'] ?> *</label>
              <input class="f-ctrl" name="phone" type="tel" placeholder="+998 XX XXX XX XX" required>
            </div>
          </div>
          <div class="f-grp">
            <label><?= $L['address'] ?></label>
            <input class="f-ctrl" name="address" type="text" placeholder="Ko'cha, uy raqami">
          </div>
          <div class="f-row">
            <div class="f-grp">
              <label><?= $L['type'] ?> *</label>
              <select class="f-ctrl" name="type" required>
                <option value="">Tanlang</option>
                <option value="shikoyat">Shikoyat</option>
                <option value="taklif">Taklif</option>
                <option value="ariza">Ariza</option>
                <option value="muammo">Muammo</option>
                <option value="kommunal">Kommunal</option>
                <option value="yoshlar">Yoshlar</option>
                <option value="ayollar">Ayollar</option>
                <option value="minnatdorchilik">Minnatdorchilik</option>
              </select>
            </div>
            <div class="f-grp">
              <label><?= $L['priority'] ?></label>
              <select class="f-ctrl" name="priority">
                <option value="normal">Oddiy</option>
                <option value="high">Muhim</option>
                <option value="urgent">Shoshilinch</option>
                <option value="low">Past</option>
              </select>
            </div>
          </div>
          <div class="f-grp">
            <label><?= $L['subject'] ?> *</label>
            <input class="f-ctrl" name="subject" type="text" placeholder="Murojaat mavzusi" required>
          </div>
          <div class="f-grp">
            <label><?= $L['message'] ?> *</label>
            <textarea class="f-ctrl" name="body" placeholder="Muammo yoki taklifingizni batafsil yozing..." required></textarea>
          </div>
          <div class="f-check">
            <input type="checkbox" id="anonCb" name="is_anon">
            <label for="anonCb"><?= $L['anon'] ?></label>
          </div>
          <button type="button" class="btn-submit" id="appealBtn" onclick="submitAppeal()">
            <i class="bi bi-send-fill"></i> <?= $L['send'] ?>
          </button>
        </form>
      </div>
    </div>
  </div>
</section>

<!-- KENGASH -->
<?php if (!empty($data['staff'])): ?>
<section class="sec">
  <div class="wrap">
    <div class="sec-hd">
      <div class="sec-hd-l">
        <div class="sec-badge"><i class="bi bi-person-badge-fill"></i> Kengash</div>
        <h2 class="sec-title">Mahalla kengashi</h2>
      </div>
      <a href="/?p=kengash" class="sec-more"><?= $L['all'] ?> <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="staff-grid">
      <?php foreach ($data['staff'] as $st): ?>
      <div class="staff-card">
        <div class="staff-card-top">
          <div class="staff-ava">
            <?php if ($st['photo']): ?><img src="/<?= h($st['photo']) ?>" alt="<?= h($st['fullname']) ?>">
            <?php else: ?><i class="bi bi-person-fill"></i><?php endif; ?>
          </div>
        </div>
        <div class="staff-card-body">
          <div class="staff-name"><?= h($st['fullname']) ?></div>
          <div class="staff-pos"><?= h(t($st,'position')) ?></div>
          <?php if ($st['phone']): ?>
          <div class="staff-ph"><i class="bi bi-telephone-fill" style="color:var(--c-p)"></i><a href="tel:<?= h($st['phone']) ?>"><?= h($st['phone']) ?></a></div>
          <?php endif; ?>
          <?php if ($st['reception']): ?>
          <div class="staff-ph mt-8"><i class="bi bi-clock-fill" style="color:var(--c-tl)"></i><?= h($st['reception']) ?></div>
          <?php endif; ?>
          <a href="/?p=murojaat" class="btn-staff">Murojaat yuborish</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- GALEREYA MINI -->
<?php if (!empty($data['gallery'])): ?>
<section class="sec" style="background:var(--c-bg2);padding:48px 0">
  <div class="wrap">
    <div class="sec-hd">
      <div class="sec-hd-l">
        <div class="sec-badge"><i class="bi bi-images"></i> Galereya</div>
        <h2 class="sec-title">Foto galereya</h2>
      </div>
      <a href="/?p=galereya" class="sec-more"><?= $L['all'] ?> <i class="bi bi-arrow-right"></i></a>
    </div>
    <div class="gallery-grid">
      <?php foreach ($data['gallery'] as $g): ?>
      <div class="gal-item" onclick="openLb('/<?= h($g['image']) ?>')">
        <img src="/<?= h($g['image']) ?>" alt="<?= h($g['title_uz']??'') ?>" loading="lazy">
        <div class="gal-ov"><i class="bi bi-zoom-in"></i></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- POLL + EVENTS + DOCS -->
<section class="sec">
  <div class="wrap">
    <div style="display:grid;gap:24px;grid-template-columns:1fr" id="btmGrid">

    <?php if (!empty($data['poll'])): $poll = $data['poll']; $popts = json_decode($poll['options'],true)??[]; $pvotes = json_decode($poll['votes']??'{}',true)??[]; $ptotal = max(array_sum($pvotes),0); ?>
    <div>
      <div class="sec-badge mb-16"><i class="bi bi-bar-chart-fill"></i> So'rovnoma</div>
      <div class="poll-box" id="pollBox">
        <div class="poll-q"><?= h($lang==='ru'&&$poll['question_ru']?$poll['question_ru']:$poll['question_uz']) ?></div>
        <?php if ($ptotal > 0): ?>
        <!-- Show results if already voted -->
        <?php foreach ($popts as $i=>$o): $cnt=$pvotes[$i]??0; $pct=$ptotal?round($cnt/$ptotal*100):0; ?>
        <div class="poll-bar-wrap">
          <div class="poll-bar-head"><span><?= h($o) ?></span><span><?= $pct ?>%</span></div>
          <div class="poll-bar-bg"><div class="poll-bar-fill" style="width:<?= $pct ?>%"></div></div>
        </div>
        <?php endforeach; ?>
        <div class="poll-total"><?= $ptotal ?> ta ovoz</div>
        <?php else: ?>
        <div class="poll-opts" id="pollOpts">
          <?php foreach ($popts as $i=>$o): ?>
          <label class="poll-opt">
            <input type="radio" name="poll_opt" value="<?= $i ?>"> <?= h($o) ?>
          </label>
          <?php endforeach; ?>
        </div>
        <button class="btn-submit" onclick="castVote(<?= $poll['id'] ?>)" id="pollBtn"><?= $L['vote'] ?></button>
        <?php endif; ?>
      </div>
    </div>
    <?php endif; ?>

    <?php if (!empty($data['events'])): ?>
    <div>
      <div class="sec-badge mb-16"><i class="bi bi-calendar-event"></i> <?= $L['tadbirlar'] ?></div>
      <div class="events-list">
        <?php foreach ($data['events'] as $ev): $dt=strtotime($ev['event_date']); ?>
        <div class="event-row">
          <div class="event-date-box">
            <div class="event-day"><?= date('d',$dt) ?></div>
            <div class="event-mon"><?= date('M',$dt) ?></div>
          </div>
          <div class="event-body">
            <div class="event-title"><?= h($lang==='ru'&&$ev['title_ru']?$ev['title_ru']:$ev['title_uz']) ?></div>
            <?php if ($ev['location']): ?><div class="event-loc"><i class="bi bi-geo-alt-fill"></i><?= h($ev['location']) ?></div><?php endif; ?>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <a href="/?p=tadbirlar" class="sec-more mt-12" style="display:inline-flex"><?= $L['tadbirlar'] ?> <i class="bi bi-arrow-right"></i></a>
    </div>
    <?php endif; ?>

    <?php if (!empty($data['docs'])): ?>
    <div>
      <div class="sec-badge mb-16"><i class="bi bi-file-earmark-fill"></i> <?= $L['hujjatlar'] ?></div>
      <div class="doc-list">
        <?php foreach ($data['docs'] as $d):
          $ext = strtolower(pathinfo($d['file'],PATHINFO_EXTENSION));
          $ico = in_array($ext,['pdf'])?'pdf':(in_array($ext,['doc','docx'])?'doc':(in_array($ext,['xls','xlsx'])?'xls':'other'));
        ?>
        <div class="doc-row">
          <div class="doc-ico <?= $ico ?>"><i class="bi bi-file-earmark-<?= $ico==='pdf'?'pdf':($ico==='doc'?'word':($ico==='xls'?'excel':'fill')) ?>-fill"></i></div>
          <div class="doc-info">
            <div class="doc-title"><?= h(t($d,'title')) ?></div>
            <div class="doc-meta"><?= strtoupper($ext) ?> · <?= $d['cat']?h($d['cat']).'  · ':'' ?><?= fdate($d['created_at']) ?></div>
          </div>
          <a href="/?p=hujjatlar&dl=<?= $d['id'] ?>" class="btn-dl"><i class="bi bi-download"></i> <?= $L['download'] ?></a>
        </div>
        <?php endforeach; ?>
      </div>
      <a href="/?p=hujjatlar" class="sec-more mt-12" style="display:inline-flex"><?= $L['all'] ?> <i class="bi bi-arrow-right"></i></a>
    </div>
    <?php endif; ?>

    </div>
  </div>
</section>

<!-- SOCIAL + MAP -->
<section class="sec" style="background:var(--c-bg2);padding:48px 0">
  <div class="wrap">
    <div style="display:grid;gap:32px;grid-template-columns:1fr" id="socGrid">
      <div>
        <div class="sec-badge mb-16"><i class="bi bi-share-fill"></i> Ijtimoiy tarmoqlar</div>
        <div class="social-grid">
          <a href="<?= h(setting('site_telegram','#')) ?>" class="soc-card" style="color:#0088cc" target="_blank" rel="noopener">
            <i class="bi bi-telegram soc-ico"></i><div class="soc-name">Telegram</div>
          </a>
          <a href="<?= h(setting('site_facebook','#')) ?>" class="soc-card" style="color:#1877f2" target="_blank" rel="noopener">
            <i class="bi bi-facebook soc-ico"></i><div class="soc-name">Facebook</div>
          </a>
          <a href="<?= h(setting('site_instagram','#')) ?>" class="soc-card" style="color:#E1306C" target="_blank" rel="noopener">
            <i class="bi bi-instagram soc-ico"></i><div class="soc-name">Instagram</div>
          </a>
          <a href="<?= h(setting('site_youtube','#')) ?>" class="soc-card" style="color:#FF0000" target="_blank" rel="noopener">
            <i class="bi bi-youtube soc-ico"></i><div class="soc-name">YouTube</div>
          </a>
        </div>
        <!-- Foydali raqamlar -->
        <div class="sidebar-widget mt-16">
          <div class="sw-title"><i class="bi bi-telephone-fill"></i> Foydali raqamlar</div>
          <?php $nums=[['Mahalla raisi',setting('site_phone')],['Tez yordam','103'],["Yong'in",'101'],['Politsiya','102'],['Gaz xizmati','104']];
          foreach($nums as $n): if(!$n[1]) continue; ?>
          <div style="display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--c-br);font-size:.83rem">
            <span style="color:var(--c-tm)"><?= h($n[0]) ?></span>
            <a href="tel:<?= h($n[1]) ?>" style="font-weight:700;color:var(--c-p)"><?= h($n[1]) ?></a>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <?php if ($me = setting('maps_embed')): ?>
      <div>
        <div class="sec-badge mb-16"><i class="bi bi-geo-alt-fill"></i> Manzil</div>
        <div style="border-radius:var(--r);overflow:hidden;height:280px;border:1.5px solid var(--c-br)">
          <?= $me ?>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php // ===========================================================
// NEWS LIST PAGE
elseif ($page === 'news' || $page === 'elonlar'):
$isElon = ($page === 'elonlar');
$catId  = $isElon ? 2 : (int)($query['cat'] ?? 1);
?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span><?= $isElon ? $L['elonlar'] : $L['news'] ?></span></div>
    <h1><?= $isElon ? $L['elonlar'] : $L['news'] ?></h1>
    <p>Jami <?= $data['total'] ?> ta <?= $isElon ? "e'lon" : 'yangilik' ?></p>
  </div>
</div>
<section class="sec">
  <div class="wrap">
    <!-- Category filter (faqat news uchun) -->
    <?php if (!$isElon && !empty($data['cats'])): ?>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:24px">
      <?php foreach ($data['cats'] as $c): ?>
      <a href="/?p=news&cat=<?= $c['id'] ?>"
         style="padding:7px 16px;border-radius:20px;font-size:.8rem;font-weight:700;
                border:1.5px solid <?= $catId==$c['id']?'var(--c-p)':'var(--c-br)' ?>;
                background:<?= $catId==$c['id']?'var(--c-p)':'var(--c-bg2)' ?>;
                color:<?= $catId==$c['id']?'#fff':'var(--c-tm)' ?>;
                transition:all var(--tr)">
        <?= h(t($c,'name')) ?>
      </a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php if (empty($data['posts'])): ?>
    <div class="text-center" style="padding:60px;background:var(--c-bg2);border-radius:var(--r);border:1.5px dashed var(--c-br)">
      <i class="bi bi-inbox" style="font-size:3rem;color:var(--c-tl);display:block;margin-bottom:12px"></i>
      <h3 style="margin-bottom:8px"><?= $L['no_data'] ?></h3>
    </div>
    <?php else: ?>
    <div class="<?= $isElon?'news-grid':'news-grid' ?>">
      <?php foreach ($data['posts'] as $post):
        $slug_ = h($post['slug']);
        $title_ = h(t($post,'title'));
        $body_  = h(mb_substr(strip_tags(t($post,'body')),0,120));
        $col_   = h($post['color']??'var(--c-p)');
        $cat_   = h(t($post,'name'));
      ?>
      <?php if ($isElon): ?>
      <article class="elon-card">
        <div class="elon-card-head">
          <span class="elon-badge"><i class="bi bi-megaphone-fill"></i> E'LON</span>
          <?php if ($post['is_pinned']): ?><span class="badge badge-red" style="margin-left:6px"><i class="bi bi-pin-fill"></i> MUHIM</span><?php endif; ?>
          <span class="elon-date"><?= fdate($post['created_at']) ?></span>
        </div>
        <div class="elon-body">
          <a href="/?p=post&slug=<?= $slug_ ?>" class="elon-title"><?= $title_ ?></a>
          <p class="elon-exc"><?= $body_ ?>...</p>
        </div>
        <div class="elon-foot">
          <div class="post-meta"><span><i class="bi bi-eye"></i><?= number_format($post['views']) ?></span></div>
          <a href="/?p=post&slug=<?= $slug_ ?>" class="btn-dl"><?= $L['read'] ?> <i class="bi bi-arrow-right"></i></a>
        </div>
      </article>
      <?php else: ?>
      <article class="post-card">
        <div class="post-card-img">
          <?php if ($post['image']): ?><img src="/<?= h($post['image']) ?>" alt="<?= $title_ ?>" loading="lazy">
          <?php else: ?><div class="no-img"><i class="bi bi-newspaper"></i></div><?php endif; ?>
          <span class="post-cat-badge" style="background:<?= $col_ ?>"><?= $cat_ ?></span>
          <?php if ($post['is_pinned']): ?><div class="post-pin"><i class="bi bi-pin-fill"></i></div><?php endif; ?>
        </div>
        <div class="post-card-body">
          <a href="/?p=post&slug=<?= $slug_ ?>" class="post-card-title"><?= $title_ ?></a>
          <p class="post-card-exc"><?= $body_ ?>...</p>
          <div class="post-card-foot">
            <div class="post-meta">
              <span><i class="bi bi-calendar3"></i><?= fdate($post['created_at']) ?></span>
              <span><i class="bi bi-eye"></i><?= number_format($post['views']) ?></span>
            </div>
            <a href="/?p=post&slug=<?= $slug_ ?>" class="badge badge-blue"><?= $L['read'] ?> →</a>
          </div>
        </div>
      </article>
      <?php endif; ?>
      <?php endforeach; ?>
    </div>

    <!-- Pagination -->
    <?php if ($data['pages'] > 1): $pp=$isElon?'elonlar':'news'; ?>
    <div class="pag">
      <?php if ($data['pg']>1): ?><a href="/?p=<?= $pp ?>&<?= $isElon?'':'cat='.$catId.'&' ?>pg=<?= $data['pg']-1 ?>"><i class="bi bi-chevron-left"></i></a><?php endif; ?>
      <?php for($i=max(1,$data['pg']-2);$i<=min($data['pages'],$data['pg']+2);$i++): ?>
      <a href="/?p=<?= $pp ?>&<?= $isElon?'':'cat='.$catId.'&' ?>pg=<?= $i ?>" class="<?= $i==$data['pg']?'on':'' ?>"><?= $i ?></a>
      <?php endfor; ?>
      <?php if ($data['pg']<$data['pages']): ?><a href="/?p=<?= $pp ?>&<?= $isElon?'':'cat='.$catId.'&' ?>pg=<?= $data['pg']+1 ?>"><i class="bi bi-chevron-right"></i></a><?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
  </div>
</section>

<?php // ===========================================================
// POST DETAIL
elseif ($page === 'post'):
if (empty($data['post'])): ?>
<div class="wrap"><div class="alert alert-err mt-32"><i class="bi bi-exclamation-circle"></i> Post topilmadi</div></div>
<?php else: $post = $data['post']; $title_=h(t($post,'title')); $cat_=h(t($post,'name')); $col_=h($post['color']??'var(--c-p)'); ?>
<div class="wrap">
  <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><a href="/?p=news"><?= $L['news'] ?></a><i class="bi bi-chevron-right"></i><span style="max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= $title_ ?></span></div>
  <div class="post-layout">
    <main>
      <div class="post-detail">
        <?php if ($post['image']): ?>
        <div class="post-detail-hero"><img src="/<?= h($post['image']) ?>" alt="<?= $title_ ?>"></div>
        <?php endif; ?>
        <div class="post-detail-body">
          <span class="post-detail-cat" style="background:<?= $col_ ?>;color:#fff"><?= $cat_ ?></span>
          <?php if ($post['is_pinned']): ?><span class="badge badge-orange" style="margin-left:6px"><i class="bi bi-pin-fill"></i> Muhim</span><?php endif; ?>
          <h1 class="post-detail-h"><?= $title_ ?></h1>
          <div class="post-detail-meta">
            <span><i class="bi bi-calendar3"></i> <?= fdate($post['created_at']) ?></span>
            <span><i class="bi bi-eye"></i> <?= number_format($post['views']) ?> ko'rildi</span>
            <?php if ($post['updated_at']!==$post['created_at']): ?>
            <span><i class="bi bi-pencil"></i> <?= fdate($post['updated_at']) ?> yangilangan</span>
            <?php endif; ?>
          </div>
          <div class="post-detail-cnt"><?= t($post,'body') ?></div>
          <!-- Share -->
          <div class="share-bar">
            <span><?= $L['share'] ?>:</span>
            <a class="share-btn" style="background:#0088cc" href="https://t.me/share/url?url=<?= urlencode(SITE_URL.'/?p=post&slug='.$post['slug']) ?>&text=<?= urlencode($title_) ?>" target="_blank" rel="noopener"><i class="bi bi-telegram"></i></a>
            <a class="share-btn" style="background:#1877f2" href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode(SITE_URL.'/?p=post&slug='.$post['slug']) ?>" target="_blank" rel="noopener"><i class="bi bi-facebook"></i></a>
            <button class="share-btn" style="background:var(--c-tl)" onclick="copyLink()"><i class="bi bi-link-45deg"></i></button>
          </div>
        </div>
      </div>
    </main>
    <aside>
      <?php if (!empty($data['related'])): ?>
      <div class="sidebar-widget">
        <div class="sw-title"><i class="bi bi-collection-fill"></i> O'xshash maqolalar</div>
        <?php foreach ($data['related'] as $r): ?>
        <div class="related-item">
          <div class="related-img">
            <?php if ($r['image']): ?><img src="/<?= h($r['image']) ?>" alt="" loading="lazy">
            <?php else: ?><div style="width:100%;height:100%;background:var(--c-pl);display:flex;align-items:center;justify-content:center;color:var(--c-p)"><i class="bi bi-newspaper"></i></div><?php endif; ?>
          </div>
          <div>
            <a href="/?p=post&slug=<?= h($r['slug']) ?>" class="related-title"><?= h(mb_substr(t($r,'title'),0,55)) ?>...</a>
            <div class="related-date"><?= fdate($r['created_at']) ?></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
      <!-- Murojaat widget -->
      <div class="sidebar-widget" style="background:linear-gradient(135deg,var(--c-p),var(--c-pd));color:#fff;border:none">
        <div style="font-weight:800;margin-bottom:8px"><i class="bi bi-send-fill"></i> Online murojaat</div>
        <p style="opacity:.85;font-size:.82rem;margin-bottom:14px">Savollaringizni yuboring</p>
        <a href="/?p=murojaat" style="display:block;text-align:center;padding:9px;background:rgba(255,255,255,.15);border-radius:8px;font-weight:700;font-size:.82rem;border:1px solid rgba(255,255,255,.2)">Murojaat yuborish →</a>
      </div>
    </aside>
  </div>
</div>
<?php endif; ?>

<?php // ===========================================================
// KENGASH
elseif ($page === 'kengash'):
?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span><?= $L['kengash'] ?></span></div>
    <h1><?= $L['kengash'] ?></h1>
    <p>Mahalla fuqarolar yig'ini xodimlari</p>
  </div>
</div>
<section class="sec">
  <div class="wrap">
    <?php if (!empty($data['single'])): $st=$data['single']; ?>
    <!-- Single staff -->
    <div style="display:grid;gap:24px;grid-template-columns:1fr" id="staffLayout">
      <div style="max-width:700px;margin:0 auto;width:100%">
        <a href="/?p=kengash" class="badge badge-blue mb-16" style="display:inline-flex;align-items:center;gap:4px"><i class="bi bi-arrow-left"></i> Orqaga</a>
        <div class="post-detail">
          <div style="padding:32px;display:flex;gap:24px;align-items:flex-start;flex-wrap:wrap">
            <div class="staff-ava" style="width:100px;height:100px;font-size:3rem;flex-shrink:0">
              <?php if ($st['photo']): ?><img src="/<?= h($st['photo']) ?>" alt="<?= h($st['fullname']) ?>">
              <?php else: ?><i class="bi bi-person-fill"></i><?php endif; ?>
            </div>
            <div style="flex:1">
              <h2 style="font-family:var(--serif);font-size:1.5rem;font-weight:900;margin-bottom:6px"><?= h($st['fullname']) ?></h2>
              <div style="color:var(--c-p);font-weight:700;margin-bottom:12px"><?= h(t($st,'position')) ?></div>
              <?php if ($st['phone']): ?><div style="font-size:.85rem;margin-bottom:6px"><i class="bi bi-telephone-fill" style="color:var(--c-p)"></i> <a href="tel:<?= h($st['phone']) ?>"><?= h($st['phone']) ?></a></div><?php endif; ?>
              <?php if ($st['email']): ?><div style="font-size:.85rem;margin-bottom:6px"><i class="bi bi-envelope-fill" style="color:var(--c-p)"></i> <?= h($st['email']) ?></div><?php endif; ?>
              <?php if ($st['reception']): ?><div style="font-size:.85rem;color:var(--c-tm)"><i class="bi bi-clock-fill" style="color:var(--c-tl)"></i> <?= h($st['reception']) ?></div><?php endif; ?>
            </div>
          </div>
          <?php if (t($st,'bio')): ?>
          <div class="post-detail-body" style="padding-top:0">
            <div class="post-detail-cnt"><?= t($st,'bio') ?></div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <?php else: ?>
    <div class="staff-grid">
      <?php foreach ($data['staff'] as $st): ?>
      <div class="staff-card">
        <div class="staff-card-top">
          <div class="staff-ava">
            <?php if ($st['photo']): ?><img src="/<?= h($st['photo']) ?>" alt="<?= h($st['fullname']) ?>">
            <?php else: ?><i class="bi bi-person-fill"></i><?php endif; ?>
          </div>
        </div>
        <div class="staff-card-body">
          <div class="staff-name"><?= h($st['fullname']) ?></div>
          <div class="staff-pos"><?= h(t($st,'position')) ?></div>
          <?php if ($st['phone']): ?>
          <div class="staff-ph"><i class="bi bi-telephone-fill" style="color:var(--c-p)"></i><a href="tel:<?= h($st['phone']) ?>"><?= h($st['phone']) ?></a></div>
          <?php endif; ?>
          <?php if ($st['reception']): ?>
          <div class="staff-ph mt-8"><i class="bi bi-clock"></i><?= h($st['reception']) ?></div>
          <?php endif; ?>
          <a href="/?p=kengash&id=<?= $st['id'] ?>" class="btn-staff">Batafsil</a>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page === 'galereya'): ?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span><?= $L['galereya'] ?></span></div>
    <h1><?= $L['galereya'] ?></h1>
  </div>
</div>
<section class="sec">
  <div class="wrap">
    <!-- Album filter -->
    <?php if (!empty($data['albums'])): ?>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px">
      <a href="/?p=galereya" style="padding:6px 14px;border-radius:20px;border:1.5px solid <?= !$query['album']?'var(--c-p)':'var(--c-br)' ?>;background:<?= !$query['album']?'var(--c-p)':'var(--c-bg2)' ?>;color:<?= !$query['album']?'#fff':'var(--c-tm)' ?>;font-size:.8rem;font-weight:700">Barchasi</a>
      <?php foreach ($data['albums'] as $a): $aval=$a['album']; ?>
      <a href="/?p=galereya&album=<?= urlencode($aval) ?>" style="padding:6px 14px;border-radius:20px;border:1.5px solid <?= ($query['album']===$aval)?'var(--c-p)':'var(--c-br)' ?>;background:<?= ($query['album']===$aval)?'var(--c-p)':'var(--c-bg2)' ?>;color:<?= ($query['album']===$aval)?'#fff':'var(--c-tm)' ?>;font-size:.8rem;font-weight:700"><?= h($aval) ?></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php if (empty($data['photos'])): ?>
    <div class="text-center" style="padding:60px;background:var(--c-bg2);border-radius:var(--r);border:1.5px dashed var(--c-br)">
      <i class="bi bi-images" style="font-size:3rem;color:var(--c-tl);display:block;margin-bottom:12px"></i>
      <h3><?= $L['no_data'] ?></h3>
    </div>
    <?php else: ?>
    <div class="gallery-grid">
      <?php foreach ($data['photos'] as $g): ?>
      <div class="gal-item" onclick="openLb('/<?= h($g['image']) ?>')">
        <img src="/<?= h($g['image']) ?>" alt="<?= h($g['title_uz']??'') ?>" loading="lazy">
        <div class="gal-ov"><i class="bi bi-zoom-in"></i></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page === 'hujjatlar'): ?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span><?= $L['hujjatlar'] ?></span></div>
    <h1><?= $L['hujjatlar'] ?></h1>
  </div>
</div>
<section class="sec">
  <div class="wrap">
    <?php if (!empty($data['cats'])): ?>
    <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px">
      <a href="/?p=hujjatlar" style="padding:6px 14px;border-radius:20px;border:1.5px solid <?= !($query['cat']??'')?'var(--c-p)':'var(--c-br)' ?>;background:<?= !($query['cat']??'')?'var(--c-p)':'var(--c-bg2)' ?>;color:<?= !($query['cat']??'')?'#fff':'var(--c-tm)' ?>;font-size:.8rem;font-weight:700">Barchasi</a>
      <?php foreach ($data['cats'] as $c): $cv=$c['cat']; ?>
      <a href="/?p=hujjatlar&cat=<?= urlencode($cv) ?>" style="padding:6px 14px;border-radius:20px;border:1.5px solid <?= ($query['cat']??'')===$cv?'var(--c-p)':'var(--c-br)' ?>;background:<?= ($query['cat']??'')===$cv?'var(--c-p)':'var(--c-bg2)' ?>;color:<?= ($query['cat']??'')===$cv?'#fff':'var(--c-tm)' ?>;font-size:.8rem;font-weight:700"><?= h($cv) ?></a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
    <?php if (empty($data['docs'])): ?>
    <div class="text-center" style="padding:60px;background:var(--c-bg2);border-radius:var(--r);border:1.5px dashed var(--c-br)">
      <i class="bi bi-file-earmark" style="font-size:3rem;color:var(--c-tl);display:block;margin-bottom:12px"></i>
      <h3><?= $L['no_data'] ?></h3>
    </div>
    <?php else: ?>
    <div class="doc-list">
      <?php foreach ($data['docs'] as $d):
        $ext=strtolower(pathinfo($d['file'],PATHINFO_EXTENSION));
        $ico=in_array($ext,['pdf'])?'pdf':(in_array($ext,['doc','docx'])?'doc':(in_array($ext,['xls','xlsx'])?'xls':'other'));
      ?>
      <div class="doc-row">
        <div class="doc-ico <?= $ico ?>"><i class="bi bi-file-earmark-<?= $ico==='pdf'?'pdf':($ico==='doc'?'word':($ico==='xls'?'excel':'fill')) ?>-fill"></i></div>
        <div class="doc-info">
          <div class="doc-title"><?= h(t($d,'title')) ?></div>
          <div class="doc-meta"><?= strtoupper($ext) ?><?= $d['cat']?' · '.h($d['cat']):'' ?> · <?= fdate($d['created_at']) ?> · <?= $d['downloads'] ?> marta yuklangan</div>
        </div>
        <a href="/?p=hujjatlar&dl=<?= $d['id'] ?>" class="btn-dl"><i class="bi bi-download"></i> <?= $L['download'] ?></a>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page === 'faq'): ?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span>FAQ</span></div>
    <h1>Tez-tez so'raladigan savollar</h1>
  </div>
</div>
<section class="sec">
  <div class="wrap" style="max-width:800px;margin:0 auto">
    <?php if (empty($data['faqs'])): ?>
    <div class="text-center" style="padding:60px;background:var(--c-bg2);border-radius:var(--r)">
      <i class="bi bi-question-circle" style="font-size:3rem;color:var(--c-tl);display:block;margin-bottom:12px"></i>
      <h3><?= $L['no_data'] ?></h3>
    </div>
    <?php else: ?>
    <div class="faq-list">
      <?php foreach ($data['faqs'] as $i=>$f): ?>
      <div class="faq-item" id="faq<?= $i ?>">
        <button class="faq-q" onclick="toggleFaq(<?= $i ?>)">
          <span><?= h($lang==='ru'&&$f['q_ru']?$f['q_ru']:$f['q_uz']) ?></span>
          <i class="bi bi-chevron-down faq-ico"></i>
        </button>
        <div class="faq-a"><?= $lang==='ru'&&$f['a_ru']?h($f['a_ru']):h($f['a_uz']) ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page === 'murojaat'): ?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span><?= $L['murojaat'] ?></span></div>
    <h1><?= $L['murojaat'] ?></h1>
  </div>
</div>
<section class="sec">
  <div class="wrap">
    <div class="appeal-grid">
      <div class="appeal-info" style="color:var(--c-t)">
        <div class="sec-badge mb-16"><i class="bi bi-info-circle"></i> Ma'lumot</div>
        <h2 style="color:var(--c-t)">Murojaatingizni bizga yuboring</h2>
        <p style="color:var(--c-tm)">Har qanday savol, shikoyat yoki takliflaringizni onlayn yuborin. Biz 24 soat ichida javob beramiz.</p>
        <div class="appeal-feats">
          <div class="appeal-feat">
            <div class="appeal-feat-ico" style="background:var(--c-pl);color:var(--c-p)"><i class="bi bi-shield-check"></i></div>
            <div><h4 style="color:var(--c-t)">Xavfsiz va maxfiy</h4><p style="color:var(--c-tm)">Anonim yuborish mumkin</p></div>
          </div>
          <div class="appeal-feat">
            <div class="appeal-feat-ico" style="background:var(--c-al);color:var(--c-a)"><i class="bi bi-clock-history"></i></div>
            <div><h4 style="color:var(--c-t)">24 soat ichida javob</h4><p style="color:var(--c-tm)">Har bir murojaat ko'rib chiqiladi</p></div>
          </div>
        </div>
        <!-- Ticket tekshir -->
        <div style="margin-top:24px;padding:20px;background:var(--c-bg2);border-radius:var(--r);border:1.5px solid var(--c-br)">
          <div class="sw-title"><i class="bi bi-search"></i> Murojaat holatini tekshirish</div>
          <div style="display:flex;gap:8px">
            <input id="chkInp2" type="text" placeholder="MFY-25-XXXXXX" maxlength="20" style="flex:1;padding:10px;border-radius:8px;border:1.5px solid var(--c-br);background:var(--c-bg);color:var(--c-t);font-family:inherit;font-size:.87rem;outline:none;text-transform:uppercase">
            <button onclick="checkTicket2()" style="padding:10px 16px;border-radius:8px;background:var(--c-p);color:#fff;font-weight:700;font-size:.83rem;border:none;cursor:pointer">Tekshirish</button>
          </div>
          <div id="chkResult2" style="margin-top:10px;font-size:.83rem"></div>
        </div>
      </div>
      <!-- Form (murojaat sahifasi) -->
      <div>
        <div class="post-detail">
          <div class="post-detail-body">
            <h3 style="font-family:var(--serif);font-size:1.2rem;font-weight:900;margin-bottom:16px">Murojaat shakli</h3>
            <div id="appealSuccess2" class="hidden">
              <div class="alert alert-ok mb-16">
                <i class="bi bi-check-circle-fill"></i>
                <span>Qabul qilindi! Ticket: <strong id="appealTicket2"></strong></span>
              </div>
            </div>
            <form id="appealForm2">
              <div class="f-row" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                <div class="f-grp"><label style="display:block;font-size:.75rem;font-weight:700;color:var(--c-tl);margin-bottom:5px"><?= $L['name'] ?> *</label><input class="search-input" name="fullname" type="text" style="width:100%;background:var(--c-bg)" placeholder="F.I.O" required></div>
                <div class="f-grp"><label style="display:block;font-size:.75rem;font-weight:700;color:var(--c-tl);margin-bottom:5px"><?= $L['phone'] ?> *</label><input class="search-input" name="phone" type="tel" style="width:100%;background:var(--c-bg)" placeholder="+998 XX XXX XX XX" required></div>
              </div>
              <div class="f-grp mt-12"><label style="display:block;font-size:.75rem;font-weight:700;color:var(--c-tl);margin-bottom:5px"><?= $L['address'] ?></label><input class="search-input" name="address" type="text" style="width:100%;background:var(--c-bg)" placeholder="Ko'cha, uy raqami"></div>
              <div class="f-row mt-12" style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                <div class="f-grp"><label style="display:block;font-size:.75rem;font-weight:700;color:var(--c-tl);margin-bottom:5px"><?= $L['type'] ?> *</label>
                <select class="search-input" name="type" style="width:100%;background:var(--c-bg)" required>
                  <option value="">Tanlang</option>
                  <option value="shikoyat">Shikoyat</option><option value="taklif">Taklif</option>
                  <option value="ariza">Ariza</option><option value="muammo">Muammo</option>
                  <option value="kommunal">Kommunal</option><option value="minnatdorchilik">Minnatdorchilik</option>
                </select></div>
                <div class="f-grp"><label style="display:block;font-size:.75rem;font-weight:700;color:var(--c-tl);margin-bottom:5px"><?= $L['priority'] ?></label>
                <select class="search-input" name="priority" style="width:100%;background:var(--c-bg)">
                  <option value="normal">Oddiy</option><option value="high">Muhim</option>
                  <option value="urgent">Shoshilinch</option><option value="low">Past</option>
                </select></div>
              </div>
              <div class="f-grp mt-12"><label style="display:block;font-size:.75rem;font-weight:700;color:var(--c-tl);margin-bottom:5px"><?= $L['subject'] ?> *</label><input class="search-input" name="subject" type="text" style="width:100%;background:var(--c-bg)" placeholder="Murojaat mavzusi" required></div>
              <div class="f-grp mt-12"><label style="display:block;font-size:.75rem;font-weight:700;color:var(--c-tl);margin-bottom:5px"><?= $L['message'] ?> *</label><textarea class="search-input" name="body" style="width:100%;background:var(--c-bg);resize:vertical;min-height:100px" placeholder="Batafsil yozing..." required></textarea></div>
              <div style="display:flex;align-items:center;gap:8px;margin:12px 0"><input type="checkbox" id="anonCb2" name="is_anon" style="width:16px;height:16px;cursor:pointer;accent-color:var(--c-p)"><label for="anonCb2" style="font-size:.82rem;cursor:pointer;color:var(--c-tm)"><?= $L['anon'] ?></label></div>
              <button type="button" onclick="submitAppeal2()" style="width:100%;padding:12px;border-radius:9px;background:var(--c-p);color:#fff;font-weight:700;font-size:.9rem;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:7px" id="appealBtn2"><i class="bi bi-send-fill"></i> <?= $L['send'] ?></button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<?php elseif ($page === 'tadbirlar'): ?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span><?= $L['tadbirlar'] ?></span></div>
    <h1><?= $L['tadbirlar'] ?></h1>
  </div>
</div>
<section class="sec">
  <div class="wrap">
    <?php if (!empty($data['upcoming'])): ?>
    <div class="sec-badge mb-16"><i class="bi bi-calendar-check-fill"></i> <?= $L['upcoming'] ?></div>
    <div class="events-list mb-24">
      <?php foreach ($data['upcoming'] as $ev): $dt=strtotime($ev['event_date']); ?>
      <div class="event-row">
        <div class="event-date-box"><div class="event-day"><?= date('d',$dt) ?></div><div class="event-mon"><?= date('M',$dt) ?></div></div>
        <div class="event-body">
          <div class="event-title" style="font-size:.95rem"><?= h($lang==='ru'&&$ev['title_ru']?$ev['title_ru']:$ev['title_uz']) ?></div>
          <?php if ($ev['location']): ?><div class="event-loc mt-8"><i class="bi bi-geo-alt-fill"></i><?= h($ev['location']) ?></div><?php endif; ?>
          <?php if (t($ev,'body')): ?><div style="font-size:.8rem;color:var(--c-tm);margin-top:6px"><?= h(mb_substr(strip_tags(t($ev,'body')),0,120)) ?>...</div><?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="text-center" style="padding:40px;background:var(--c-bg2);border-radius:var(--r);margin-bottom:24px">
      <p style="color:var(--c-tl)"><?= $L['no_data'] ?></p>
    </div>
    <?php endif; ?>

    <?php if (!empty($data['past'])): ?>
    <div class="sec-badge mb-16"><i class="bi bi-clock-history"></i> <?= $L['past'] ?></div>
    <div class="events-list">
      <?php foreach ($data['past'] as $ev): $dt=strtotime($ev['event_date']); ?>
      <div class="event-row" style="opacity:.7">
        <div class="event-date-box" style="background:var(--c-tl)"><div class="event-day"><?= date('d',$dt) ?></div><div class="event-mon"><?= date('M',$dt) ?></div></div>
        <div class="event-body">
          <div class="event-title"><?= h($lang==='ru'&&$ev['title_ru']?$ev['title_ru']:$ev['title_uz']) ?></div>
          <?php if ($ev['location']): ?><div class="event-loc"><i class="bi bi-geo-alt-fill"></i><?= h($ev['location']) ?></div><?php endif; ?>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</section>

<?php elseif ($page === 'mahalla'): ?>
<div class="pg-hero">
  <div class="wrap">
    <div class="bc"><a href="/">Bosh sahifa</a><i class="bi bi-chevron-right"></i><span><?= $L['mahalla'] ?></span></div>
    <h1><?= $L['mahalla'] ?></h1>
  </div>
</div>
<section class="sec">
  <div class="wrap" style="max-width:900px;margin:0 auto">
    <div class="post-detail">
      <div class="post-detail-body">
        <div class="sec-badge mb-16"><i class="bi bi-info-circle-fill"></i> Umumiy ma'lumot</div>
        <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:16px;margin-bottom:24px">
          <?php $stats_=[['bi-people-fill','Aholi soni',setting('population','0').' nafar'],['bi-house-fill',"Uy-xonadonlar",setting('households','0')." ta"],["bi-signpost-2-fill","Ko'chalar",setting('streets','0')." ta"],['bi-calendar-check-fill','Tashkil topgan',setting('founded_year','1992').' yil'],['bi-person-badge-fill','Kengash xodimlari',$data['staff_count'].' nafar']]; ?>
          <?php foreach ($stats_ as $s): ?>
          <div style="background:var(--c-pl);border-radius:var(--r-sm);padding:16px;display:flex;align-items:center;gap:12px">
            <div style="width:44px;height:44px;border-radius:10px;background:var(--c-p);display:flex;align-items:center;justify-content:center;color:#fff;font-size:1.1rem;flex-shrink:0"><i class="bi <?= $s[0] ?>"></i></div>
            <div><div style="font-size:.72rem;color:var(--c-tl);font-weight:600"><?= $s[1] ?></div><div style="font-weight:800;font-size:1.05rem"><?= $s[2] ?></div></div>
          </div>
          <?php endforeach; ?>
        </div>
        <p style="color:var(--c-tm);line-height:1.8">
          Shakarqamish mahalla fuqarolar yig'ini — Surxondaryo viloyati Oltinsoy tumanida joylashgan. 
          Mahallaning rasmiy portali orqali yangiliklar, e'lonlar, hujjatlar bilan tanishish va online murojaat yuborish mumkin.
        </p>
        <div style="margin-top:24px">
          <a href="/?p=murojaat" class="sec-more"><i class="bi bi-send-fill"></i> Murojaat yuborish <i class="bi bi-arrow-right"></i></a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php endif; ?>

<!-- ============================================================
     FOOTER
============================================================ -->
<footer>
  <div class="wrap">
    <div class="footer-grid">
      <div class="footer-brand">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
          <div class="logo-ico"><i class="bi bi-building-fill"></i></div>
          <div><div style="font-weight:800;color:#fff"><?= h($siteName) ?></div><div style="font-size:.65rem;opacity:.5">MAHALLA FUQAROLAR YIG'INI</div></div>
        </div>
        <p><?= h(setting('site_address','Surxondaryo viloyati, Oltinsoy tumani')) ?></p>
        <div class="footer-soc">
          <a href="<?= h(setting('site_telegram','#')) ?>" target="_blank" rel="noopener"><i class="bi bi-telegram"></i></a>
          <a href="<?= h(setting('site_facebook','#')) ?>" target="_blank" rel="noopener"><i class="bi bi-facebook"></i></a>
          <a href="<?= h(setting('site_instagram','#')) ?>" target="_blank" rel="noopener"><i class="bi bi-instagram"></i></a>
          <a href="<?= h(setting('site_youtube','#')) ?>" target="_blank" rel="noopener"><i class="bi bi-youtube"></i></a>
        </div>
      </div>
      <div>
        <div class="footer-title">Sahifalar</div>
        <div class="footer-links">
          <?php foreach([['home',$L['home']],['news',$L['news']],['elonlar',$L['elonlar']],['kengash',$L['kengash']],['galereya',$L['galereya']],['hujjatlar',$L['hujjatlar']]] as $fl): ?>
          <a href="/?p=<?= $fl[0] ?>"><?= $fl[1] ?></a>
          <?php endforeach; ?>
        </div>
      </div>
      <div>
        <div class="footer-title">Xizmatlar</div>
        <div class="footer-links">
          <?php foreach([['murojaat',$L['murojaat']],['tadbirlar',$L['tadbirlar']],['faq','FAQ'],['mahalla',$L['mahalla']]] as $fl): ?>
          <a href="/?p=<?= $fl[0] ?>"><?= $fl[1] ?></a>
          <?php endforeach; ?>
          <a href="/admin">Admin panel</a>
        </div>
      </div>
      <div>
        <div class="footer-title">Bog'lanish</div>
        <div class="footer-contact">
          <div><i class="bi bi-geo-alt-fill"></i><?= h(setting('site_address')) ?></div>
          <div><i class="bi bi-telephone-fill"></i><a href="tel:<?= h(setting('site_phone')) ?>"><?= h(setting('site_phone')) ?></a></div>
          <?php if(setting('site_phone2')): ?><div><i class="bi bi-telephone-fill"></i><a href="tel:<?= h(setting('site_phone2')) ?>"><?= h(setting('site_phone2')) ?></a></div><?php endif; ?>
          <div><i class="bi bi-envelope-fill"></i><?= h(setting('site_email')) ?></div>
          <div><i class="bi bi-clock-fill"></i>Du–Ju: 9:00–18:00</div>
        </div>
      </div>
    </div>
    <div class="footer-bot">
      <span>&copy; <?= date('Y') ?> <?= h($siteName) ?>.uz — Barcha huquqlar himoyalangan</span>
      <span>v2.0 · <?= $lang === 'uz' ? "O'zbekcha" : ($lang==='cy'?'Ўзбекча':'Русский') ?></span>
    </div>
  </div>
</footer>

<button class="scroll-top" id="scrollTop" onclick="window.scrollTo({top:0,behavior:'smooth'})" title="Yuqoriga">
  <i class="bi bi-chevron-up"></i>
</button>

<!-- ============================================================
     JAVASCRIPT
============================================================ -->
<script>
const CSRF_TOKEN = '<?= $csrfToken ?>';
// ======================================================
// THEME
// ======================================================
(function(){
  const t = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', t);
  const btn = document.getElementById('themeBtn');
  if (btn) btn.innerHTML = t==='dark' ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon"></i>';
})();

function toggleTheme(){
  const cur = document.documentElement.getAttribute('data-theme');
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  document.getElementById('themeBtn').innerHTML = next==='dark' ? '<i class="bi bi-sun"></i>' : '<i class="bi bi-moon"></i>';
}

// ======================================================
// MOBILE MENU
// ======================================================
function toggleMobMenu(){
  const nav = document.getElementById('mobNav');
  const tog = document.getElementById('mobToggle');
  nav.classList.toggle('open');
  tog.innerHTML = nav.classList.contains('open') ? '<i class="bi bi-x-lg"></i>' : '<i class="bi bi-list"></i>';
}
// Desktop lang show
(function(){
  const dl = document.getElementById('deskLang');
  if (window.innerWidth >= 1024 && dl) dl.style.display = 'flex';
  window.addEventListener('resize', function(){
    if (dl) dl.style.display = window.innerWidth>=1024 ? 'flex' : 'none';
  });
})();

// ======================================================
// CLOCK
// ======================================================
function updateClock(){
  const now = new Date();
  const days = ['Yak','Du','Se','Cho','Pa','Ju','Sha'];
  const p = n => String(n).padStart(2,'0');
  const el = document.getElementById('tb-clock');
  if(el) el.textContent = `${days[now.getDay()]}, ${p(now.getDate())}.${p(now.getMonth()+1)}.${now.getFullYear()} ${p(now.getHours())}:${p(now.getMinutes())}:${p(now.getSeconds())}`;
}
setInterval(updateClock,1000); updateClock();

// ======================================================
// WEATHER
// ======================================================
(async()=>{
  try{
    const r = await fetch('https://api.open-meteo.com/v1/forecast?latitude=37.8&longitude=67.9&current_weather=true');
    const d = await r.json();
    const el = document.getElementById('temp');
    if(el && d.current_weather) el.textContent = Math.round(d.current_weather.temperature)+'°C';
  }catch(e){}
})();

// ======================================================
// HERO SLIDER
// ======================================================
(function(){
  const slides = document.querySelectorAll('.hero-slide');
  const dots   = document.querySelectorAll('.h-dot');
  if(!slides.length) return;
  let cur = 0, timer;
  function go(n){
    slides[cur].classList.remove('on'); dots[cur]?.classList.remove('on');
    cur = (n + slides.length) % slides.length;
    slides[cur].classList.add('on'); dots[cur]?.classList.add('on');
  }
  window.hNext = ()=>{ clearInterval(timer); go(cur+1); start(); };
  window.hPrev = ()=>{ clearInterval(timer); go(cur-1); start(); };
  window.hGo   = (i)=>{ clearInterval(timer); go(i); start(); };
  function start(){ timer=setInterval(()=>go(cur+1),5000); }
  start();
})();

// ======================================================
// COUNTER ANIMATION
// ======================================================
(function(){
  const els = document.querySelectorAll('[data-count]');
  const obs = new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(!e.isIntersecting) return;
      const el=e.target, target=+el.dataset.count;
      if(target===0){el.textContent='0';return;}
      let n=0; const step=Math.ceil(target/60);
      const t=setInterval(()=>{n=Math.min(n+step,target);el.textContent=n.toLocaleString();if(n>=target)clearInterval(t);},20);
      obs.unobserve(el);
    });
  },{threshold:.5});
  els.forEach(e=>obs.observe(e));
})();

// ======================================================
// SCROLL TOP
// ======================================================
window.addEventListener('scroll',()=>{
  document.getElementById('scrollTop')?.classList.toggle('show', window.scrollY>400);
},{ passive:true });

// ======================================================
// SEARCH
// ======================================================
function openSearch(){
  document.getElementById('searchOv').classList.add('open');
  setTimeout(()=>document.getElementById('searchInput')?.focus(),150);
}
function closeSearch(){ document.getElementById('searchOv').classList.remove('open'); }
document.addEventListener('keydown',e=>{
  if(e.key==='Escape') closeSearch();
  if((e.ctrlKey||e.metaKey)&&e.key==='k'){e.preventDefault();openSearch();}
});
document.getElementById('searchInput')?.addEventListener('input',function(){
  const q=this.value.trim();
  const res=document.getElementById('searchRes');
  if(q.length<2){res.innerHTML='';return;}
  // Oddiy client-side search (DB ga murojaat ham qilish mumkin)
  res.innerHTML='<p style="padding:10px;color:var(--c-tl);font-size:.83rem"><i class="bi bi-search"></i> "'+q+'" — qidirilmoqda... <a href="/?p=news&q='+encodeURIComponent(q)+'" style="color:var(--c-p)">Yangiliklarda qidirish →</a></p>';
});

// ======================================================
// LIGHTBOX
// ======================================================
function openLb(src){
  document.getElementById('lb-img').src=src;
  document.getElementById('lb').classList.add('open');
}
document.addEventListener('keydown',e=>{ if(e.key==='Escape') document.getElementById('lb')?.classList.remove('open'); });

// ======================================================
// TOAST
// ======================================================
function showToast(msg, type='ok'){
  const t=document.getElementById('toast');
  t.innerHTML = (type==='ok'?'<i class="bi bi-check-circle-fill" style="color:#34D399"></i>':'<i class="bi bi-exclamation-circle-fill" style="color:#F87171"></i>') + ' ' + msg;
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'),3500);
}

// ======================================================
// APPEAL FORM (Hero / Home)
// ======================================================
async function submitAppeal(){
  const form=document.getElementById('appealForm');
  if(!form) return;
  const btn=document.getElementById('appealBtn');
  const fd=new FormData(form);
  fd.append('action','appeal');
  fd.append('csrf', CSRF_TOKEN);

  // Minimal validatsiya
  const fn=fd.get('fullname')?.trim(), ph=fd.get('phone')?.trim(), sub=fd.get('subject')?.trim(), bod=fd.get('body')?.trim(), tp=fd.get('type');
  if(!fn||fn.length<2){showToast('Ism kamida 2 harf','err');return;}
  if(!ph||ph.length<7){showToast('Telefon noto\'g\'ri','err');return;}
  if(!tp){showToast('Murojaat turini tanlang','err');return;}
  if(!sub||sub.length<3){showToast('Mavzu kiriting','err');return;}
  if(!bod||bod.length<10){showToast('Matn juda qisqa','err');return;}

  btn.disabled=true; btn.innerHTML='<i class="bi bi-hourglass-split"></i> Yuborilmoqda...';
  try{
    const r=await fetch(window.location.pathname,{method:'POST',body:fd});
    const d=await r.json();
    if(d.ok){
      document.getElementById('appealTicket').textContent=d.ticket;
      document.getElementById('appealSuccess').classList.remove('hidden');
      form.reset(); form.style.display='none';
      showToast('Murojaatingiz qabul qilindi! Ticket: '+d.ticket);
    } else showToast(d.msg||'Xatolik','err');
  }catch(e){showToast('Ulanish xatosi','err');}
  finally{btn.disabled=false; btn.innerHTML='<i class="bi bi-send-fill"></i> <?= $L['send'] ?>';}
}

// Murojaat sahifasi form
async function submitAppeal2(){
  const form=document.getElementById('appealForm2');
  if(!form) return;
  const btn=document.getElementById('appealBtn2');
  const fd=new FormData(form);
  fd.append('action','appeal');
  fd.append('csrf', CSRF_TOKEN);
  if(document.getElementById('anonCb2')?.checked) fd.set('is_anon','1');
  const fn=fd.get('fullname')?.trim(), ph=fd.get('phone')?.trim(), sub=fd.get('subject')?.trim(), bod=fd.get('body')?.trim(), tp=fd.get('type');
  if(!fn||fn.length<2){showToast('Ism kamida 2 harf','err');return;}
  if(!ph||ph.length<7){showToast('Telefon noto\'g\'ri','err');return;}
  if(!tp){showToast('Murojaat turini tanlang','err');return;}
  if(!sub){showToast('Mavzu kiriting','err');return;}
  if(!bod||bod.length<10){showToast('Matn juda qisqa','err');return;}
  btn.disabled=true; btn.innerHTML='<i class="bi bi-hourglass-split"></i> Yuborilmoqda...';
  try{
    const r=await fetch(window.location.href,{method:'POST',body:fd});
    const d=await r.json();
    if(d.ok){
      document.getElementById('appealTicket2').textContent=d.ticket;
      document.getElementById('appealSuccess2').classList.remove('hidden');
      form.reset(); form.style.display='none';
      showToast('Qabul qilindi! Ticket: '+d.ticket);
    } else showToast(d.msg||'Xatolik','err');
  }catch(e){showToast('Ulanish xatosi','err');}
  finally{btn.disabled=false; btn.innerHTML='<i class="bi bi-send-fill"></i> <?= $L['send'] ?>';}
}

// ======================================================
// CHECK TICKET
// ======================================================
async function checkTicket(){
  const inp=document.getElementById('chkInp');
  const res=document.getElementById('chkResult');
  if(!inp||!res) return;
  const tk=inp.value.trim().toUpperCase();
  if(!tk){res.innerHTML='<span style="color:var(--c-r)">Ticket kiriting</span>';return;}
  res.innerHTML='<span style="opacity:.7"><i class="bi bi-hourglass-split"></i> Tekshirilmoqda...</span>';
  const fd=new FormData(); fd.append('action','check_appeal'); fd.append('ticket',tk);
  try{
    const r=await fetch(window.location.pathname,{method:'POST',body:fd});
    const d=await r.json();
    if(d.ok){
      const a=d.data;
      const sc={'new':'#60A5FA','processing':'#FBBF24','resolved':'#34D399','rejected':'#F87171'};
      const st={'new':'Yangi','processing':"Ko'rib chiqilmoqda",'resolved':'Hal qilindi','rejected':'Rad etildi'};
      res.innerHTML=`<div style="background:rgba(255,255,255,.1);border-radius:8px;padding:12px;margin-top:8px">
        <div style="font-weight:700;margin-bottom:6px">${a.subject}</div>
        <div>Holat: <span style="color:${sc[a.status]||'#60A5FA'};font-weight:700">${st[a.status]||a.status}</span></div>
        ${a.reply?'<div style="margin-top:8px;padding:8px;background:rgba(255,255,255,.08);border-radius:6px;font-size:.82rem"><b>Javob:</b> '+a.reply+'</div>':''}
      </div>`;
    } else res.innerHTML=`<span style="color:#F87171"><i class="bi bi-exclamation-circle"></i> ${d.msg}</span>`;
  }catch(e){res.innerHTML='<span style="color:#F87171">Ulanish xatosi</span>';}
}

async function checkTicket2(){
  const inp=document.getElementById('chkInp2');
  const res=document.getElementById('chkResult2');
  if(!inp||!res) return;
  const tk=inp.value.trim().toUpperCase();
  if(!tk){res.innerHTML='<span style="color:var(--c-r)">Ticket kiriting</span>';return;}
  res.innerHTML='<span style="color:var(--c-tl)"><i class="bi bi-hourglass-split"></i> Tekshirilmoqda...</span>';
  const fd=new FormData(); fd.append('action','check_appeal'); fd.append('ticket',tk);
  try{
    const r=await fetch(window.location.href,{method:'POST',body:fd});
    const d=await r.json();
    if(d.ok){
      const a=d.data;
      const sc={'new':'var(--c-p)','processing':'var(--c-g)','resolved':'var(--c-a)','rejected':'var(--c-r)'};
      const st={'new':'Yangi','processing':"Ko'rib chiqilmoqda",'resolved':'Hal qilindi','rejected':'Rad etildi'};
      res.innerHTML=`<div class="alert alert-info" style="margin-top:8px">
        <div style="font-weight:700">${a.subject}</div>
        <div>Holat: <span style="color:${sc[a.status]||'var(--c-p)'};font-weight:700">${st[a.status]||a.status}</span></div>
        ${a.reply?`<div style="margin-top:8px;font-size:.82rem"><b>Javob:</b> ${a.reply}</div>`:''}
      </div>`;
    } else res.innerHTML=`<div class="alert alert-err" style="margin-top:8px">${d.msg}</div>`;
  }catch(e){res.innerHTML='<div class="alert alert-err">Ulanish xatosi</div>';}
}

// ======================================================
// POLL
// ======================================================
async function castVote(pollId){
  const sel = document.querySelector('input[name="poll_opt"]:checked');
  if(!sel){showToast("Variantni tanlang",'err');return;}
  const btn=document.getElementById('pollBtn');
  btn.disabled=true;
  const fd=new FormData(); fd.append('action','vote'); fd.append('csrf',CSRF_TOKEN); fd.append('poll_id',pollId); fd.append('option',sel.value);
  try{
    const r=await fetch(window.location.pathname,{method:'POST',body:fd});
    const d=await r.json();
    if(d.ok){
      const box=document.getElementById('pollBox');
      let html='';
      d.results.forEach(o=>{html+=`<div class="poll-bar-wrap"><div class="poll-bar-head"><span>${o.text}</span><span>${o.pct}%</span></div><div class="poll-bar-bg"><div class="poll-bar-fill" style="width:${o.pct}%"></div></div></div>`;});
      html+=`<div class="poll-total">${d.total} ta ovoz</div>`;
      box.querySelector('.poll-opts')?.remove(); box.querySelector('button')?.remove();
      box.insertAdjacentHTML('beforeend',html);
      showToast('<?= $L['vote_done'] ?>');
    } else showToast(d.msg||'Xatolik','err');
  }catch(e){showToast('Ulanish xatosi','err');}
  finally{btn.disabled=false;}
}

// ======================================================
// FAQ
// ======================================================
function toggleFaq(i){
  const item=document.getElementById('faq'+i);
  if(!item) return;
  item.classList.toggle('open');
}

// ======================================================
// SHARE
// ======================================================
async function copyLink(){
  try{ await navigator.clipboard.writeText(window.location.href); showToast('Havola nusxa olindi!'); }
  catch(e){ showToast('Nusxa olib bo\'lmadi','err'); }
}

// ======================================================
// RESPONSIVE LAYOUT FIXES
// ======================================================
(function(){
  function fixLayouts(){
    const w=window.innerWidth;
    // Bottom grid on home
    const bg=document.getElementById('btmGrid');
    if(bg) bg.style.gridTemplateColumns=w>=768?'1fr 1fr':'1fr';
    // Social grid on home
    const sg=document.getElementById('socGrid');
    if(sg) sg.style.gridTemplateColumns=w>=768?'1fr 1fr':'1fr';
    // Staff layout
    const sl=document.getElementById('staffLayout');
    if(sl) sl.style.gridTemplateColumns='1fr';
    // Footer
    const fg=document.querySelector('.footer-grid');
    if(fg){
      if(w>=1024) fg.style.gridTemplateColumns='1.6fr 1fr 1fr 1fr';
      else if(w>=640) fg.style.gridTemplateColumns='1fr 1fr';
      else fg.style.gridTemplateColumns='1fr';
    }
    // Post layout
    const pl=document.querySelector('.post-layout');
    if(pl) pl.style.gridTemplateColumns=w>=1024?'1fr 320px':'1fr';
    // Appeal grid
    document.querySelectorAll('.appeal-grid').forEach(ag=>{
      ag.style.gridTemplateColumns=w>=768?'1fr 1fr':'1fr';
    });
    // f-row grids
    document.querySelectorAll('.f-row').forEach(fr=>{
      fr.style.gridTemplateColumns=w>=480?'1fr 1fr':'1fr';
    });
  }
  fixLayouts();
  window.addEventListener('resize',fixLayouts,{passive:true});
})();
</script>
</body>
</html>
